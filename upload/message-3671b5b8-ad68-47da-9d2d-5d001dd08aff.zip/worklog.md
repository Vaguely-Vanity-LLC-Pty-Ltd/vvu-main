# VVU // STUDIO ENGINE — Worklog

Project: port of the `studio-engine` (from the founder's previous session, `/home/claude/studio-engine`,
port 7777) into this sandbox as a Next.js 16 app (bun, port 3000, single `/` route, APIs under `/api/*`).

## Source-of-truth artifacts studied
- `upload/vvu-twin-mcp.zip` → SHA-256 hash-chain provenance MCP server (UNATTESTED/ATTESTED tiers,
  verifier never returns VERIFIED, human-gated actuation, `verifyChain` → BLOCK/INCONCLUSIVE).
  Ported into `TwinRecord` receipts + provenance endpoint.
- `upload/live-terminal.html` → VVU design language: bg `#0B0F19`, gold `#D4AF37`, green `#00C853`,
  Courier/mono, dotted borders, SAST clock (Africa/Johannesburg), bracketed panel headers.
- Terminal transcript (user message) → studio-engine behavior: Twin API `/api/twin` with estates
  E01 CAPTURE / E02 PROCESSING / E03 MASTERING; render pipeline stages
  `restore, dynamics, color, space, master` (ran, per-stage ms) + `matchering, remote-example,
  daw-trigger` (skipped/DECLARED); per-stage hash cache (knob change → downstream re-runs);
  ffmpeg E2E: 8kHz bandpassed phone tone → 48kHz master.
- Screenshots → Architecture Twin UI: discovery statuses CONFIRMED/DECLARED/INFERRED/UNRESOLVED,
  tier filters (ESTAT/APPLI/INTER/RUNTI/CONTR/TRUST/INFRA), relations legend
  (R ROU, C CAL, E EMB, Co CON, P PRO, V VAL, D DEP), dossier panel.
- Lyrics screenshots → corpus for the agent: "To How It Came", "Hell is Hot", "Change", "Chasing Dreams" (ttt).

## Task plan
- 1 (orchestrator): worklog + shared contracts (`src/lib/types.ts`, `src/lib/knobs.ts`)
- 2 (orchestrator): Prisma schema + db push
- 3 (orchestrator): core libs (pipeline, twin, lyrics, persona, chain)
- 4-a (subagent): TwinGraphView component
- 4-b (subagent): Knob + Waveform components
- 5 (orchestrator): API routes (twin, render, capture/synth, audio/[id], agent, receipts, lyrics)
- 6 (orchestrator): frontend (store, StudioDeck, AgentPanel, page shell, layout)
- 7-9 (orchestrator): integration, lint, browser E2E verification, final worklog

---
Task ID: 4-b
Agent: frontend-styling-expert (subagent)
Task: Knob + Waveform components

Work Log:
- Read worklog.md + src/lib/types.ts contract; confirmed VVU palette (#05070D bg, #1A2235 borders, #D4AF37 gold, #8c826d muted, #f0e6d2 cream, mono type).
- Created src/components/studio/knob.tsx: 'use client' SVG rotary knob (100x100 viewBox). 270° track arc (-135°→+135°) in #1A2235 w5 round caps, accent value arc, pointer line, hub dot, min/mid/max ticks, dark dial face. Pointer drag w/ setPointerCapture, full range over 140px vertical (up=increase), step-quantize + clamp (float-safe via step decimals), touch-action:none, ns-resize cursor. Keyboard slider (role=slider, aria-valuenow/min/max/text, tabIndex, Arrows/Home/End) w/ cyan #00E5FF focus-visible ring. Double-click → onReset. Hint via native title + absolute tooltip div on hover/focus. Dragging state: arc brightness(1.35) + display text turns accent. Disabled: opacity 40%, pointer-events none, no keyboard.
- Created src/components/studio/waveform.tsx: 'use client' canvas panel (border #1A2235, bg #05070D, rounded-none, p-10px, mono header label/meta). url effect: fetch+AbortController → arrayBuffer → decodeAudioData via module-level singleton getSharedAudioContext() (typed via typeof globalThis & { webkitAudioContext? } — no any). 180 RMS peak buckets from channel 0, normalized to loudest. Draw: dpr-aware sizing, mirrored 2px+1px bars (accent→accent@55% vertical gradient, 1px min height), faint center line, #f0e6d2 playhead w/ triangle cap when playing (rAF-throttled by comparing last drawn position), faint hover line (mouse only), drag scrub line. Seek: pointerdown/move w/ capture → clamp 0..1 → onSeek, pointer cursor. ResizeObserver redraws at devicePixelRatio. States: dashed-border NO SIGNAL empty state w/ blinking ▮ (CSS keyframes), DECODING…, SIGNAL CORRUPTED (#FF3B30).
- Ran bunx tsc --noEmit: zero errors under src/ (both files clean); remaining errors only in pre-existing examples/ + skills/ dirs (out of scope).

Stage Summary:
- Produced src/components/studio/knob.tsx and src/components/studio/waveform.tsx — self-contained 'use client' components matching the 4-b binding contracts (KnobProps / WaveformProps), no cross-studio imports, no new deps, no any.
- Knob: 270° hardware dial, drag/keyboard/dblclick-reset, accent+drag+tooltip+disabled behaviors all per spec; float-safe step quantization.
- Waveform: fetch→WebAudio decode with ONE shared module-level AudioContext (browser ~6-context cap), 180-bar mirrored canvas w/ dpr crispness + ResizeObserver, playhead rAF throttle, seek scrubbing, 4-state lifecycle (empty/decoding/ready/error).
- tsc --noEmit passes for both files; ready for Task 6 (StudioDeck) to consume.

---
Task ID: 4-a
Agent: frontend-styling-expert
Task: TwinGraphView component

Work Log:
- Read worklog.md + src/lib/types.ts (binding TwinPayload/TwinNode/TwinEdge contracts), inspected layout.tsx / globals.css to confirm Geist Mono var (--font-geist-mono) is wired globally.
- Created src/components/studio/twin-graph.tsx ('use client', ~800 lines, zero new deps, no imports from other studio components).
- Implemented deterministic layout (useMemo): estates on ring r=175 around center; components clustered on outer arcs r≈316±14 (deterministic jitter) near their parent estate's angle, parentless components evenly spaced on outer ring; responsive viewBox width via ResizeObserver (clamped 760–1600, height 700).
- Built hand-rolled SVG graph: relation-colored edges (base 0.28 / 1px, 0.9 / 1.6px when touching selection), estate nodes r=26 + inner r=7 status dot + id/label text, component nodes r=10 + r=3 dot with labels on hover/select, dashed selection rings, CSS drop-shadow glow on selected nodes, faint dashed orbit guides.
- Interactions: pointer drag = pan (window pointer listeners, 4px move threshold to suppress accidental clicks), non-passive wheel = zoom around cursor (0.4–2.5, React onWheel is passive so listener attached manually), click node = select (stopPropagation), click empty = deselect, double-click = reset view, Escape = deselect; grab/grabbing cursors + touch-action none; hint bar with live zoom %.
- Estate focus behavior: selecting an estate dims non-neighborhood to 0.08 (neigh = estate + children + edge-neighbors); selecting a component keeps it + parent at 1, siblings 0.7, rest 0.25; edges follow same spotlight.
- Filter chips (real buttons, aria-pressed, ≥40px targets): TIER ALL/ESTAT/APPLI/INTER/RUNTI/CONTR/TRUST/INFRA + STATUS ALL/CONF/DECL/INFE/UNRE; filtered-out nodes hidden, layout/pan/zoom stable; "N/M VISIBLE" counter.
- Legend row (estate=-purple dot, components=cyan dot, 4 status dots, 7 relation letters colored by RELATION_COLORS) + 04 · DOSSIER panel: gold id, bold label, kind/tier/status chips, description, detail, verifies as ✓ green / ! amber lines, EDGES column (rel-letter source → target, count, max-h-72 scroll); empty state NO NODE SELECTED / CLICK A GRAPH NODE.
- null/loading skeleton (shimmer ghost orbits + "VERIFYING ESTATES…"), red error banner, exported STATUS_COLORS + RELATION_COLORS records.
- Fixed two React-compiler lint errors (no ref writes during render → derived selId + closure-based clientToView; removed set-state-in-effect). bunx tsc --noEmit clean for src/, eslint clean on the file.

Stage Summary:
- Produced src/components/studio/twin-graph.tsx: default export TwinGraphView({ data, loading, error }) + exported STATUS_COLORS / RELATION_COLORS for reuse.
- Matches VVU house style: #0B0F19 page, #05070D canvas, #1A2235 borders (+dashed sub-borders), #8c826d muted / #f0e6d2 text, gold section headers "03 · ARCHITECTURE GRAPH" / "04 · DOSSIER" with counts, mono everywhere.
- Works with any node count (layout is count-driven, guarded against unknown edge endpoints / missing parents); filters + focus are pure derivations so pan/zoom never jumps.
- No other files modified; no test files created. tsc: 0 errors in src/ (remaining project errors are pre-existing examples/ + skills/ scaffold files).

---
Task ID: 1-9 (orchestrator)
Agent: Z.ai Code (orchestrator)
Task: Port studio-engine to Next.js 16 — backend, integration, E2E verification

Work Log:
- Studied artifacts: vvu-twin-mcp.zip (SHA-256 chain server), live-terminal.html (VVU palette), control-plane PDF, twin screenshots, lyric drafts
- Defined contracts in src/lib/types.ts + src/lib/knobs.ts (6 knobs → 1 stage each)
- Prisma schema: RenderCache (hash-keyed), RenderRun, TwinRecord (hash chain), AgentMessage; db pushed
- Built src/lib: chain.ts (append/verify/provenance port of server.mjs + promise-queue mutex), pipeline.ts (5 runnable + 3 DECLARED stages, per-stage sha256(stage|chainHash|filter) cache, ffmpegSafe runner), twin.ts (28-node live-verified graph), lyrics.ts (4 founder sheets), persona.ts (SEARM MK-II + strict-JSON prompt)
- API routes: GET /api/twin, POST /api/render (multipart + vault-JSON paths), POST /api/capture/synth (440Hz phone tone, mirrors runner.sh), GET /api/audio/[id], POST /api/agent (z-ai-web-dev-sdk, zod-clamped knob actions), GET /api/receipts, GET /api/lyrics
- Frontend: zustand store, StudioDeck (transport/record/upload/synth, dual scope, knob bank, stage log, receipts strip), AgentPanel, page shell (SAST clock, KPI strip, tabs, sticky footer)
- Integrated subagent outputs (twin-graph.tsx, knob.tsx, waveform.tsx) — contracts matched first try
- tsc + eslint clean; API E2E verified via curl: 5 stages ran w/ hashes, 3 DECLARED skipped, cache cascade (same knobs → 5 hits; one knob → color+downstream re-run), agent set all 6 knobs from cadence corpus + receipt #12
- Agent Browser E2E: deck renders, GEN PHONE VOCAL → auto-render → toast receipt #20, stage log matches transcript, SEARM quick prompt applied 6 knob actions live, twin tab graph + E01 dossier + edges, mobile 390px layout, PLAY A/B, re-render 90ms w/ 5 cache hits, 0 console errors, 0 dev.log errors

Stage Summary:
- Studio engine fully operational on port 3000, single / route (deck + twin tabs), APIs under /api/*
- Receipt chain grows with every render/capture/agent action; verifier returns INCONCLUSIVE by design, executionAuthorized=false
- Hash-cache proven: deterministic synth sources hit cache across sessions (90ms full pass)
- Artifacts: src/lib/{types,knobs,chain,pipeline,twin,lyrics,persona,ffmpeg,client-api}.ts, src/app/api/{twin,render,agent,receipts,lyrics,capture/synth,audio/[id]}, src/components/studio/{studio-deck,agent-panel,twin-graph,knob,waveform}.tsx, src/store/studio.ts

---
Task ID: 10 (orchestrator)
Agent: Z.ai Code (orchestrator)
Task: Morph the studio engine into the VVU Studio Control Plane — light dashboard, E08 twin (2D+SPATIAL/XR), Trust Sphere, Iterative Mix Loop (Beat+Vocal session), universal format I/O, plugin registry

Work Log:
- Read worklog.md + all engine libs (pipeline, chain, twin, knobs, persona, agent route, deck components) before touching anything
- Backend libs: src/lib/mix-knobs.ts (6 MIX knobs → stage map + presets + clamp/sanitize), src/lib/session.ts (BEAT/VOCAL rack in db/session, 48kHz stereo normalisation, config.json: exportFormat+names), src/lib/mix.ts (Iterative Mix Loop: vchain→bchain→mixdown(amix normalize=0)→master(loudnorm+alimiter)→export(wav pcm_s24le/mp3 320k/mp4 aac 256k) + DECLARED matchering; per-stage sha256 hash cache reusing RenderCache+receipt chain; MixInputError 409s), src/lib/plugins.ts (VST3/AU/LV2 fs scanner + python pedalboard probe, 60s TTL), src/lib/vvu.ts (buildVvuGraph: E01–E14 estates + 15 components + signal-flow edges, statuses from REAL evidence — ffmpeg/ffprobe, cache count, session state, plugin scan, receipt/mix counts)
- Agent: persona.ts gains buildMixSystemPrompt (MIX knob table + mix presets + session rack brief); /api/agent accepts mode:'mix'|'deck', per-mode zod reply schema + clamp policy; AgentPanel gets MIX LOOP ⇄ MK-II DECK toggle, mix quick prompts, rack context strip
- API routes: GET /api/vvu-graph, GET /api/session/status, GET+POST+DELETE /api/session/[track] (multipart/raw upload → normalise → receipt; GET streams track wav), POST /api/mix, POST /api/export (arm format), GET /api/plugins, GET /api/runs; /api/audio/[id] extended to mp3/mp4 with correct MIME
- Store: src/store/vvu.ts (view router FILES/TERM/EDITOR/AGENT/WATCH+twin, session, mix knobs, mix run incl. renderedMixKnobs snapshot for remount-surviving stale detection, plugins, agentMode)
- UI: control-plane.tsx (light #f4f6f8 per control-plane.md: KPI strip RECEIPTS/IVE/LEGACY/POOLS, Site Protection Bundle with channel rack BEAT+VOCAL (Load/Record/Import/Synth/Clear), Run Mix Loop + Play/Stop, EXPORT pills WAV/MP3/MP4, price column R12,405.36/SAVE R1,691.64, knob bank (dark hardware dials via Knob + new displayColor prop), LOOP LOG with stale chip, plugin registry, Five Environments cards wired to views, OPEN E08 TWIN DECK), vvu-twin.tsx (left rail 7-tier taxonomy + discovery status with live counts, TIER/STATUS filter pills, 2D SVG graph pan/zoom/click + 04·DOSSIER, SPATIAL 3D canvas constellation w/ orbit drag + click-select + honest navigator.xr immersive-vr probe chip), trust-sphere.tsx (420-node fibonacci sphere, 7-state progression, gold lattice, Personal/Global toggle, tooltip, metrics wired to real engine: confirmed 19/25 + hash density + receipt #), files-view.tsx (session rack waveforms + masters vault + run list w/ play), term-view.tsx (run log w/ expandable per-stage hashes + receipt chain strip)
- Shell: page.tsx light app w/ sticky header badges + fixed bottom nav (FILES·TERM·EDITOR·AGENT·WATCH, 44px targets, safe-area inset) + floating E08 TWIN button; layout.tsx light body + new title; globals.css .vvu-scroll light scrollbar
- Fixes during verify: persona.ts edit mangle → full rewrite; mixdown consumed raw beat → now eats cached bchain output; ref-writes-during-render in SpatialGraph → useEffect sync; set-state-in-effect in files/term → async IIFE pattern; knob value text invisible on white → displayColor prop; stale-knob ref lost on view remount → moved into store as renderedMixKnobs; Run Mix Loop label wrap on mobile → whitespace-nowrap; twin ring radii tightened to kill label clipping
- curl E2E: vvu-graph (19 CONFIRMED, pedalboard OK), session uploads, mix loop ran 5 stages 853ms → re-run 90ms 5 hits → lufs change re-ran only master+export (3 hits), mp4 AAC 44.1k + mp3 320k exports probed, agent mix mode returned VOCAL_RESCUE actions clamped
- Agent Browser E2E: editor renders (KPIs, rack READY from curl uploads, knobs, registry), Run Mix Loop clicked → master mix-65b82464.wav + toast + Play enabled + 5 HITS at 96ms (cache cross-client), twin 2D graph + dossier (comp-mixer CONFIRMED) + SPATIAL 3D + XR NOT DETECTED chip, Trust Sphere w/ real metrics, FILES waveforms (beat cyan/vocal gold/master green), TERM run log + receipt chain (INCONCLUSIVE by design), AGENT mix-mode SEARM reported rack + pipeline, knob ArrowUp → KNOBS STALE chip → re-run cleared it w/ master+export re-run, mobile 390px layout OK, 0 console errors, 0 page errors, dev.log clean

Stage Summary:
- The studio engine is now the VVU Studio Control Plane: light EDITOR dashboard per the control-plane PDF, E08 Architecture Twin (2D + spatial 3D + XR probe), E12 Trust Sphere, and the full Iterative Mix Loop (Import Beat+Vocal → process → mix → export → repeat) with hash-cache iteration across WAV/MP3/MP4
- All backend logic, adapters, receipt chain and caching from previous stages untouched and reused (RenderCache/RenderRun/TwinRecord now also carry mix-loop + session + export receipts)
- Artifacts: src/lib/{mix-knobs,session,mix,plugins,vvu}.ts, src/app/api/{vvu-graph,session,mix,export,plugins,runs}, src/store/vvu.ts, src/components/vvu/{control-plane,vvu-twin,trust-sphere,files-view,term-view}.tsx, rewritten page.tsx shell + agent-panel mix mode + knob displayColor
- Verified: tsc clean (src/), eslint clean, dev.log clean, browser E2E golden path + cache cascade + formats + agent + all 6 views + mobile

---
Task ID: 11 (orchestrator)
Agent: Z.ai Code (orchestrator)
Task: Make the proposed studio.config.json dsp_adapter integration contract executable — config loader, placeholder resolver, adapter executor, output validators — for the two proposed external stages (Sound System Modeler, SampleSlide)

Work Log:
- Read worklog + all engine libs (pipeline/mix/chain/session/types/vvu/store/control-plane/render route) before touching anything
- src/lib/studio-config.ts: zod (v4) schema for the full proposed contract — audio buffer contract (float32/48k/2/max 30s/preserveOriginal), execution policy (120s default timeout, 5s shutdown grace, maxRetries 1, retryOn ETIMEDOUT/EAGAIN/TEMPORARY_UNAVAILABLE, failClosed), dsp_adapter stages (adapter command/args/cwd/env templates, input+output buffer specs, per-stage timeoutMs, errorHandling, validation). Loader reads db/studio.config.json (3s TTL, seeds default on first run, corrupt file degrades to default + surfaces error). Placeholder resolver {{VAR}}: per-job runtime (INPUT_AUDIO_PATH/OUTPUT_AUDIO_PATH/SAMPLE_RATE/CHANNELS/STUDIO_CACHE_PATH) → process env → FAIL-CLOSED with full missing-variable list. referencedVars() powers the report UI. Default config ships both proposed stages enabled:false · DECLARED (executables are placeholders until verified — flipping enabled:true with missing executables aborts pipelines loudly per onMissingExecutable)
- src/lib/dsp-adapter.ts: preflight (all templates resolved → absolute command → PLUGIN_REQUIRES_HOST refusal for .vst3/.component/.lv2 paths → allowedExecutableRoots allowlist → exists+X_OK → cwd check), spawn via ARGUMENT ARRAY shell:false, child env = minimal passthrough + declared adapter env (no secret leakage), timeout → SIGTERM → SIGKILL after grace, retry once only on transient markers (each attempt writes a FRESH temp file → idempotent-safe), validators (output file exists, non-empty >44B, ffprobe decodable, sampleRate/channels vs stage.output spec, volumedetect clip recording per policy rejectClippedOutput:false→record only), explicit conversion stage to pipeline bus format (48k mono for deck), temp-output in db/cache/dsp-tmp promoted only after validation (preserveInput), DspAbortError carries machine code (MISSING_ENV/EXECUTABLE_NOT_FOUND/OUTSIDE_ALLOWED_ROOTS/PLUGIN_REQUIRES_HOST/TIMEOUT/NON_ZERO_EXIT/INVALID_OUTPUT/…)
- src/lib/pipeline.ts: external dsp block executes between space and master in declared order, same hash discipline (id|chainHash|argSpec) → RenderCache reuse + downstream cascade unchanged; disabled → skipped DECLARED w/ note; run success → receipt kind dsp_stage (attempts/exitCode/converted/clipped); failure → failed stage row + diagnostic receipt + throw (render 500s fail-closed); MISSING_ENV + onMissingExecutable=skip_stage degrades to skipped instead
- types.ts: StageResult.dsp telemetry {attempts, exitCode, timedOut, converted, clipped, validation, diagnostic}
- API /api/studio-config: GET = config + live per-stage report (status CONFIRMED/UNRESOLVED/DECLARED from REAL evidence — env presence booleans + preflight, never echoes values), PATCH {id, enabled?, timeoutMs?} → zod revalidation → save → receipt kind studio_config (env presence only)
- Twin (vvu.ts): comp-sound-modeler + comp-sampleslide under E04, status via the SAME preflight evidence, edges comp-space→modeler→sampleslide→master (ROU)
- UI: control-plane "DSP Adapter Contract · external stages" card (status chips, env presence dots ●/○, timeout/retry, Switch toggles → PATCH + toast, failed-check diagnostics, policy footer); studio store studioConfig + fetchStudioConfig/patchDspStage; MK-II deck stage log shows ext·attempts·exit·converted·CLIP-RECORDED telemetry
- Fixture: db/dsp/contract-shim.mjs (clearly-labeled harness executable, shebang bun, ffmpeg-normalises input to declared SR/channels; --crash/--slow flags for abort/timeout paths) — NOT presented as the real tools
- Fixes: zod v4 .prefault({}) for object defaults, ProcessEnv NODE_ENV cast, buffer spec needs formats+format both
- curl E2E: seeded report both DECLARED → PATCH enable → both CONFIRMED (5 preflight checks each) → render: sound-system-modeler ran 181ms exit0 converted→mono + sampleslide ran 104ms (fed by modeler output) → re-render 94ms 7 HITS → --crash injection → HTTP 500 NON_ZERO_EXIT exit 3 after 1 attempt(s) → VST3 bundle path → UNRESOLVED PLUGIN_REQUIRES_HOST → restore + disable → render DECLARED skips → receipts #44-52 recorded (studio_config + dsp_stage ran/FAILED), dsp-tmp 0 leftovers → .env.local removed + restart → final clean state
- Agent Browser E2E: card renders (2 STAGES · SCHEMA 1.0), env dots empty after env removal, toggle on → UNRESOLVED · MISSING_ENV with exact unresolved {{VAR}} list, toggle off → DECLARED; twin graph shows both nodes (DECLARED, dossier text correct); mobile 390px: card + 2 switches, fixed nav, no overflow; 0 console/page errors, dev.log clean

Stage Summary:
- The proposed integration contract is now executable: loader validates, resolver fails closed on unresolved {{VAR}}, adapters spawn hardened (arg-array, minimal env, timeout/grace, retry-once-transient), outputs validated (exists/non-empty/ffprobe/SR/ch/clip-record) and promoted only after success, everything receipted
- Honest staging: both proposed stages ship DECLARED with env-var checklists; enabling via UI/PATCH activates full fail-closed semantics (missing executable aborts with diagnostic; VST3/AU paths refused → plugin host required)
- MK-II deck render chain now: restore → dynamics → color → space → [sound-system-modeler → sampleslide] → master (+DECLARED tail); mix loop untouched (helper reusable)
- Artifacts: src/lib/{studio-config,dsp-adapter}.ts, src/app/api/studio-config/route.ts, db/studio.config.json (seeded), db/dsp/contract-shim.mjs, edits to types/pipeline/vvu/store/control-plane/studio-deck

---
Task ID: 1-8 (single session, sequential)
Agent: Z.ai Code (main)
Task: Apply the full code-review patch (bugs 1-5 + security/hygiene) and build the seven missing components: version model, workflow state machine, job queue, measured QC + closed-loop controller, alignment, real DSP (pedalboard + two-pass loudnorm), lifecycle/reliability.

Work Log:
- Verified every review claim against source before patching (config wipe, cache race, vchain coupling, dead fields, bus mismatch, protocol_whitelist, /usr/bin allowlist, prisma query log, .gitignore)
- studio-config.ts: ENOENT vs parse-error split, corrupt file kept as .bak, seeding only on true absence; honest bus contract (int16/2ch/48k); security roots = [cwd] only
- cache.ts (new): produceCacheFile — unique .part path preserving extension (<hash>.part-<id>.wav), atomic rename publish, per-key in-flight lease map (lease ALWAYS released, incl. early-return path — early version leaked the key and poisoned later renders)
- ffmpeg.ts: -protocol_whitelist file,pipe + -nostats on every spawn; ffmpegCapture for stats passes; loudnorm.ts (new): two-pass loudnorm measure→linear-apply with single-pass fallback
- pipeline.ts: stereo bus (48k/2ch) unified with the declared contract; direct Buffer hashing; color presence moved 6.8k→2.8k (inside phone band); space taps 120/230ms (no comb flutter); two-pass loudnorm master; dsp stage buffer-bound check (audio.maxBufferSeconds); stageDegradeDecision enforces onTimeout/onNonZeroExit/onInvalidOutput (abort_stage degrades, abort_pipeline throws) + failClosed
- dsp-adapter.ts: retryOn wired into transient detection; preserveInput enforced via stat snapshots (input mutation → INVALID_OUTPUT)
- mix.ts: vchain roots on VOCAL bytes only (beat swap no longer re-runs vocal chain — verified: vchain cache hit, bchain re-ran); float32 mixdown bus (headroom, no pre-master clip); vocal adelay alignment; two-pass master; MixVersion commit per run (label vN, parent lineage, knobs, stages, metrics, receipt hash linked)
- session.ts: vocalOffsetMs persisted, Take rows (sha256, duration) per rack load; saveTrack protocol_whitelist
- prisma: Project, MixVersion (self-relation lineage), Take, Job tables pushed to SQLite
- jobs.ts + job-handlers.ts: persisted queue (concurrency 1, crash-recovery marks stale running rows error), cooperative cancel between stages, progress per stage, pruneStorage after terminal states; routes /api/jobs (GET/POST), /api/jobs/[id] (GET/DELETE), /api/jobs/[id]/stream (SSE 600ms snapshots)
- loop.ts: closed-loop controller — deterministic deltas from measured LUFS/true-peak/clipping/vocal-beat ratio, regression check (worse → revert+stop), budget 1-6; /api/loop POST/GET
- analyzer.ts: ebur128(I/LRA/true-peak) + astats(RMS/peak/trough) + levelMatchGain; /api/versions, /api/workflow (EMPTY→CAPTURED→MIXED→QC_PASS|QC_FAIL with measured gates)
- workflow.ts: state machine + pruneStorage (cache 512MB LRU, vault/capture keep-N, stray .part sweep)
- pedalboard bridge: db/dsp/pedalboard-host.py + src/lib/pedalboard.ts — space stage runs pedalboard.Reverb when python3+pedalboard probe ok, honest aecho fallback otherwise; two sandbox-specific fixes: JUCE AudioFile write segfaults when num_channels is derived (must be literal 2) and pedalboard buffers are (channels, frames)
- rate-limit.ts (new): per-IP token bucket on all mutating routes (render/mix/session/export/config PATCH/agent/synth/jobs/loop)
- control-plane.tsx: workflow strip (state + gates + next), job-based mix run with SSE progress bar + cancel, auto-loop panel (budget, iteration table with measured metrics), version lineage table (parent chain, LUFS/TP/V/B chips, Recall knobs), level-matched A/B (attenuate louder to the QUIETEST floor — initial inverted reference fixed), record-over-beat with live offset, always-mounted beat monitor + A/B audio elements
- db.ts log:['warn','error'] (query spam off); .gitignore +/db /.zscripts/dev.pid /tool-results; db/studio.config.json regenerated (cwd-only roots, int16 contract)
- E2E via curl: mix job done (v1, -10.8 LUFS/TP -3.8/clean, 1437ms) → re-run 5 hits 838ms → beat swap keeps vchain cached → loop 4 iters (score 8.31→6.86, deltas clamped at vocalPres +9 policy edge) → deck render via pedalboard.Reverb → full-cache re-run 94ms → config corruption serves defaults + .bak → SSE frames delivered → cancel→cancelled state
- Browser E2E: workflow strip QC PASSED v8 with 5 green gates; Run Mix Loop click → v9 committed, lineage "9 VERSIONS · A/B LEVEL-MATCHED"; auto-loop from UI (3 iters, best v12); A/B v3 attenuates to 0.562 (=10^(-5/20) vs -15.8 floor); mobile 390px no overflow; tsc + eslint clean

Stage Summary:
- All five review bugs fixed and verified; security hardening applied (protocol whitelist, cwd-only executable roots, rate limits, quiet prisma, gitignore)
- All seven missing components shipped in honest form: immutable MixVersion lineage with receipt linkage, workflow gates computed from measured audio, persisted job runner with SSE progress/cancel, deterministic closed-loop controller with regression guard, record-over-beat alignment (adelay), real DSP (pedalboard host + two-pass loudnorm), lifecycle pruning
- DECLARED stays DECLARED: matchering, stem separation, sound-system-modeler/sampleslide (placeholders, need env), multi-worker chain (concurrency=1 documented); auth still out of scope (single-operator machine, rate limits only)
- Artifacts: src/lib/{cache,rate-limit,loudnorm,analyzer,workflow,jobs,job-handlers,loop,pedalboard}.ts (new), pipeline/mix/session/dsp-adapter/studio-config/ffmpeg rewrites, prisma schema + db push, /api/{jobs,jobs/[id],jobs/[id]/stream,loop,versions,workflow} (new), db/dsp/pedalboard-host.py, control-plane.tsx UI, store/vvu.ts types
