# POOLS.md — Ubuntu Pools (Fire)

> Collective savings pools. Members contribute on a schedule; payouts rotate.

## Purpose
Enable founder-aligned cooperative savings ("stokvel" model) for VVU · STUDIO
members. A pool has N members; each round, one member receives the pooled
contribution. Transparent, on-chain-style ledger but stored in the platform
database.

## Key features
- Create a pool (founder/admin only) with a name, contribution amount,
  cadence (weekly/monthly), and size.
- Invite members by email; auto-join on accept.
- Track contributions per round; advance the active recipient each cycle.
- Payout ledger (immutable append-only).
- Visibility: pool members see real-time progress; non-members see only
  public metadata.
- Notifications (email + in-app) on round rollover.

## API endpoints (planned)
- `GET    /api/pools`                  — list public + member pools
- `POST   /api/pools`                  — create pool (admin)
- `GET    /api/pools/:id`              — pool detail + ledger
- `POST   /api/pools/:id/members`      — join / invite
- `DELETE /api/pools/:id/members/:uid` — leave / remove
- `POST   /api/pools/:id/contribute`   — record a contribution
- `POST   /api/pools/:id/advance`      — advance to next recipient (admin/cron)

## Data models (planned)
```
model Pool {
  id                String   @id @default(cuid())
  name              String
  description       String?
  contributionZAR   Int
  cadence           String   // "WEEKLY" | "MONTHLY"
  size              Int      // target member count
  currentRound      Int      @default(0)
  status            String   @default("OPEN") // OPEN | ACTIVE | CLOSED
  createdBy         String
  createdAt         DateTime @default(now())
  members           PoolMember[]
  contributions     Contribution[]
  payouts           Payout[]
}

model PoolMember {
  id        String   @id @default(cuid())
  poolId    String
  userId    String
  order     Int      // payout position (1..N)
  joinedAt  DateTime @default(now())
  @@unique([poolId, userId])
}

model Contribution {
  id        String   @id @default(cuid())
  poolId    String
  userId    String
  round     Int
  amountZAR Int
  paidAt    DateTime @default(now())
  @@unique([poolId, userId, round])
}

model Payout {
  id        String   @id @default(cuid())
  poolId    String
  userId    String
  round     Int
  amountZAR Int
  paidAt    DateTime @default(now())
  @@unique([poolId, round])
}
```

## Deployment notes
- Pool advancement must be a cron job (Vercel Cron `0 0 * * 0` for weekly).
- All monetary values stored as integer cents (ZAR) — never float.
- Lock pool from edits once status moves from OPEN → ACTIVE.

## Status
- **Spec only.** Route stub at `/pools` will be implemented in a later
  session. Foundation work (auth + DB) is in place.
