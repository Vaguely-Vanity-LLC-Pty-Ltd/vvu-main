# PRESS.md — Publishing Library + Video Player

> Member-facing publishing surface: long-form papers, articles, and a video
> player (WATCH integration) for founder-produced content.

## Purpose
House the founder's publishing output — articles, papers, and videos. Members
browse by tag, search, and read/watch. VIP tier gets early access to new
releases.

## Key features
- Article list with rich markdown rendering + syntax highlighting.
- Papers (PDF viewer) with download links.
- Video library with an HTML5 player + chapter markers.
- Tag taxonomy + full-text search.
- Tier-gated content (VIP early access; PUBLIC after release window).
- Reading history + bookmarks (per user).
- SEO: server-rendered article pages with OpenGraph metadata.

## API endpoints (planned)
- `GET    /api/press/articles`               — list (paginated, filterable)
- `GET    /api/press/articles/:slug`         — single article
- `GET    /api/press/videos`                 — list
- `GET    /api/press/videos/:id`             — single video + chapters
- `POST   /api/press/bookmarks`             — bookmark article
- `DELETE /api/press/bookmarks/:id`         — remove bookmark
- `GET    /api/press/me/history`            — my reading history

## Data models (planned)
```
model Article {
  id          String   @id @default(cuid())
  slug        String   @unique
  title       String
  excerpt     String?
  body        String   // markdown
  tags        String   // comma-separated
  tier        String   @default("FREE")
  publishedAt DateTime?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

model Video {
  id          String   @id @default(cuid())
  slug        String   @unique
  title       String
  description String?
  hlsUrl      String   // m3u8
  durationSec Int
  tier        String   @default("FREE")
  publishedAt DateTime?
  chapters    VideoChapter[]
}

model VideoChapter {
  id        String   @id @default(cuid())
  videoId   String
  title     String
  startSec  Int
}

model Bookmark {
  id        String   @id @default(cuid())
  userId    String
  articleId String
  at        DateTime @default(now())
  @@unique([userId, articleId])
}
```

## Deployment notes
- Article body stored as markdown; rendered server-side with
  `react-markdown` + `react-syntax-highlighter`.
- Video served HLS from a CDN. The `hlsUrl` is the only thing stored.
- VIP gating: server returns 402 (Payment Required) for tier-restricted
  content; client shows an upgrade prompt.

## Status
- **Spec only.** Route stub at `/press` will be implemented in a later
  session.
