# ESTATE_AUDIT.md

Surface-by-surface map of the VVU Control codebase. Every file path below is real — it exists in `workspace-820761d5-6c91-499c-bff3-7b71e6ebff69/` today. Statuses are honest:

- **CONFIRMED** — real code, runs, has an E2E path in `worklog.md`
- **PARTIAL** — real code exists but the surface's stated purpose is incompletely covered
- **DECLARED** — folder/concept exists in the README, no implementation
- **EMPTY** — no code

---

## auth/ — CONFIRMED

Authentication & access. The gate that lets a second human in without re-architecting the engine.

### Files

| Path | Role | Load-bearing |
|---|---|---|
| `src/lib/auth.ts` | NextAuth v4 config. GitHub OAuth. Email allowlist (`AUTHORIZED_EMAILS`). Fail-closed: empty allowlist = no one signs in. | YES |
| `middleware.ts` | Single gate for all routes — `/api/auth/*` and `/login` whitelisted, everything else requires a session. | YES |
| `src/app/api/auth/[...nextauth]/route.ts` | NextAuth handler (GET + POST). | YES |
| `src/app/login/page.tsx` | Minimal sign-in surface. GitHub button only. | no |
| `src/app/layout.tsx` | Wraps children in `<SessionProvider>`. | YES |
| `.env.example` | Documents `NEXTAUTH_SECRET`, `NEXTAUTH_URL`, `GITHUB_ID`, `GITHUB_SECRET`, `AUTHORIZED_EMAILS`. | no |

### Honest gaps

- **No `User` model in Prisma.** The inherited README says "User model managed through Prisma" — that's aspirational. NextAuth uses JWT sessions; there is no users table. Add one when the second user lands.
- **No credentials provider.** README says "credentials-based login support" — not implemented. GitHub OAuth only.
- **No roles / orgs / per-route policies.** Middleware is binary: signed in or not. The moment you need roles, move to NextAuth v5 + a User table.

---

## control-plane/ — CONFIRMED

The app shell. Five views on one page: FILES · TERM · EDITOR · AGENT · WATCH. SAST clock, status badges, the bottom nav.

### Files

| Path | Role | Load-bearing |
|---|---|---|
| `src/app/page.tsx` | Shell. Bottom nav, SAST clock (`Africa/Johannesburg`), 15s receipts poll. | YES |
| `src/components/vvu/control-plane.tsx` | 1498 LOC — the largest file. Workflow strip, mix-loop panel, version lineage table, A/B level-matched compare, record-over-beat. | YES |
| `src/store/vvu.ts` | Zustand store. View state, session, studio config. | YES |
| `src/lib/client-api.ts` | Client-side fetchers used by the store. | no |
| `src/hooks/*` | React hooks (2 files). | no |
| `src/app/api/route.ts` | Root API — health check. | no |

### Sub-surface: EDITOR (studio deck)

The EDITOR view hosts the mastering interface. These files are the operator surface.

| Path | Role | Load-bearing |
|---|---|---|
| `src/components/studio/studio-deck.tsx` | Transport, record arm, knob bank, stage log. | YES |
| `src/components/studio/knob.tsx` | SVG rotary knob. Drag/keyboard/dblclick-reset. | YES |
| `src/components/studio/waveform.tsx` | Canvas scope. Fetch → decode → 180 RMS buckets. Shared `AudioContext`. | YES |
| `src/components/studio/agent-panel.tsx` | SEARM chat surface. Knob actions apply live. | no |
| `src/lib/pipeline.ts` | The render engine. Content-addressed stages. | YES (own it) |
| `src/lib/cache.ts` | `produceCacheFile` — atomic `.part` → rename, in-flight lease map. | YES |
| `src/lib/ffmpeg.ts` | `ffmpegSafe` — `-protocol_whitelist file,pipe` on every spawn. | YES |
| `src/lib/loudnorm.ts` | Two-pass loudnorm measure→apply, single-pass fallback. | YES |
| `src/lib/pedalboard.ts` | Python bridge for the `space` stage. Honest `aecho` fallback. | no |
| `src/lib/knobs.ts` | Bounds, steps, house presets. Agent actions clamped here. | YES |
| `src/lib/mix-knobs.ts` | Mix-loop knob policy. | no |
| `src/lib/mix.ts` | Mix-loop engine. vchain on vocal bytes only. MixVersion commit. | YES |
| `src/lib/session.ts` | Record-over-beat. `vocalOffsetMs` persistence. Take rows. | no |
| `src/lib/types.ts` | Shared contracts (`KnobSettings`, `StageResult`, etc.). | YES |
| API routes | `/api/render`, `/api/mix`, `/api/session/[track]`, `/api/session/status`, `/api/audio/[id]`, `/api/capture/synth`, `/api/loop`, `/api/versions`, `/api/runs`, `/api/plugins`, `/api/lyrics`, `/api/export` | mixed |

### Honest gaps

- The header still shows `VERIFIED` and `FIRE PROVEN` badges. Pull them until externally attestable.
- No mobile-specific layout work beyond what Tailwind responsive classes give you for free.

---

## safes/ — CONFIRMED

Secure storage & vault operations. The hash chain is the vault; the audio directories are the strongrooms.

### Files

| Path | Role | Load-bearing |
|---|---|---|
| `src/lib/chain.ts` | Append-only SHA-256 hash chain. `appendRecord`, `tailRecord`, `provenance()` (the verifier). | YES (own it) |
| `db/audio/` | Final masters vault. | YES |
| `db/cache/` | Per-stage render cache, content-addressed. | YES |
| `db/capture/` | Raw microphone takes before normalisation. | YES |
| `db/session/` | Session state. | no |
| Prisma `TwinRecord` | The chain itself — `n`, `kind`, `tier`, `source`, `data`, `t`, `prev`, `h`. | YES |
| Prisma `RenderCache` | Per-stage cache rows keyed by content hash. | YES |
| Prisma `RenderRun` | One row per full pipeline pass — the terminal receipt. | YES |
| API `/api/receipts` | Chain tail + recent records + provenance verdict. | no |

### Honest gaps

- No encryption at rest. SQLite file is plaintext. Fine for N=1; not fine when a second operator's work is in the same DB.
- No backup automation. `db/` is one `rm -rf` from gone.
- No retention policy beyond `workflow.ts::pruneStorage` (512 MB LRU on cache, keep-N on vault).

---

## validation/ — CONFIRMED

Verification workflows. The oracle boundary. The one invariant that lets the rest of the system be honest.

### Files

| Path | Role | Load-bearing |
|---|---|---|
| `src/lib/chain.ts::provenance()` | The verifier. Recomputes every hash; returns `INCONCLUSIVE` by design. Never returns `VERIFIED`. Never authorises execution. | YES (own it) |
| `src/lib/twin.ts` (T02 node) | `oracle boundary` node — hardcoded `CONFIRMED` because the check is "does the verifier refuse to return VERIFIED?" — and it does, by design. | YES |
| `src/components/vvu/trust-sphere.tsx` | The WATCH view. Visualises the chain verdict. | no |
| API `/api/twin` | Serves the graph including the oracle node + verdict. | no |

### Honest gaps

- **No external attestation path.** `VERIFIED` is unreachable. That's correct by design — but it means the system can never make a stronger claim than `INCONCLUSIVE` without external input. When you want real `VERIFIED`, you need a second machine signing receipts.
- **No revocation.** A receipt, once appended, is permanent. There's no "mark this receipt as disputed" flow.

---

## field/ — CONFIRMED

Infrastructure monitoring. The architecture twin — a live-verified graph of the engine, status computed from runtime checks.

### Files

| Path | Role | Load-bearing |
|---|---|---|
| `src/lib/twin.ts::buildTwin()` | Builds the graph. Every node's `status` is a function of real checks (file existence, CLI tools, db, writability, chain integrity). Never declared by hand. | YES (own it) |
| `src/lib/pipeline.ts::detectTools()` | `ffmpeg -version`, `ffprobe -version` probes. | YES |
| `src/lib/pipeline.ts::writable()` | Write-probe for cache/vault/capture dirs. | YES |
| `src/components/vvu/vvu-twin.tsx` | Twin viewer UI. | no |
| `src/components/studio/twin-graph.tsx` | SVG pan/zoom graph + dossier. | no |
| `src/lib/vvu.ts` | Estate/cluster composition logic (14 KB). | no |
| API `/api/twin`, `/api/vvu-graph` | Twin data endpoints. | no |

### Honest gaps

- Twin nodes are static declarations in `twin.ts`. Adding a new component means editing the file. No manifest-driven discovery yet.
- No historical twin snapshots — the graph is always "now." No way to ask "what was the twin at 14:00 yesterday?"

---

## forge/ — CONFIRMED

Build / integration environment. The DSP adapter contract — where external tools are declared, preflight-checked, spawned, and validated.

### Files

| Path | Role | Load-bearing |
|---|---|---|
| `src/lib/dsp-adapter.ts` | Fail-closed executor. 11 named failure codes. Preflight chain. `shell: false`. Minimal env. Atomic promote. `preserveInput` stat-snapshot. | YES (own it) |
| `src/lib/studio-config.ts` | Zod v4 manifest loader. `{{VAR}}` placeholder resolver (fail-closed). 3s TTL. Corrupt file → `.bak` + default. | YES |
| `db/studio.config.json` | The manifest. Two declared stages (`sound-system-modeler`, `sampleslide`), both `enabled: false` by default. | YES |
| `db/dsp/contract-shim.mjs` | Test harness executable — clearly labeled, not a real tool. | no |
| `db/dsp/pedalboard-host.py` | Python bridge for Pedalboard. JUCE workarounds documented in worklog. | no |
| `src/lib/pedalboard.ts` | Node-side wrapper for the Python host. | no |
| API `/api/studio-config` | GET = config + live per-stage report. PATCH = enable/disable + timeout. | no |

### Honest gaps

- Only one `allowedExecutableRoots` (`cwd`) by default. Adding a real external tool requires editing the manifest AND vouching for its install path.
- No signed-binary verification. The preflight checks the executable bit, not a signature.

---

## pools/ — CONFIRMED

Pooled operations. The job queue, the closed-loop controller, the rate limiter, the storage pruner.

### Files

| Path | Role | Load-bearing |
|---|---|---|
| `src/lib/jobs.ts` | Persisted job runner. Concurrency 1 (SQLite single-writer). Crash-recovery marks stale `running` rows `error`. Cooperative cancel. | YES |
| `src/lib/job-handlers.ts` | Handler dispatch by `kind`. | no |
| `src/lib/loop.ts` | Closed-loop controller. Deterministic deltas from measured LUFS/true-peak/clipping/vocal-beat. Regression guard. Budget 1–6. | YES |
| `src/lib/workflow.ts` | State machine (`EMPTY→CAPTURED→MIXED→QC_PASS|QC_FAIL`). `pruneStorage` — 512 MB LRU on cache, keep-N on vault, stray `.part` sweep. | YES |
| `src/lib/analyzer.ts` | ebur128 (I/LRA/true-peak) + astats (RMS/peak/trough) + levelMatchGain. | YES |
| `src/lib/rate-limit.ts` | Per-IP token bucket. 6 capacity, 0.25/s refill. Applied to all mutating routes. | YES |
| API `/api/jobs`, `/api/jobs/[id]`, `/api/jobs/[id]/stream` | SSE 600 ms snapshots. Cancel via DELETE. | no |
| API `/api/workflow` | State + gates + next action. | no |
| Prisma `Job` | The queue table. `state`, `progress`, `stageLabel`, `cancelRequested`, timestamps. | YES |

### Honest gaps

- **Concurrency is hardcoded to 1.** Correct for SQLite + single-receipt-chain; wrong the moment you add Postgres + multiple workers.
- **No priority queue.** Jobs are FIFO. A long render blocks a quick capture.
- **No retries at the job level.** A failed job stays `error` until manually re-queued.

---

## press/ — PARTIAL

Publishing & media. The lyrics corpus and the SEARM persona. No publishing flow.

### Files

| Path | Role | Load-bearing |
|---|---|---|
| `src/lib/lyrics.ts` | Four founder lyric sheets (To How It Came, Hell is Hot, Change, Chasing Dreams). Sectioned. The only text the agent may analyse as founder work. | no |
| `src/lib/persona.ts` | SEARM persona. `buildSystemPrompt`, `buildMixSystemPrompt`, `fallbackReply`, `PERSONA_ID`. | no |
| API `/api/lyrics` | GET corpus. | no |
| API `/api/agent` | LLM boundary. Persona + lyrics in, strict-JSON actions out. Uses `z-ai-web-dev-sdk`. | no |
| Prisma `AgentMessage` | Chat history. | no |

### Honest gaps

- **No public-facing media surface.** Lyrics are private input to the agent, not published content.
- **No publishing workflow.** No draft/schedule/release flow. No public URL for any lyric.
- **No media hosting.** No image, no video, no audio streaming for public consumption.

If `press/` is meant to be a real publishing surface, it needs ~3 weeks of work. If it's meant to be "the agent's content substrate," rename it.

---

## bench/ — PARTIAL

Asset registry. The Take table and the files view. No project-level browse, no search, no tagging.

### Files

| Path | Role | Load-bearing |
|---|---|---|
| `src/components/vvu/files-view.tsx` | FILES view. Lists captures, masters, cache entries. | no |
| Prisma `Take` | One row per uploaded/recorded source. `kind`, `name`, `rawPath`, `wavPath`, `sha256`, `bytes`, `durationS`, `offsetMs`. | YES |
| Prisma `Project` | Top-level project. `name` unique. | no |
| Prisma `MixVersion` | Immutable snapshot — input hashes, knobs, stages, metrics, output, parent lineage. | YES |

### Honest gaps

- **No project browse UI.** The `Project` model exists but there's no page that lists projects.
- **No search.** Files are listed flat.
- **No tagging, no metadata editing.** A `Take` has `name` and `kind` and that's it.
- **No version comparison beyond A/B level-matched.** Can't diff two MixVersions knob-by-knob in the UI.

---

## store/ — EMPTY

Commerce. No code.

### Honest gaps

Everything. There is no `store/` surface. The README's "Digital commerce and marketplace components" line is fiction. If you want this surface, it's greenfield — start with a `Product` model and a checkout flow. Don't pretend it's there.

---

## mini-services/ — EMPTY

`.gitkeep` only. The README's "Lightweight service modules" line is fiction.

---

## examples/ — PARTIAL

### Files

| Path | Role |
|---|---|
| `examples/websocket/frontend.tsx` | Socket.io client reference. Missing `socket.io-client` dep. |
| `examples/websocket/server.ts` | Socket.io server reference. Missing `socket.io` dep. |

### Honest gaps

Doesn't compile (4 tsc errors, all in this directory). Either install the deps and finish the example, or delete it.

---

## prisma/ — CONFIRMED (the data spine)

### Files

| Path | Role |
|---|---|
| `prisma/schema.prisma` | 132 lines. 8 models. |
| `db/custom.db` | SQLite database file (311 KB). |

### Models

- `RenderCache` — per-stage output, keyed by content hash
- `RenderRun` — one row per full pipeline pass
- `TwinRecord` — append-only SHA-256 chain
- `AgentMessage` — SEARM chat history
- `Project` → `MixVersion` — version lineage (self-relation)
- `Take` — uploaded/recorded sources
- `Job` — persisted queue

### Honest gaps

- **No `User` model.** Auth uses JWT, no users table.
- **No migrations.** Schema is applied via `db:push` (destructive). Add `db:migrate` to the workflow before the second user lands.
- **SQLite only.** Postgres is "intended for deployment" per the README but no schema portability has been tested.

---

## Cross-cutting: what's load-bearing

Three files in the codebase are load-bearing — a subagent rewriting them would silently break the product. **You must own these line-by-line.**

1. `src/lib/pipeline.ts` (552 LOC) — the render engine
2. `src/lib/twin.ts` (451 LOC) — the architecture graph
3. `src/lib/dsp-adapter.ts` (584 LOC) — the external-stage executor

See `/home/z/my-project/download/load-bearing-code-walkthrough.md` for the per-file teaching doc.

---

## The 14-day move, restated

1. Pick one external user (a producer in PE or online).
2. Add them to `AUTHORIZED_EMAILS`.
3. Deploy to a public URL (Caddyfile is already there).
4. Watch what breaks.
5. Fix only what broke. Don't touch the surfaces that didn't get used.
