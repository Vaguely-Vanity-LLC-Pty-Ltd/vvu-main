# STORE.md — E-commerce + Subscriptions

> Sell products and subscription tiers. Checkout via ProofBridge.

## Purpose
The commercial surface of VVU · STUDIO: subscription tiers (Supporter R49,
Super Fan R99, VIP R249), one-time products, cart, checkout, order history.

## Key features
- Three subscription tiers with monthly billing.
- Product catalog with images, descriptions, stock levels.
- Cart (Zustand client state, persisted to localStorage).
- Checkout via ProofBridge (server-side handoff; webhook confirms).
- Order history + invoice download (PDF).
- Tier upgrade / downgrade / cancellation.
- Coupon codes (% off, fixed off, free trial).

## API endpoints (planned)
- `GET    /api/store/products`               — catalog
- `GET    /api/store/products/:id`           — detail
- `GET    /api/store/tiers`                  — subscription tiers
- `POST   /api/store/checkout`               — create ProofBridge session
- `POST   /api/store/webhook`                — ProofBridge webhook (no auth, signature-verified)
- `GET    /api/store/orders/me`              — my orders
- `POST   /api/store/subscriptions/upgrade`  — change tier
- `POST   /api/store/subscriptions/cancel`   — cancel

## Data models (planned)
```
model Product {
  id          String   @id @default(cuid())
  slug        String   @unique
  name        String
  description String?
  priceZAR    Int
  stock       Int      @default(0)
  imageUrl    String?
  active      Boolean  @default(true)
}

model SubscriptionTier {
  id          String   @id  @default(cuid())
  code        String   @unique  // SUPPORTER | SUPER_FAN | VIP
  name        String
  priceZAR    Int      // monthly
  description String?
  perks       String   // JSON
}

model Order {
  id          String   @id @default(cuid())
  userId      String
  totalZAR    Int
  status      String   // PENDING | PAID | FULFILLED | REFUNDED
  items       OrderItem[]
  createdAt   DateTime @default(now())
}

model OrderItem {
  id        String   @id @default(cuid())
  orderId   String
  productId String?
  tierCode  String?
  name      String
  priceZAR  Int
  qty       Int      @default(1)
}

model Subscription {
  id        String   @id @default(cuid())
  userId    String
  tierCode  String
  status    String   @default("ACTIVE") // ACTIVE | CANCELLED | PAST_DUE
  startedAt DateTime @default(now())
  endsAt    DateTime?
}
```

## Deployment notes
- All monetary values are integer cents (ZAR).
- ProofBridge webhook must verify the signature header; reject on mismatch.
- Tier upgrades are prorated automatically; downgrades take effect at the next
  billing cycle.
- Coupons live in a separate model with usage counters.

## Status
- **Spec only.** Route stub at `/store` will be implemented in a later
  session.
