# AUTH.md — Authentication

> Real NextAuth.js v4 — GitHub OAuth + credentials provider. Not a stub.

## Purpose
Provide secure, production-grade authentication for VVU · STUDIO: sign-up,
sign-in, sign-out, session persistence, protected routes, and role-based
authorization. Sessions must work in Vercel serverless (no DB-backed session
storage required for hot path).

## Key features
- **GitHub OAuth** — one-click sign-in / sign-up. `allowDangerousEmailAccountLinking`
  is enabled so a credentials user with the same email can later sign in via
  GitHub (and vice versa) without a "duplicate account" error.
- **Credentials provider** — email + bcrypt-hashed password. 12 rounds.
- **JWT session strategy** — works on Vercel edge/serverless without a session
  DB. The JWT carries `id`, `role`, `subscriptionTier`.
- **Role & tier injection** — `jwt` callback hydrates the token from the DB on
  first sign-in; `session` callback exposes role/tier to the client.
- **Protected routes** — `src/middleware.ts` (withAuth) gates `/dashboard/*`.
- **Sign-up flow** — `POST /api/auth/register` creates the user, then the
  client immediately calls `signIn("credentials")` to start a session.

## API endpoints
- `GET  /api/auth/[...nextauth]`           — NextAuth handler
- `POST /api/auth/[...nextauth]`           — NextAuth handler
- `POST /api/auth/register`                — credentials sign-up
- `POST /api/auth/callback/credentials`    — internal (NextAuth)
- `POST /api/auth/signout`                 — internal (NextAuth)

## Pages
- `/sign-in`   — GitHub button + credentials form
- `/sign-up`   — credentials form
- `/sign-out`  — sign-out confirmation

## Data models
- `User.hashedPassword` — bcrypt hash, null for OAuth-only users
- `Account`             — OAuth linkage (provider, providerAccountId, tokens)
- `Session`             — unused under JWT strategy, kept for forward-compat
- `VerificationToken`   — email verification flow (future)

## Configuration
- `src/lib/auth-options.ts` — NextAuth options (providers, callbacks, pages)
- `src/lib/auth.ts`         — handler wrapper
- `src/middleware.ts`       — `withAuth({ pages: { signIn: "/sign-in" } })`
- `src/types/next-auth.d.ts` — type augmentation for `session.user.role/tier`

## Environment variables (`.env`, gitignored)
```
NEXTAUTH_SECRET=<openssl rand -base64 32>
NEXTAUTH_URL=http://localhost:3000
GITHUB_CLIENT_ID=<github oauth app client id>
GITHUB_CLIENT_SECRET=<github oauth app client secret>
```

## Deployment notes
- On Vercel, set `NEXTAUTH_URL` to the production URL (e.g.
  `https://vvu-control.space-z.ai`).
- Rotate `NEXTAUTH_SECRET` only with a coordinated re-deploy — JWTs signed with
  the old secret become invalid.
- For Postgres production, change `datasource.db.provider` to `"postgresql"`
  and supply a `DATABASE_URL` with `?schema=public`. The schema already
  avoids SQLite-only types (no `BigInt`, no native enums).

## Status
- **Foundation complete.** Real GitHub OAuth requires the founder to create a
  GitHub OAuth App and fill `GITHUB_CLIENT_ID` / `GITHUB_CLIENT_SECRET` in
  `.env`. Credentials provider is fully functional today.
