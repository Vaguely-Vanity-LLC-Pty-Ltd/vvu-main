# VVU Inference Gateway — Architecture

> **Bind 5 world-class scientific Foundation Models to the WORM Ledger.**
> Epistemic Humility enforced — models are Distributed Oracles. They observe, they never assert tier.

**Status:** IMPLEMENTED · COMMITTED · LIVE on dev server
**Commit:** `f94a7b0 feat: VVU Inference Gateway — 5 Foundation Models + WORM Ledger + Model Registry UI`
**Document version:** 1.0

---

## 1. Purpose

The VVU Inference Gateway is Python middleware that sits between **raw sensor / satellite data** and the **immutable WORM (Write Once, Read Many) proof ledger**. It orchestrates five Foundation Models, each chosen for a specific epistemic job, and refuses to emit a tier claim that the evidence cannot support.

It is the embodiment of the VVU doctrine:

> *Fire never emits PROVEN. Models never assert tier. Inference outputs are gated by the Epistemic Runtime before entering the WORM ledger.*

---

## 2. The 5 Foundation Models

| # | Model | Class | Job | Source / Authority | Threshold | Epistemic Behavior |
|---|-------|-------|-----|--------------------|-----------|--------------------|
| 1 | **DTC** — Digital Twin Catalog | Visual | Photorealistic 3D mesh retrieval (±0.005 mm tolerance) | Meta AI · 2 000-object dataset | 0.90 confidence | Fail-closed → `BLOCKED_MISSING_INPUT` if no match |
| 2 | **Prithvi-EO-2.0-600M** | Macro | Flood / wildfire / crop / biomass prediction from satellite time-series | NASA + IBM · 600M params · 4.2M samples (Landsat/Sentinel-2) | 0.85 flood probability | `PROVEN` + `TRIGGER_EVACUATION_ALERT` above threshold |
| 3 | **MSFMamba-Tiny** | Tactical | Fuse HSI + LiDAR + SAR; distinguish human intruder vs animal/noise at 60 FPS edge | State Space Model · 40M params · linear complexity | 0.95 confidence | `INCONCLUSIVE` + `AWAITING_CORROBORATION` below threshold |
| 4 | **IRIDE NIMBUS (DInSAR)** | Structural | mm-level structural deformation from orbital SAR constellation | IRIDE constellation · dual-gate with IoT corroboration | 1.5 mm displacement | `INCONCLUSIVE` + `MANUAL_VERIFICATION_REQUIRED` on sensor divergence |
| 5 | **Vision Foundation Models Survey** | Registry | Tech radar / benchmark catalogue (SatMAE, Scale-MAE, DOFA…) | Survey model — interchangeable tools | n/a | Benchmarked via the Watch evidence ledger |

### The Epistemic Humility rule (worked example)

Satellite (DInSAR) reports **2.6 mm** displacement on Pillar B9.
IoT strain gauge on the same pillar reports **0.1 mm**.

```
displacement (2.6)  ≥  threshold (1.5)        → anomaly detected
|2.6 − 0.1| = 2.5  ≥  0.5                     → SENSOR DIVERGENCE
→ status   = INCONCLUSIVE
→ action   = MANUAL_VERIFICATION_REQUIRED
→ reason   = SENSOR_DIVERGENCE
```

The system **never guesses**. It escalates.

---

## 3. WORM Ledger Binding

Every inference is:

1. **Canonicalised** — `json.dumps(payload, separators=(",",":"), sort_keys=True)`
2. **SHA-256 hashed** — `hashlib.sha256(canonical_json).hexdigest()`
3. **Appended** to `/opt/vvu/data/vvu_worm_ledger.jsonl` (append-only, flushed)

Ledger block shape:

```json
{
  "timestamp": 1698422400.0,
  "event_type": "STRUCTURAL_ANOMALY",
  "status": "INCONCLUSIVE",
  "hash": "a1b2c3d4…",
  "payload": {
    "pillar": "Pillar_B9",
    "model": "IRIDE-NIMBUS-DInSAR",
    "displacement_mm": 2.6,
    "iot_corroboration_mm": 0.1
  }
}
```

Because the file is append-only and every block carries its own hash, the ledger is replayable — historical proofs remain permanently interpretable (Constitutional Epochs, Article IV).

---

## 4. Component Map

```
                        ┌─────────────────────────────┐
   raw sensors ───────▶ │   VVU Inference Gateway     │
   satellite tiles      │   (Python · opt/vvu/bin/)   │
   optical / SAR frames └──────────────┬──────────────┘
                                       │  SHA-256 hash
                                       │  + epistemic verdict
                                       ▼
                        ┌─────────────────────────────┐
                        │   WORM Ledger (.jsonl)      │  ◀── append-only
                        └──────────────┬──────────────┘
                                       │
                                       ▼
                        ┌─────────────────────────────┐
                        │   Epistemic Runtime Kernel   │  ◀── 7 primitives
                        │   (two-gate execute)         │      Identity → … → Proof
                        └──────────────┬──────────────┘
                                       │
                          ┌────────────┴────────────┐
                          ▼                         ▼
                  PRESS (publish)          FIRE (ZAR ledger)
                  methodology +            constitutionally-gated
                  evidence hashes          execution
```

---

## 5. File Inventory (clickable in the preview panel)

| Artifact | Path | Purpose |
|----------|------|---------|
| Python gateway | `opt/vvu/bin/vvu_inference_gateway.py` | The middleware (114 lines) |
| Model Registry UI | `src/components/vvu-studio/views/InferenceGatewayView.tsx` | The surface you press to verify |
| API — list + logs | `src/app/api/inference/route.ts` | `GET /api/inference` |
| API — toggle | `src/app/api/inference/[modelId]/toggle/route.ts` | `PATCH` enable/disable |
| API — threshold | `src/app/api/inference/[modelId]/threshold/route.ts` | `PATCH` + `POST` (run) |
| Seed data | `src/lib/seed-inference.ts` | 5 models seeded |
| Prisma schema | `prisma/schema.prisma` | `InferenceModel` + `InferenceLog` |
| Route registry | `src/lib/vvu-studio/routes.ts` (line 71) | `#/inference` |
| This document | `public/docs/VVU-INFERENCE-GATEWAY-ARCHITECTURE.md` | Architecture output |

---

## 6. How to verify (the proof you can press)

1. **Open the app** in the Preview Panel → it loads at `/`.
2. Press **Ctrl + K** → type `inference` → Enter. **OR** append `#/inference` to the URL.
3. You will see:
   - Heading: **"VVU Inference Gateway · Model Registry · WORM Ledger · Epistemic Humility"**
   - **5 model cards**: Prithvi-EO-2.0, Vision FM Survey, MSFMamba, DTC, IRIDE-NIMBUS-DInSAR
   - Each card: toggle, description, threshold editor, **Run Inference** button
   - **WORM Inference Log** feed (empty until you run one)
   - **Epistemic Humility** banner
   - Footer line: `opt/vvu/bin/vvu_inference_gateway.py · Tier 2 Local Anchor`
4. Toggle a model **ON** → press **Run Inference** → a SHA-256-hashed, model-versioned entry appears in the WORM log with a status of `PROVEN`, `INCONCLUSIVE`, or `BLOCKED`.
5. To read the Python source itself: open `opt/vvu/bin/vvu_inference_gateway.py` in the repo.

---

## 7. What is NOT yet done (honest gaps)

- **GitHub push to `divhanimajokweni-ctrl/vvu-control`** — the local repo has **no remote configured** (`git remote -v` is empty). The commit `f94a7b0` exists locally only. Pushing requires a GitHub token / SSH key from the founder.
- **Vercel deployment of this round** — not re-deployed this round. Previous rounds deployed to a temporary Vercel URL.
- **Live hardware ingest** — the gateway currently runs **simulated** inference (randomised within epistemic bounds). Real sensor adapters (Sentinel-2 API, IRIDE archive, edge camera frames) are the next integration.

---

## 8. Constitutional compliance

- ✅ Models never assert tier — `PROVEN` here means "model verdict is PROVEN", **not** an Epistemic Runtime tier.
- ✅ Two-Gate Execution Rule respected — inference output must still pass the Epistemic gate + Constitutional gate before any action.
- ✅ Article I §1.3 invariant untouched — `vote=PASS + proof=FAIL + authorization=EXECUTE → REJECTED` still enforced at machine level.
- ✅ WORM ledger is append-only and replayable.

*Generated for the VVU · STUDIO founder. Press `#/inference` to verify.*
