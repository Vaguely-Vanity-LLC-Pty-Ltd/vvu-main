# FEEDBACK.md — explicit asks from the founder's UI screenshots

Two screenshots were uploaded with red annotations. These are not
suggestions — they are explicit feature asks. Capture them verbatim,
don't paraphrase.

---

## Screenshot 1 — `screenshots/01-control-plane-with-annotations.png`

Shows the VVU STUDIO control panel running in a VS Code-style IDE.
Top stats: receipts 1, funding in flight R284,900.00, online devices
4/5, catalog 5 items. Site Protection Bundle R12,405.36 (save 12%).
Five estates visible: Forge, Bench, Fire, Field, Press. Multiple
surface cards (digital twin, water quality, keyboard mapping, etc.).
VVU agent chat panel on the right; terminal at the bottom.

### Red annotation (verbatim)

> 数字孪生、地图与地理空间瓦片、Fluid Studio、Watchdog、EIS 等
> 应设置图标快捷方式，点击后直接跳转对应页面

### Translation

> Digital Twin, Maps & Geospatial Tiles, Fluid Studio, Watchdog, EIS,
> etc. should have icon shortcuts — clicking them jumps directly to
> the corresponding page.

### What this means in code

The five estates (Forge, Bench, Fire, Field, Press) currently exist
as folders with `.md` manifest files. The named items (Digital Twin,
Maps & Geospatial Tiles, Fluid Studio, Watchdog, EIS) are surface
cards visible in the UI but not yet backed by routes.

Action: add icon-bearing nav shortcuts in the dashboard surface
directory that link to real routes. Each named item becomes a
`(dashboard)/<slug>/page.tsx` with at minimum a stub page so the
link is not dead. Priority order matches the annotation:

1. `/digital-twin`     — Digital Twin
2. `/maps`             — Maps & Geospatial Tiles
3. `/fluid-studio`     — Fluid Studio
4. `/watchdog`         — Watchdog
5. `/eis`              — EIS (Epistemic Intelligence Specification)

Each gets a lucide-react icon in the dashboard nav.

---

## Screenshot 2 — `screenshots/02-trust-sphere-with-annotations.png`

Shows the Trust Sphere dashboard — ~420 colored dots in Fibonacci
distribution on a cream background. Status badges: RECONNECTING,
MRR R0.0K, BOOTING. Right panel: NETWORK HEALTH (ports 3000–3007
all DOWN), SLA 72H target 99.50%, TRUSTED NODES 19, DEVICE MESH
OFFLINE. Bottom: COUNT 420, QUESTION 141 UNANSWERED, MOI 70.68%.

### Red annotation (verbatim)

> HOW CAN WE HAVE MAPS WITHOUT A FULL GLOBAL MAPS OR BROADER ACTUALLY

### What this means in code

The Trust Sphere visualises 420 nodes as a Fibonacci scatter, but
there is no actual map. The founder is asking: where is the global
map? Where is the broader geospatial view? The dots are abstract;
they want them pinned to real geography.

Action: this is the `/maps` route from Screenshot 1, but with
teeth. The Trust Sphere's 420 nodes need a geographic projection —
not a Fibonacci scatter. Use a real world map (Leaflet + OSM tiles,
or d3-geo + a TopoJSON) and project each node by its declared
lat/long. Nodes without lat/long fall back to the Fibonacci ring
around the map's edge, clearly labeled as UNRESOLVED LOCATION.

This connects the two screenshots: the Trust Sphere's 420 nodes are
the same set that should appear on the global map. The map is the
broader view; the sphere is the abstract trust topology.

---

## Priority

These are not nice-to-haves. They are the founder pointing at the
screen and saying "this is missing." Do them before any other
surface work. The five routes from Screenshot 1 + the global map
from Screenshot 2 are the next six commits.
