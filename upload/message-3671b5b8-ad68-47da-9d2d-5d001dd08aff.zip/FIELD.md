# FIELD.md — Infrastructure Monitoring

> Real-time view of the platform's own infrastructure: uptime, response times,
> error rates, deploy history.

## Purpose
A small ops dashboard for the founder to see at-a-glance whether the platform
is healthy. Pulls data from Vercel, the gateway, and any mini-services.

## Key features
- Per-route response time sparklines (last 24h).
- Uptime checks (cron ping of public endpoints).
- Error rate (4xx / 5xx) per route.
- Vercel deploy timeline with status (READY / ERROR / BUILDING).
- Mini-services status (port + last-seen + uptime).
- Alert subscriptions (email when error rate > N% for M minutes).

## API endpoints (planned)
- `GET /api/field/metrics`     — response time + error rate summary
- `GET /api/field/uptime`      — uptime checks
- `GET /api/field/deploys`     — recent Vercel deployments
- `GET /api/field/services`    — mini-services status
- `WS  /?XTransformPort=3003`  — real-time metrics push (socket.io)

## Data models (planned)
```
model Metric {
  id         String   @id @default(cuid())
  route      String
  method     String
  status     Int
  durationMs Int
  at         DateTime @default(now())
}

model UptimeCheck {
  id        String   @id @default(cuid())
  url       String
  ok        Boolean
  latencyMs Int?
  at        DateTime @default(now())
}

model AlertSubscription {
  id        String   @id @default(cuid())
  userId    String
  email     String
  threshold Int      // error % (0..100)
  window    Int      // minutes
  createdAt DateTime @default(now())
}
```

## Deployment notes
- Real-time stream uses a socket.io mini-service on port 3003. The Next.js
  frontend connects via `io("/?XTransformPort=3003")` — never direct.
- Metrics are sampled (1/min per route) and pruned to 7 days.
- Vercel deploy state fetched via `GET /v6/deployments?projectId=…` with
  `VERCEL_TOKEN`.

## Status
- **Spec only.** Route stub at `/field` will be implemented in a later
  session. The gateway (`Caddyfile`) and mini-services layout are already in
  place from the foundation scaffold.
