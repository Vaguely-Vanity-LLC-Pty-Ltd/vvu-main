# JOB.md — VVU · STUDIO First-Principles Rebuild

> **This is the only instruction file. Everything else was wiped on purpose.**
> Backup of the previous state: `git checkout v-pre-wipe` or branch `backup/pre-wipe`.

---

## 1. Identity

**Project:** VVU · STUDIO — Founder-Owned Industrial Asset Protection Platform
**Founder:** divhanimajokweni-ctrl
**Repo:** https://github.com/divhanimajokweni-ctrl/vvu-control
**Deploy (Vercel):** https://my-project-vvu-org.vercel.app
**Deploy (alt):** https://my-project-three-alpha-26.vercel.app
**Custom domain (pending DNS):** vvu-control.space-z.ai
**Vercel team:** vvu-org (hobby plan)

## 2. Credentials

All tokens live in `.env` (gitignored, never committed). Current `.env`:
```
DATABASE_URL=file:/home/z/my-project/db/custom.db
```

**Tokens available from the founder (store in .env when needed):**
- `GITHUB_PAT_TOKEN` — GitHub Personal Access Token (repo scope). Regenerate at github.com/settings/tokens if revoked.
- `VERCEL_TOKEN` — Vercel API token (vcp_...). Used for deploys + domain management.
- `NEXTAUTH_SECRET` — generate with `openssl rand -base64 32`
- `NEXTAUTH_URL` — the deploy URL
- `GITHUB_CLIENT_ID` / `GITHUB_CLIENT_SECRET` — GitHub OAuth app for real auth
- `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` — Google OAuth (optional)

**Never commit tokens. Never put them in JOB.md. Always reference .env.**

## 3. The Job

Rebuild the entire platform from first principles. The previous version was built across 30+ rounds and worked in parts but was amateurish in others. This rebuild must be **enterprise-grade** — the same standards as GitHub, Cloudflare, and Vercel themselves use.

### Non-negotiable standards:
1. **Authentication must actually work.** Not a stub. Real NextAuth.js v4 with GitHub OAuth + credentials provider. Users can sign up, sign in, sign out. Sessions persist. Protected routes redirect to login.
2. **Every link must be verifiable and working.** No dead links. No "coming soon" placeholders.
3. **Every surface must be deployable.** `bun run build` must succeed. Vercel deploy must be READY.
4. **Enterprise UI standards.** Clean, professional, responsive, accessible. Dark mode. Sticky footer. No indigo/blue unless requested.
5. **Security.** Tokens in .env. No secrets in code. NextAuth session cookies. CSRF protection. Input validation with Zod.
6. **TypeScript strict.** No `any` unless absolutely necessary. No ignored build errors.

## 4. Folder Structure

Each surface is a folder. Each folder contains an `MD` file (the manifest/spec for that surface) plus its implementation. MD files are lightweight and carry the full knowledge needed to deploy.

```
/
├── .env                      # credentials (gitignored)
├── JOB.md                    # this file — the single instruction
├── package.json              # Next.js 16 + TypeScript 5 + Tailwind 4 + shadcn/ui
├── prisma/
│   └── schema.prisma         # database schema (Postgres for production)
├── src/
│   ├── app/                  # Next.js App Router
│   │   ├── (auth)/           # sign-in, sign-up, sign-out pages
│   │   ├── (dashboard)/      # protected dashboard routes
│   │   ├── api/              # API routes
│   │   └── layout.tsx        # root layout
│   ├── lib/
│   │   ├── auth.ts           # NextAuth config (REAL, not stub)
│   │   ├── db.ts             # Prisma client
│   │   └── validators.ts     # Zod schemas
│   └── components/           # React components
├── control-plane/            # MD manifest: the main dashboard spec
├── pools/                    # MD manifest: Ubuntu Pools (Fire)
├── safes/                    # MD manifest: secure storage / vault
├── validation/               # MD manifest: validation dashboard
├── forge/                    # MD manifest: study environment
├── bench/                    # MD manifest: asset registry
├── field/                    # MD manifest: infrastructure monitoring
├── press/                    # MD manifest: publishing
├── store/                    # MD manifest: e-commerce
└── auth/                     # MD manifest: authentication spec
```

## 5. Surfaces to Build (in priority order)

1. **Authentication** — NextAuth + GitHub OAuth + credentials. Real sign-up/sign-in/sign-out. User model in Prisma.
2. **Control Plane (Dashboard)** — the entry point. Shows the user's account, subscription status, API keys, and links to every surface.
3. **Subscriptions** — 3 tiers (Supporter R49, Super Fan R99, VIP R249). Users can subscribe and upgrade.
4. **API Keys** — users can generate/revoke access tokens for API access.
5. **Store** — e-commerce with products, cart, checkout (ProofBridge).
6. **Pools** — Ubuntu Pools (collective savings).
7. **Forge** — study environment.
8. **Bench** — asset registry.
9. **Field** — infrastructure monitoring.
10. **Press** — publishing library + video player (WATCH integration).
11. **Safes** — secure storage.
12. **Validation** — validation dashboard.

## 6. Tech Stack (non-negotiable)

- **Framework:** Next.js 16 with App Router
- **Language:** TypeScript 5 (strict)
- **Styling:** Tailwind CSS 4 + shadcn/ui (New York style)
- **Database:** Prisma ORM (SQLite for dev, Postgres for Vercel production)
- **Auth:** NextAuth.js v4 (GitHub OAuth + Credentials provider)
- **State:** Zustand (client) + TanStack Query (server)
- **Validation:** Zod
- **Icons:** Lucide React
- **AI:** z-ai-web-dev-sdk (backend only)

## 7. Deployment

- **Vercel** under the `vvu-org` team
- **GitHub** repo: divhanimajokweni-ctrl/vvu-control
- **Trigger builds** via Vercel Git Push API with `forceNew=1` (hobby plan concurrency limit)
- **Custom domain:** vvu-control.space-z.ai (needs DNS: TXT _vercel.space-z.ai + CNAME vvu-control.space-z.ai → cname.vercel-dns.com)

## 8. Process Rules (from the founder)

1. **Write the plan down first.** Before coding.
2. **Follow the plan to the letter.** No last-minute changes.
3. **After every task, check against the plan.**
4. **Grade yourself if you fail.**
5. **Do not mess it up.**

## 9. Rebuild Sequence

This is a multi-session effort. Each session:
1. Read JOB.md (this file)
2. Read the relevant surface MD manifest
3. Implement that surface
4. Lint
5. Verify locally (agent-browser)
6. Commit + push to GitHub
7. Trigger Vercel deploy + verify READY
8. Verify on live
9. Update JOB.md with progress
10. Check against plan. Grade.

### Session 1 (now): Foundation
- [x] Backup previous state
- [x] Create JOB.md
- [x] Wipe repo
- [ ] Scaffold Next.js 16 app
- [ ] Create folder structure with MD manifests
- [ ] Implement real authentication (NextAuth + GitHub OAuth)
- [ ] Deploy + verify

---

*Last updated: Session 1 — foundation*
*Status: IN PROGRESS*
