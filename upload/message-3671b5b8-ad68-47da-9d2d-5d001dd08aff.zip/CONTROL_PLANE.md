# CONTROL_PLANE.md — Control Plane (Dashboard)

> The founder-facing entrypoint to the entire VVU · STUDIO platform.

## Purpose
A single pane of glass showing account status, subscription tier, API access,
and links to every surface (Pools, Forge, Bench, Field, Press, Store, Safes,
Validation). This is what users land on after they sign in.

## Key features
- Account summary: name, email, role, subscription tier, member-since date.
- API key management (generate / rotate / revoke) with copy-to-clipboard.
- Surface directory: cards linking to every other module.
- Real-time session awareness (NextAuth `useSession`).
- Mobile-first responsive layout, dark-mode default.

## API endpoints
- `GET  /api`                              — liveness probe
- `POST /api/auth/register`                — credentials sign-up
- `POST /api/user/api-key`                 — generate / rotate API key
- `DELETE /api/user/api-key`               — revoke API key
- `GET  /api/auth/[...nextauth]`           — NextAuth handler (sign-in, sign-out, callbacks)

## Data models
- `User` — `id, email, name, image, role, subscriptionTier, apiKey, createdAt`
- `Account`, `Session`, `VerificationToken` — NextAuth standard
- Role enum: `FOUNDER | ADMIN | MEMBER | GUEST`
- Tier enum: `FREE | SUPPORTER | SUPER_FAN | VIP`

## Deployment notes
- Route group `(dashboard)` is gated by `src/middleware.ts` (`withAuth`).
  Unauthenticated requests are redirected to `/sign-in`.
- Page is a server component — uses `getSession()` from `@/lib/auth-options`
  to read the user, then hits Prisma directly. Avoid client-side data fetching
  for the initial render to keep TTFB fast.
- The dashboard is the default redirect target for authed users visiting `/`.

## Status
- **Foundation complete.** Surface cards link to stub routes — those routes
  will be implemented in subsequent sessions.
