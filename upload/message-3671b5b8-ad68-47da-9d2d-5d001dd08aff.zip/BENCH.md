# BENCH.md — Asset Registry

> Inventory of every physical and digital asset the platform manages or tracks.

## Purpose
A single registry for assets (devices, real estate, vehicles, contracts,
domains, software licenses). Each asset has an owner, status, location, and
optionally attaches to a Safe (for documents) or a Pool (for shared ownership).

## Key features
- Asset CRUD with rich metadata (custom fields per asset type).
- Asset types: DEVICE | REAL_ESTATE | VEHICLE | CONTRACT | DOMAIN | LICENSE | OTHER.
- Status lifecycle: REGISTERED → ACTIVE → MAINTENANCE → RETIRED.
- Attachments: link to SafeItem (encrypted documents) by reference.
- Bulk import / export (CSV).
- Full-text search + faceted filters (by type, status, owner).
- Audit trail: every change recorded with actor + timestamp.

## API endpoints (planned)
- `GET    /api/bench/assets`                 — list (with filters)
- `POST   /api/bench/assets`                 — create
- `GET    /api/bench/assets/:id`             — detail + audit trail
- `PATCH  /api/bench/assets/:id`             — update
- `DELETE /api/bench/assets/:id`             — soft-delete (status = RETIRED)
- `POST   /api/bench/assets/import`          — CSV import (admin)
- `GET    /api/bench/assets/export`          — CSV export

## Data models (planned)
```
model Asset {
  id         String   @id @default(cuid())
  type       String   // DEVICE | REAL_ESTATE | VEHICLE | …
  name       String
  status     String   @default("REGISTERED")
  ownerId    String
  location   String?
  metadata   String   // JSON blob
  safeItemId String?
  poolId     String?
  createdAt  DateTime @default(now())
  updatedAt  DateTime @updatedAt
  audit      AssetAudit[]
}

model AssetAudit {
  id        String   @id @default(cuid())
  assetId   String
  actorId   String
  action    String   // CREATE | UPDATE | STATUS_CHANGE | DELETE
  diff      String?  // JSON of before/after
  at        DateTime @default(now())
}
```

## Deployment notes
- `metadata` stored as JSON string (SQLite has no native JSON). On Postgres,
  migrate to `Json` type for query support.
- Soft-delete only — never physically remove an asset row (audit integrity).
- CSV import processes rows in a transaction; failures roll back the whole
  batch.

## Status
- **Spec only.** Route stub at `/bench` will be implemented in a later
  session.
