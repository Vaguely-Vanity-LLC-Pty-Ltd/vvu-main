# FORGE.md — Study Environment

> A focused study workspace for members: courses, labs, code playgrounds,
> progress tracking.

## Purpose
Give VVU · STUDIO members a place to learn the platform's domain (asset
protection, ops, infra) through structured courses and hands-on labs. Progress
is tracked per user and surfaced on the dashboard.

## Key features
- Course catalog with module / lesson hierarchy.
- Markdown + code blocks rendered with syntax highlighting.
- In-browser code playground (sandboxed iframe) for hands-on labs.
- Progress tracking: per-lesson completion, per-course percentage.
- Quizzes with auto-grading.
- Tier-gated content (VIP-only advanced courses).

## API endpoints (planned)
- `GET    /api/forge/courses`                — catalog
- `GET    /api/forge/courses/:id`            — course + lessons
- `POST   /api/forge/progress`              — mark lesson complete
- `GET    /api/forge/progress/me`           — my progress
- `POST   /api/forge/quizzes/:id/submit`    — submit answers, get grade

## Data models (planned)
```
model Course {
  id          String   @id @default(cuid())
  slug        String   @unique
  title       String
  description String?
  tier        String   @default("FREE")  // FREE | SUPPORTER | SUPER_FAN | VIP
  published   Boolean  @default(false)
  modules     Module[]
}

model Module {
  id        String   @id @default(cuid())
  courseId  String
  title     String
  order     Int
  lessons   Lesson[]
}

model Lesson {
  id        String   @id @default(cuid())
  moduleId  String
  title     String
  content   String   // markdown
  order     Int
  duration  Int?     // minutes
  progress  LessonProgress[]
}

model LessonProgress {
  id        String   @id @default(cuid())
  lessonId  String
  userId    String
  completed Boolean  @default(false)
  at        DateTime @default(now())
  @@unique([lessonId, userId])
}
```

## Deployment notes
- Course content stored in the DB (markdown). For large bodies of content,
  consider MDX files in the repo and a build-time indexer.
- Playground iframe must use `sandbox="allow-scripts"` without `allow-same-origin`.
- VIP content gating is enforced both server-side (API) and client-side (UI).

## Status
- **Spec only.** Route stub at `/forge` will be implemented in a later
  session.
