# VALIDATION.md — Validation Dashboard

> Verify that every surface is healthy, links resolve, builds pass, and deploys
> are READY. The platform grades itself.

## Purpose
A self-check surface: continuous validation that the platform meets the
non-negotiable standards from `JOB.md`. Used by the founder (and during
rebuild sessions) to confirm nothing regressed.

## Key features
- Lint summary (last `bun run lint` result, error count, file breakdown).
- Build status (last `bun run build` exit code, warnings).
- Vercel deploy state (READY / ERROR / BUILDING) per environment.
- Link checker — crawl all internal routes, report dead links.
- Auth smoke test — sign-in/up/out flow regression.
- Surface checklist — each surface's MD spec vs. implementation status.
- Grade output (A / B / C / D / F) per surface.

## API endpoints (planned)
- `GET /api/validation/lint`         — last lint result
- `GET /api/validation/build`        — last build result
- `GET /api/validation/deploy`       — Vercel deployment state
- `GET /api/validation/links`        — internal link check report
- `POST /api/validation/run`         — trigger a full validation sweep (admin)

## Data models (planned)
```
model ValidationRun {
  id          String   @id @default(cuid())
  triggeredBy String
  startedAt   DateTime @default(now())
  finishedAt  DateTime?
  status      String   // RUNNING | PASSED | FAILED
  summary     String?  // JSON blob of component results
  checks      ValidationCheck[]
}

model ValidationCheck {
  id        String   @id @default(cuid())
  runId     String
  name      String   // "lint", "build", "deploy", "links"…
  status    String   // PASS | FAIL | SKIP
  detail    String?
  at        DateTime @default(now())
}
```

## Deployment notes
- Validation runs are triggered by Vercel Cron (`0 */6 * * *` — every 6h) and
  on-demand from the dashboard.
- Use the Vercel REST API (`GET /v6/deployments`) with `VERCEL_TOKEN` from
  `.env` to fetch deploy state. Never commit the token.
- Link crawler must respect `robots.txt` and stay on the same origin.

## Status
- **Spec only.** Route stub at `/validation` will be implemented in a later
  session.
