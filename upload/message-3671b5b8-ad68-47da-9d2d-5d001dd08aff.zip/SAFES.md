# SAFES.md — Secure Storage / Vault

> Encrypted at-rest storage for sensitive founder assets: documents, keys,
> credentials, recovery phrases.

## Purpose
A vault for the founder and admins to store high-sensitivity material with
per-item access logs. Items are encrypted with a derived key; the platform
never sees plaintext without an explicit unlock action.

## Key features
- Items encrypted client-side (WebCrypto AES-GCM) before upload — server only
  ever stores ciphertext.
- Per-item access audit log (who, when, IP, user-agent).
- Time-locked self-destruct items (optional TTL).
- Founders can share with named members; revocation is instant.
- Folder hierarchy + full-text search over item metadata (not contents).

## API endpoints (planned)
- `GET    /api/safes`                       — list folders + items
- `POST   /api/safes/folders`               — create folder
- `POST   /api/safes/items`                 — upload encrypted item
- `GET    /api/safes/items/:id`             — fetch ciphertext
- `DELETE /api/safes/items/:id`             — destroy
- `POST   /api/safes/items/:id/share`       — share with member
- `DELETE /api/safes/items/:id/share/:uid`  — revoke
- `GET    /api/safes/audit`                 — audit log (admin)

## Data models (planned)
```
model SafeFolder {
  id        String   @id @default(cuid())
  name      String
  parentId  String?
  ownerId   String
  createdAt DateTime @default(now())
}

model SafeItem {
  id           String   @id @default(cuid())
  folderId     String?
  ownerId      String
  name         String
  ciphertext   String   // base64 (client-encrypted)
  iv           String   // base64
  algorithm    String   @default("AES-GCM")
  expiresAt    DateTime?
  createdAt    DateTime @default(now())
  shares       SafeShare[]
  auditEvents  SafeAudit[]
}

model SafeShare {
  id        String   @id @default(cuid())
  itemId    String
  userId    String
  grantedAt DateTime @default(now())
  revokedAt DateTime?
}

model SafeAudit {
  id        String   @id @default(cuid())
  itemId    String
  userId    String
  action    String   // VIEW | SHARE | REVOKE | DELETE
  ip        String?
  ua        String?
  at        DateTime @default(now())
}
```

## Deployment notes
- Encryption keys are derived in-browser from the user's password (PBKDF2) —
  the server never has the raw key.
- For Vercel, store ciphertext in the DB (small items) or S3-compatible blob
  storage (large items) with the DB row holding only the reference.
- Audit log entries are append-only — never expose a DELETE endpoint.

## Status
- **Spec only.** Route stub at `/safes` will be implemented in a later
  session.
