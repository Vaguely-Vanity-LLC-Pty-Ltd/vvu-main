# VVU Control — Surface Manifest

Each surface folder contains the real files that back it. Files are
flattened (no `src/` prefix) so the surface view is immediate. The
canonical source of truth remains the workspace's `src/` tree; this
compile is the audit view.

## Status

| Surface | Status | Files |
|---|---|---|
| auth/            | CONFIRMED | 5 |
| control-plane/   | CONFIRMED | 28 (incl. editor/ + api/) |
| safes/           | CONFIRMED | 2 |
| validation/      | CONFIRMED | 1 (+README — impl lives in safes/ + field/) |
| field/           | CONFIRMED | 6 |
| forge/           | CONFIRMED | 6 |
| pools/           | CONFIRMED | 10 |
| press/           | PARTIAL   | 3 (lyrics + persona + agent; no publishing) |
| bench/           | PARTIAL   | 2 (files view + term view; no project browse) |
| prisma/          | CONFIRMED | 1 (schema) |
| store/           | EMPTY     | 0 |
| mini-services/   | EMPTY     | 0 |
| examples/        | PARTIAL   | 0 (doesn't compile — excluded) |

## Read order

1. README.md — what this is
2. ESTATE_AUDIT.md — surface-by-surface honest gaps
3. MANIFEST.md (this file) — file index
4. load-bearing-code-walkthrough.md — the three files you must own
5. landing.html — the public-URL page
