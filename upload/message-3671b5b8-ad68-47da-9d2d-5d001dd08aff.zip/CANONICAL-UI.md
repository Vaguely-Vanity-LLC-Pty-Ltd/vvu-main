# CANONICAL-UI.md — One System, Four Voices

> The VVU estate renders many faces, and it renders them on purpose.
> This document is the contract that keeps the variety intentional
> and the drift impossible.

## 1. Mandate

The estate ships four visibly different experience families: the bare
terminal **Manifest**, the tabbed **verification layer**, the 3D **City
Twin** operations theater, and the IDE-chrome **VVU·STUDIO** commerce
environment. They must NOT converge into one generic look. They must
also NOT drift into four unrelated products.

The contract is therefore split in two:

1. **Invariants** — a small, strict set of things that are byte-identical
   everywhere, in every mode, on every page state.
2. **Modes** — four canonical mode personalities whose differences are
   mandated. A reader must be able to name the mode at a glance.

Anything not covered by an invariant is mode territory: layout, density,
chrome, motion, accent weight. Anything covered by an invariant is not
available for reinterpretation.

## 2. Invariants (apply in ALL modes)

| # | Invariant | Canonical value |
| --- | --- | --- |
| I-1 | Wordmark | `VENTURE VISION UBUNTU (VVU)` — never "VUU", never "VentureVision" |
| I-2 | Founder footer line | `Mihle "Divhani" Majokweni` |
| I-3 | Footer org + year | `VVU Foundation ©2026` |
| I-4 | Footer motto | `Transparent cycles forge trust` |
| I-5 | Receipt epigraph | `This receipt proves inclusion, not consensus` |
| I-6 | Eleven-beat order | INGEST → INFER → LOG → SYNC → COMPARE → FOLD → MINT → SHIP → WIPE → RETRIEVE → WATCHDOG (fixed, never reordered) |
| I-7 | Status vocabulary | `MOI`, `NODES`, `FPS`, `FILES` — estate metrics keep these names in every mode |
| I-8 | Palette source | every color resolves to a `--vvu-*` token; no hardcoded hex in surface code |
| I-9 | Data typography | monospace for all machine-truth (beats, hashes, receipts, telemetry numbers) |

## 3. The Four Canonical Modes

Each mode is a first-class citizen of the system. Surfaces MUST declare
exactly one mode. Flattening two modes into sameness violates this spec;
so does inventing a fifth mode without a spec amendment.

### 3.1 MANIFEST — the bare terminal ritual

- Where: public manifest page, verification receipts (`venturevisionubuntu.co.za`).
- Personality: liturgical. Near-black canvas, monospace everything, no
  chrome except the beats and the receipt. The page IS the document.
- Density: sparse. One column. Generous vertical rhythm.
- Motion: none to minimal — state flips (IDLE → ARMED → DONE) only.
- Accent: `--vvu-manifest-accent` (terminal green).
- Chrome: none. No nav tabs, no panels. Footer only.

### 3.2 VERIFY — terminal with navigation

- Where: the verification layer with surface tabs (CITY TWIN, RIG,
  WORM LEDGER, MAP, TRUST SPHERE, COST MATRIX).
- Personality: MANIFEST's voice plus wayfinding. Same canvas, same type,
  but a persistent top tab rail and status bar appear.
- Density: sparse-to-medium. Tabs on top, one working surface below.
- Motion: connection-state feedback (RECONNECTING, BOOTING) allowed.
- Accent: `--vvu-verify-accent` (armed amber).
- Chrome: tab rail + status strip. No side panels.

### 3.3 TWIN — ops theater

- Where: City Twin monitor, Field oversight.
- Personality: mission control. 3D isometric viewport center-stage,
  telemetry rails left and right, route colors (green / blue / orange)
  over the city model, red critical markers.
- Density: dense. Multi-panel. The only mode allowed a 3D viewport.
- Motion: continuous — the FPS counter is a first-class element (I-7).
- Accent: `--vvu-twin-accent` (route orange); the data colors
  `--vvu-telemetry-blue` and `--vvu-route` are legal in TWIN-scoped
  components only.
- Chrome: full panels + mode toggles (CITY TWIN / RIG / MAP), the
  inference switch rail (§9.1), the map-view dropdown (§9.2), and the
  replay timeline (§9.3).

### 3.4 STUDIO — IDE chrome and commerce

- Where: VVU·STUDIO membership, Store, Control Plane dashboard.
- Personality: an editor you subscribe to. File explorer, tab bar,
  agent dock (VVU Agent), tier cards with ZAR pricing, receipts via
  ProofBridge (SHA-256).
- Density: medium-dense, workspace-like.
- Motion: standard UI transitions; no 3D.
- Accent: `--vvu-studio-accent` (estate green — matches the repo's
  green-accent chart palette).
- Chrome: IDE shell (explorer / tabs / dock) or card grid. The only
  mode allowed light-surface cards over the dark canvas.

## 4. Token Set (single source: `src/app/globals.css`)

| Token | Value | Role |
| --- | --- | --- |
| `--vvu-canvas` | `#050607` | page background, all modes |
| `--vvu-panel` | `#0b0d0f` | panel background |
| `--vvu-panel-raised` | `#111417` | raised surface (cards, docks) |
| `--vvu-line` | `#1d2226` | borders, dividers |
| `--vvu-text` | `#e8eaed` | primary text |
| `--vvu-text-muted` | `#8a9199` | secondary text |
| `--vvu-live` | `#22c55e` | live / OK state |
| `--vvu-armed` | `#f59e0b` | armed / pending state |
| `--vvu-critical` | `#ef4444` | critical / severe state |
| `--vvu-telemetry-blue` | `#3b82f6` | TWIN-only data color |
| `--vvu-route` | `#f97316` | TWIN-only route color |
| `--vvu-manifest-accent` | `#22c55e` | MANIFEST mode accent |
| `--vvu-verify-accent` | `#f59e0b` | VERIFY mode accent |
| `--vvu-twin-accent` | `#f97316` | TWIN mode accent |
| `--vvu-studio-accent` | `#16a34a` | STUDIO mode accent |

Tokens are registered with Tailwind 4 via `@theme inline`, so utilities
like `bg-vvu-canvas`, `text-vvu-live`, `border-vvu-line` are generated.
Re-theming the estate is a token-file change; no surface code may embed
palette values (I-8).

## 5. Canonical Components (`src/components/canonical/`)

| Component | Enforces | Notes |
| --- | --- | --- |
| `SurfaceModeTag` | mode declaration | renders the mode chip; one per surface (CU-2) |
| `BeatRail` | I-6 | the eleven beats in fixed order, per-beat state (idle/armed/done), mode-aware density |
| `StatusStrip` | I-7 | MOI / NODES / FPS / FILES readout with state dot (live / armed / degraded / empty) |
| `TrustFooter` | I-2, I-3, I-4 | founder line, org + year, motto — the ONLY footer surfaces may ship |
| `InferenceSwitch` | FR-CT-1..5 | the press-to-begin-inference switch for the five Foundation Models; OFF / ARMED / RUNNING / VERDICT |
| `MapViewDropdown` | FR-CT-6..10 | the single dropdown that switches map view and tile layer; carries each tile's epistemic class |
| `ReplayTimeline` | FR-CT-11..15 | the 31-day replay scrubber; read-only, reconstructed from the WORM log |

Surfaces re-implementing these in local code is a review-blocking defect.
Mode chrome (tab rails, explorers, viewport frames) is deliberately NOT
canonical — that is where the variety lives.

## 6. Canonical Strings

| State | String |
| --- | --- |
| EMPTY (no cycles) | `INSUFFICIENT DATA — THE TWIN HAS NO CYCLES YET` |
| DEGRADED (link lost) | `TELEMETRY LINK DOWN — RECONNECTING` |
| READY (idle service) | `AWAITING SERVICE` |
| BOOTING | `BOOTING` |
| Receipt epigraph | `This receipt proves inclusion, not consensus` |

These strings ship exactly as written — uppercase, em-dash included —
from the components that own them.

## 7. Drift Ledger (caught and canonicalized)

| Drift observed | Resolution |
| --- | --- |
| One surface rendered the wordmark as `VUU` | I-1: `VVU` everywhere |
| Founder rendered as `Mike "Divhani" Majokweni` on one surface | I-2: `Mihle "Divhani" Majokweni` |
| Beats listed with per-surface naming and ordering | I-6: fixed canonical order via `BeatRail` |
| Footer variants (some with motto, some without) | I-3 / I-4: one `TrustFooter` |

New drift entries are added here when caught, then closed by a token or
component fix — never by a local patch.

## 8. Canonical UI Requirements (CU-n)

- **CU-1** — All surfaces MUST consume the `--vvu-*` token set; hardcoded
  palette values MUST NOT appear in surface code.
- **CU-2** — Every surface MUST declare exactly one canonical mode
  (MANIFEST, VERIFY, TWIN, STUDIO) via `SurfaceModeTag` or route metadata.
- **CU-3** — Invariants I-1 through I-9 MUST hold in every mode and on
  every page state, including EMPTY, DEGRADED, and error states.
- **CU-4** — Modes MUST remain visually distinct; a surface MUST NOT adopt
  another mode's chrome, density, or motion.
- **CU-5** — Invariant elements (beats, footer, status vocabulary) MUST be
  rendered through `src/components/canonical/`, never re-implemented.
- **CU-6** — Mode accents MUST derive from the base token set; a mode MUST
  NOT introduce a second palette or an unregistered color.

## 9. TWIN Geospatial Affordances (canonical)

The City Twin's three geospatial controls are canonical components, not
per-surface inventions. They render in TWIN mode (Field MAY reuse
`ReplayTimeline`), and their state machines are owned here. The functional
requirements live in README Section 9 (FR-CT-1..15, AC-CT-a..i); this
section fixes the interaction anatomy.

### 9.1 InferenceSwitch — press to begin inference

One switch per Foundation Model, always visible in the twin chrome.
Inference is a switch, because evidence should be as easy to start as a
light and as hard to fake as a receipt.

- State machine: `OFF → ARMED → RUNNING → VERDICT` (and `ARMED → OFF`
  when a model is disabled). `OFF` is the only state in which the model
  cannot run.
- Pressing an `ARMED` switch begins an inference run bound to the
  current map view, tile, and viewport context (FR-CT-3).
- Verdict colors resolve to tokens: `PROVEN` → `--vvu-live`,
  `INCONCLUSIVE` → `--vvu-armed`, `BLOCKED` → `--vvu-critical`.
- The switch never asserts tier (Epistemic Humility); it reports the
  model's verdict and the gate that produced it, for example
  `BLOCKED_MISSING_INPUT`.
- Icons are per model class (visual / macro / tactical / structural /
  registry) from Lucide, the estate icon system.

### 9.2 MapViewDropdown — one control, every tile

The single dropdown that switches map view and tile layer (FR-CT-6).
Operators move from street level to orbit and back without re-learning
the interface.

- Canonical views, owned by the component in this order: `STREET`,
  `SATELLITE`, `TERRAIN`, `TWIN MESH`, `DINSAR OVERLAY`,
  `FUSED TACTICAL` — each rendered with its tile descriptor and
  epistemic class (the claims the tile can and cannot support).
- A view whose tiles have not passed validation renders `UNVERIFIED`
  and is never styled to imply verified status (FR-CT-7).
- Switching views preserves switch states, running runs, and replay
  position (FR-CT-8); the surrounding twin chrome never changes with
  the view (FR-CT-9).

### 9.3 ReplayTimeline — 31 days, read only

The trailing-31-day scrubber over the WORM Inference Log (FR-CT-11).
The past is reconstructed, not remembered.

- `REPLAY_WINDOW_DAYS = 31` is owned by the component; a deployment MAY
  lengthen the window, never shorten it below 31 (FR-CT-13).
- Scrubbing reconstructs map view, active tiles, switch states, and
  verdicts from WORM entries; replay is read-only and writes no
  evidence (FR-CT-12, FR-CT-14).
- Canonical footer string: `EVIDENCE OUTLIVES THE WINDOW — THE WORM
  LEDGER RETAINS PERMANENTLY`.

## 10. File Map

```text
ui/
└── CANONICAL-UI.md          # this specification
src/app/
└── globals.css              # --vvu-* token definitions + Tailwind registration
src/components/canonical/
├── tokens.ts                # mode types + identity strings (I-1..I-5)
├── BeatRail.tsx             # I-6 eleven beats
├── StatusStrip.tsx          # I-7 status vocabulary + canonical state strings
├── SurfaceModeTag.tsx       # CU-2 mode declaration
├── TrustFooter.tsx          # I-2 I-3 I-4 footer
├── InferenceSwitch.tsx      # §9.1 press-to-run switch (5 Foundation Models)
├── MapViewDropdown.tsx      # §9.2 map view + tile dropdown
├── ReplayTimeline.tsx       # §9.3 31-day replay scrubber
└── index.ts                 # barrel export
```
