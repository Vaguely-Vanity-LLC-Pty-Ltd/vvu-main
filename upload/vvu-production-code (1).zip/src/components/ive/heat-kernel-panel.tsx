"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Flame, Loader2 } from "lucide-react";

interface TraceStep {
  step: number;
  l2Norm: number;
  highFreqEnergy: number;
}
interface Result {
  topology: string;
  n: number;
  kappa: number;
  steps: number;
  finalL2Norm: number;
  finalHighFreqEnergy: number;
  retention: number;
  trace: TraceStep[];
}

export function HeatKernelPanel({
  claimId,
  topology = "cycle",
}: {
  claimId?: string;
  topology?: "cycle" | "evidence";
}) {
  const [result, setResult] = useState<Result | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.resolve().then(() => {
      if (!cancelled) {
        setLoading(true);
        setError(null);
      }
    });
    const body: Record<string, unknown> = {
      topology,
      kappa: 0.25,
      steps: 50,
    };
    if (topology === "evidence" && claimId) body.claimId = claimId;
    else body.n = 128;
    fetch("/api/heat-kernel", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })
      .then(async (r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json() as Promise<Result>;
      })
      .then((d) => {
        if (!cancelled) setResult(d);
      })
      .catch((e) => {
        if (!cancelled) setError(String(e?.message ?? e));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [claimId, topology]);

  const trace = result?.trace ?? [];
  const maxL2 = Math.max(...trace.map((t) => t.l2Norm), 1e-9);
  const maxHF = Math.max(...trace.map((t) => t.highFreqEnergy), 1e-9);
  const maxValue = Math.max(maxL2, maxHF);

  const l2Points = trace
    .map((t, i) => {
      const x = (i / Math.max(1, trace.length - 1)) * 100;
      const y = 100 - (t.l2Norm / maxValue) * 95;
      return `${x},${y}`;
    })
    .join(" ");
  const hfPoints = trace
    .map((t, i) => {
      const x = (i / Math.max(1, trace.length - 1)) * 100;
      const y = 100 - (t.highFreqEnergy / maxValue) * 95;
      return `${x},${y}`;
    })
    .join(" ");
  // area fill polygon under the L2 curve (for the gradient wash)
  const l2AreaPoints = trace.length > 0 ? `0,100 ${l2Points} 100,100` : "";

  // sample the trace to label 0 / 25 / 50 / 75 / 100 step markers
  const stepLabels = [0, 0.25, 0.5, 0.75, 1].map((f) => {
    const idx = Math.round(f * (trace.length - 1));
    return { f, idx, label: trace[idx]?.step ?? 0 };
  });

  return (
    <Card className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="flex items-center gap-1.5 text-sm font-semibold">
            <Flame className="h-3.5 w-3.5" />
            Heat Kernel Diffusion
          </h3>
          <p className="font-mono text-[10px] text-muted-foreground">
            u_t = −κ L u &nbsp;(graph Laplacian L = D − A)
          </p>
        </div>
        <span className="rounded border border-emerald-500/30 bg-emerald-500/10 px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wider text-emerald-700 dark:text-emerald-300">
          Theorem 3
        </span>
      </div>
      {loading ? (
        <div className="flex items-center gap-2 rounded-md border border-dashed border-border/60 bg-muted/30 p-4 font-mono text-[11px] text-muted-foreground">
          <Loader2 className="h-3 w-3 animate-spin" /> Running diffusion…
        </div>
      ) : error ? (
        <div className="rounded-md border border-red-500/40 bg-red-500/10 p-2 font-mono text-[10px] text-red-700 dark:text-red-300">
          error: {error}
        </div>
      ) : result ? (
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-md border border-emerald-500/30 bg-emerald-500/10 p-2 text-center">
              <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                L2 retention
              </div>
              <div className="font-mono text-lg font-bold text-emerald-700 dark:text-emerald-300">
                {(result.retention * 100).toFixed(1)}%
              </div>
            </div>
            <div className="rounded-md border border-red-500/30 bg-red-500/10 p-2 text-center">
              <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                High-freq
              </div>
              <div className="font-mono text-lg font-bold text-red-700 dark:text-red-300">
                ×{result.finalHighFreqEnergy.toFixed(2)}
              </div>
            </div>
            <div className="rounded-md border border-border bg-card p-2 text-center">
              <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                κ / N
              </div>
              <div className="font-mono text-lg font-bold">
                {result.kappa.toFixed(2)} / {result.n}
              </div>
            </div>
          </div>
          <div>
            <div className="mb-1 flex items-center justify-between">
              <span className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                Diffusion trace · {trace.length} steps
              </span>
              <span className="font-mono text-[9px] text-muted-foreground">
                t = 0 … {result?.steps ?? 0}
              </span>
            </div>
            <div className="relative h-28 rounded-md border bg-muted/20 p-1.5">
              <svg
                viewBox="0 0 100 100"
                preserveAspectRatio="none"
                className="h-full w-full"
              >
                <defs>
                  <linearGradient id="l2grad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.646 0.222 41.116)" stopOpacity="0.35" />
                    <stop offset="100%" stopColor="oklch(0.646 0.222 41.116)" stopOpacity="0.02" />
                  </linearGradient>
                </defs>
                {/* horizontal grid lines (25%, 50%, 75%) */}
                {[25, 50, 75].map((y) => (
                  <line
                    key={y}
                    x1="0"
                    y1={y}
                    x2="100"
                    y2={y}
                    stroke="var(--border)"
                    strokeWidth="0.4"
                    vectorEffect="non-scaling-stroke"
                    opacity="0.6"
                  />
                ))}
                {/* vertical grid lines at 25/50/75% of steps */}
                {[25, 50, 75].map((x) => (
                  <line
                    key={`v${x}`}
                    x1={x}
                    y1="0"
                    x2={x}
                    y2="100"
                    stroke="var(--border)"
                    strokeWidth="0.4"
                    vectorEffect="non-scaling-stroke"
                    opacity="0.4"
                  />
                ))}
                {/* area fill under L2 curve */}
                {l2AreaPoints && (
                  <polygon
                    points={l2AreaPoints}
                    fill="url(#l2grad)"
                  />
                )}
                <polyline
                  points={l2Points}
                  fill="none"
                  stroke="oklch(0.646 0.222 41.116)"
                  strokeWidth={1.5}
                  vectorEffect="non-scaling-stroke"
                />
                <polyline
                  points={hfPoints}
                  fill="none"
                  stroke="oklch(0.7 0.18 50)"
                  strokeWidth={1.5}
                  strokeDasharray="2,2"
                  vectorEffect="non-scaling-stroke"
                />
              </svg>
              {/* step-axis labels */}
              <div className="mt-1 flex justify-between font-mono text-[8px] text-muted-foreground">
                {stepLabels.map((s, i) => (
                  <span key={i}>t={s.label}</span>
                ))}
              </div>
            </div>
            <div className="mt-1.5 flex items-center gap-3 text-[9px]">
              <span className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-sm" style={{ backgroundColor: "oklch(0.646 0.222 41.116)" }} />
                <span className="text-muted-foreground">L2 norm</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-sm" style={{ backgroundColor: "oklch(0.7 0.18 50)" }} />
                <span className="text-muted-foreground">High-freq</span>
              </span>
            </div>
          </div>
          <p className="font-mono text-[10px] leading-snug text-muted-foreground">
            Heat kernel decays monotonically; high-frequency modes suppressed. Wave eq
            (u_tt + c²Lu = 0) conserves energy (drift = 0.000e+00) but is inappropriate for
            dissipative evidence systems.
          </p>
        </div>
      ) : null}
    </Card>
  );
}
