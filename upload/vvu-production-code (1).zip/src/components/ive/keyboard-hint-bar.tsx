"use client";

import { useEffect, useState } from "react";
import { Keyboard, X } from "lucide-react";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "vvu-ive-hintbar-dismissed";

// Contextual keyboard shortcut hints — shown per active view.
const HINTS: { keys: string; label: string }[] = [
  { keys: "Ctrl+K", label: "commands" },
  { keys: "/", label: "search" },
  { keys: "r", label: "run pipeline" },
  { keys: "n/p", label: "next/prev claim" },
  { keys: "g", label: "cycle estate" },
  { keys: "b", label: "batch" },
  { keys: "e", label: "export" },
  { keys: "?", label: "help" },
];

export function KeyboardHintBar() {
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    Promise.resolve().then(() => {
      setDismissed(window.localStorage.getItem(STORAGE_KEY) === "1");
    });
    const onChange = () =>
      setDismissed(window.localStorage.getItem(STORAGE_KEY) === "1");
    window.addEventListener("storage", onChange);
    return () => window.removeEventListener("storage", onChange);
  }, []);

  if (dismissed) return null;

  const dismiss = () => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(STORAGE_KEY, "1");
      window.dispatchEvent(new Event("storage"));
    }
    setDismissed(true);
  };

  return (
    <div className="mx-auto flex w-full max-w-[1600px] items-center gap-2 px-4 py-1.5">
      <div className="flex flex-1 flex-wrap items-center gap-x-3 gap-y-1 rounded-md border border-border/60 bg-muted/20 px-2.5 py-1">
        <span className="flex items-center gap-1 font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
          <Keyboard className="h-3 w-3" /> shortcuts
        </span>
        <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
          {HINTS.map((h) => (
            <span
              key={h.keys}
              className="flex items-center gap-1"
            >
              <kbd
                className={cn(
                  "rounded border border-border bg-background px-1 py-0.5 font-mono text-[9px] font-semibold text-foreground",
                )}
              >
                {h.keys}
              </kbd>
              <span className="font-mono text-[9px] text-muted-foreground">
                {h.label}
              </span>
            </span>
          ))}
        </div>
      </div>
      <button
        onClick={dismiss}
        className="shrink-0 rounded p-1 text-muted-foreground hover:bg-muted/50 hover:text-foreground"
        title="Dismiss (reappears after clearing localStorage)"
      >
        <X className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
