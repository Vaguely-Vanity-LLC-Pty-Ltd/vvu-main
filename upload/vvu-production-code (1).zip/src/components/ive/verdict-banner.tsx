"use client";

import { Card } from "@/components/ui/card";
import {
  ShieldCheck,
  ShieldAlert,
  CheckCircle2,
  XCircle,
  Zap,
  Activity,
  Database,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type {
  AuthorizationRecord,
  ClaimWithRelations,
  NIndRecord,
} from "@/lib/eis";

const CONJUNCT_META = [
  { symbol: "C", label: "Claim", key: "claimOk" as const },
  { symbol: "E", label: "Evidence", key: "evidenceOk" as const },
  { symbol: "I", label: "Integrity", key: "integrityOk" as const },
  { symbol: "S", label: "Safety", key: "safetyOk" as const },
  { symbol: "R", label: "Review", key: "reviewOk" as const },
];

export function VerdictBanner({
  claim,
  auth,
  nInd,
}: {
  claim: ClaimWithRelations;
  auth: AuthorizationRecord | null;
  nInd: NIndRecord | null;
}) {
  const authorized = auth?.authorized ?? false;
  const breakerTripped = claim.circuitEvents[0]?.triggered ?? false;
  const evidenceCount = claim.evidence.length;
  const distinctSources = new Set(claim.evidence.map((e) => e.source)).size;
  const nIndValue = nInd?.nInd ?? 0;
  const nIndThreshold = claim.safetyCritical ? 2 : 1;

  // Quick metric cells
  const metrics = [
    {
      icon: Database,
      label: "Evidence",
      value: `${evidenceCount}`,
      sub: `${distinctSources}/4 src`,
      tone: evidenceCount >= 1 ? "neutral" : "bad",
    },
    {
      icon: Activity,
      label: "State",
      value: claim.state,
      sub: claim.claimType,
      tone:
        claim.state === "FALSIFIED"
          ? "bad"
          : claim.state === "UNTESTED"
            ? "warn"
            : "good",
    },
    {
      icon: Zap,
      label: "N_ind",
      value: nIndValue.toFixed(2),
      sub: `≥ ${nIndThreshold - 0.3}`,
      tone: nIndValue >= nIndThreshold - 0.3 ? "good" : "bad",
    },
    {
      icon: breakerTripped ? ShieldAlert : ShieldCheck,
      label: "Breaker",
      value: breakerTripped ? "TRIPPED" : "CLOSED",
      sub: breakerTripped ? claim.circuitEvents[0]?.reason ?? "fail-closed" : "authorising",
      tone: breakerTripped ? "bad" : "good",
    },
  ];

  return (
    <Card
      className={cn(
        "overflow-hidden border-2 p-0 transition-colors",
        authorized
          ? "border-emerald-500/50"
          : breakerTripped
            ? "border-red-500/50"
            : "border-amber-500/50",
      )}
    >
      {/* Verdict strip — large A = TRUE / FALSE */}
      <div
        className={cn(
          "flex items-center justify-between gap-3 px-4 py-3",
          authorized
            ? "bg-gradient-to-r from-emerald-500/15 via-emerald-500/5 to-transparent"
            : breakerTripped
              ? "bg-gradient-to-r from-red-500/15 via-red-500/5 to-transparent"
              : "bg-gradient-to-r from-amber-500/15 via-amber-500/5 to-transparent",
        )}
      >
        <div className="flex items-center gap-2.5">
          <div
            className={cn(
              "flex h-10 w-10 items-center justify-center rounded-full border-2",
              authorized
                ? "border-emerald-500 bg-emerald-500/10"
                : breakerTripped
                  ? "border-red-500 bg-red-500/10"
                  : "border-amber-500 bg-amber-500/10",
            )}
          >
            {authorized ? (
              <ShieldCheck
                className={cn(
                  "h-5 w-5",
                  "text-emerald-600 dark:text-emerald-400",
                )}
              />
            ) : (
              <ShieldAlert
                className={cn(
                  "h-5 w-5",
                  breakerTripped
                    ? "text-red-600 dark:text-red-400"
                    : "text-amber-600 dark:text-amber-400",
                )}
              />
            )}
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span
                className={cn(
                  "font-mono text-2xl font-bold tracking-wider",
                  authorized
                    ? "text-emerald-700 dark:text-emerald-300"
                    : breakerTripped
                      ? "text-red-700 dark:text-red-300"
                      : "text-amber-700 dark:text-amber-300",
                )}
              >
                A = {authorized ? "TRUE" : "FALSE"}
              </span>
              <span className="font-mono text-[10px] text-muted-foreground">
                {authorized
                  ? "action permitted"
                  : breakerTripped
                    ? "fail-closed · breaker tripped"
                    : "awaiting sign-off"}
              </span>
            </div>
            <p className="mt-0.5 line-clamp-1 font-mono text-[10px] text-muted-foreground">
              {auth?.reason ?? "No authorization record yet — run /api/authorize to evaluate A = C ∧ E ∧ I ∧ S ∧ R."}
            </p>
          </div>
        </div>

        {/* Conjunct strip */}
        {auth && (
          <div className="hidden items-center gap-1.5 sm:flex">
            {CONJUNCT_META.map((c, i) => {
              const ok = auth[c.key];
              const required = i < 3 || claim.safetyCritical;
              return (
                <div
                  key={c.symbol}
                  className={cn(
                    "flex h-9 w-9 flex-col items-center justify-center rounded-md border",
                    ok
                      ? "border-emerald-500/40 bg-emerald-500/10"
                      : required
                        ? "border-red-500/40 bg-red-500/10"
                        : "border-border bg-muted/30",
                  )}
                  title={`${c.label}: ${ok ? "pass" : required ? "fail" : "n/a"}`}
                >
                  {ok ? (
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                  ) : required ? (
                    <XCircle className="h-3.5 w-3.5 text-red-600 dark:text-red-400" />
                  ) : (
                    <span className="text-[9px] text-muted-foreground">—</span>
                  )}
                  <span
                    className={cn(
                      "mt-0.5 font-mono text-[8px] font-bold",
                      ok
                        ? "text-emerald-700 dark:text-emerald-300"
                        : required
                          ? "text-red-700 dark:text-red-300"
                          : "text-muted-foreground",
                    )}
                  >
                    {c.symbol}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Quick metric strip */}
      <div className="grid grid-cols-2 divide-x divide-y-0 divide-border border-t border-border sm:grid-cols-4 sm:divide-y-0">
        {metrics.map((m) => {
          const Icon = m.icon;
          return (
            <div
              key={m.label}
              className="flex items-center gap-2 px-3 py-2"
            >
              <Icon
                className={cn(
                  "h-4 w-4 shrink-0",
                  m.tone === "good"
                    ? "text-emerald-600 dark:text-emerald-400"
                    : m.tone === "bad"
                      ? "text-red-600 dark:text-red-400"
                      : m.tone === "warn"
                        ? "text-amber-600 dark:text-amber-400"
                        : "text-muted-foreground",
                )}
              />
              <div className="min-w-0">
                <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                  {m.label}
                </div>
                <div
                  className={cn(
                    "truncate font-mono text-xs font-bold",
                    m.tone === "good"
                      ? "text-emerald-700 dark:text-emerald-300"
                      : m.tone === "bad"
                        ? "text-red-700 dark:text-red-300"
                        : m.tone === "warn"
                          ? "text-amber-700 dark:text-amber-300"
                          : "text-foreground",
                  )}
                >
                  {m.value}
                </div>
                <div className="truncate font-mono text-[9px] text-muted-foreground">
                  {m.sub}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
