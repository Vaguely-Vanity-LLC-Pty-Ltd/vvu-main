"use client";

import { useEffect, useState } from "react";
import {
  Command,
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import {
  Sparkles,
  Plus,
  Download,
  RefreshCw,
  Play,
  Trash2,
  GitBranch,
  Sigma,
  ShieldCheck,
  Database,
  Layers,
  Filter,
  ChevronRight,
} from "lucide-react";
import type { ClaimWithRelations, EstateKey, VerificationState } from "@/lib/eis";

export interface CommandAction {
  id: string;
  label: string;
  hint?: string;
  icon: typeof Sparkles;
  group: "actions" | "navigation" | "filter";
  onSelect: () => void;
}

export function CommandPalette({
  open,
  onOpenChange,
  claims,
  selectedId,
  actions,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  claims: ClaimWithRelations[];
  selectedId: string | null;
  actions: {
    seed: () => void;
    newClaim: () => void;
    export: () => void;
    refresh: () => void;
    runPipeline: (id: string) => void;
    deleteClaim: (id: string) => void;
    setEstateFilter: (v: string) => void;
    setTab: (t: string) => void;
    selectClaim: (id: string) => void;
  };
}) {
  // keyboard: Ctrl/Cmd+K toggles
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === "k" || e.key === "K")) {
        e.preventDefault();
        onOpenChange(!open);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onOpenChange]);

  const estateOptions: { key: string; label: string }[] = [
    { key: "all", label: "All estates" },
    { key: "canonical", label: "Canonical IVE" },
    { key: "hbk-mk2", label: "HBK Mk-II Estate" },
    { key: "skylantern", label: "Skylantern Estate" },
  ];

  const tabOptions: { key: string; label: string }[] = [
    { key: "pipeline", label: "Pipeline" },
    { key: "lattice", label: "Lattice" },
    { key: "diffusion", label: "Diffusion" },
    { key: "timeline", label: "Timeline" },
    { key: "raw", label: "Raw" },
  ];

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput placeholder="Type a command or search claims…" />
      <CommandList className="max-h-[420px]">
        <CommandEmpty>No results found.</CommandEmpty>

        <CommandGroup heading="Actions">
          <CommandItem
            onSelect={() => {
              onOpenChange(false);
              actions.seed();
            }}
          >
            <Sparkles className="mr-2 h-4 w-4" />
            <span className="flex-1">Seed demo data</span>
            <kbd className="rounded border border-border bg-muted px-1.5 py-0.5 font-mono text-[9px]">s</kbd>
          </CommandItem>
          <CommandItem
            onSelect={() => {
              onOpenChange(false);
              actions.newClaim();
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            <span className="flex-1">New claim</span>
          </CommandItem>
          <CommandItem
            onSelect={() => {
              onOpenChange(false);
              actions.export();
            }}
          >
            <Download className="mr-2 h-4 w-4" />
            <span className="flex-1">Export IVE state to JSON</span>
            <kbd className="rounded border border-border bg-muted px-1.5 py-0.5 font-mono text-[9px]">e</kbd>
          </CommandItem>
          <CommandItem
            onSelect={() => {
              onOpenChange(false);
              actions.refresh();
            }}
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            <span className="flex-1">Refresh state</span>
          </CommandItem>
          {selectedId && (
            <>
              <CommandItem
                onSelect={() => {
                  onOpenChange(false);
                  actions.runPipeline(selectedId);
                }}
              >
                <Play className="mr-2 h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                <span className="flex-1">Run pipeline on selected claim</span>
                <kbd className="rounded border border-border bg-muted px-1.5 py-0.5 font-mono text-[9px]">r</kbd>
              </CommandItem>
              <CommandItem
                onSelect={() => {
                  onOpenChange(false);
                  actions.deleteClaim(selectedId);
                }}
              >
                <Trash2 className="mr-2 h-4 w-4 text-red-600 dark:text-red-400" />
                <span className="flex-1">Delete selected claim</span>
              </CommandItem>
            </>
          )}
        </CommandGroup>

        <CommandSeparator />

        <CommandGroup heading="Navigate tabs">
          {tabOptions.map((t) => (
            <CommandItem
              key={t.key}
              onSelect={() => {
                onOpenChange(false);
                actions.setTab(t.key);
              }}
            >
              <ChevronRight className="mr-2 h-4 w-4 text-muted-foreground" />
              <span className="flex-1">{t.label} tab</span>
              <kbd className="rounded border border-border bg-muted px-1.5 py-0.5 font-mono text-[9px]">
                Ctrl+{tabOptions.findIndex((x) => x.key === t.key) + 1}
              </kbd>
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandSeparator />

        <CommandGroup heading="Filter by estate">
          {estateOptions.map((e) => (
            <CommandItem
              key={e.key}
              onSelect={() => {
                onOpenChange(false);
                actions.setEstateFilter(e.key);
              }}
            >
              <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
              <span className="flex-1">{e.label}</span>
            </CommandItem>
          ))}
        </CommandGroup>

        {claims.length > 0 && (
          <>
            <CommandSeparator />
            <CommandGroup heading={`Claims (${claims.length})`}>
              {claims.slice(0, 30).map((c) => (
                <CommandItem
                  key={c.id}
                  value={`claim ${c.title} ${c.estateKey} ${c.state} ${c.claimType}`}
                  onSelect={() => {
                    onOpenChange(false);
                    actions.selectClaim(c.id);
                  }}
                >
                  <Layers className="mr-2 h-4 w-4 shrink-0 text-muted-foreground" />
                  <div className="flex min-w-0 flex-1 items-center gap-2">
                    <span
                      className={
                        c.estateKey === "hbk-mk2"
                          ? "h-1.5 w-1.5 shrink-0 rounded-full bg-amber-500"
                          : c.estateKey === "skylantern"
                            ? "h-1.5 w-1.5 shrink-0 rounded-full bg-cyan-500"
                            : "h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-500"
                      }
                    />
                    <span className="truncate text-sm">{c.title}</span>
                  </div>
                  <span className="ml-auto shrink-0 font-mono text-[10px] text-muted-foreground">
                    {c.state} · {c.estateKey}
                  </span>
                </CommandItem>
              ))}
            </CommandGroup>
          </>
        )}
      </CommandList>
    </CommandDialog>
  );
}
