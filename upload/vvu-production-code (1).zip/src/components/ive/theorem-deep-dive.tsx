"use client";

import { Card } from "@/components/ui/card";
import {
  GitBranch,
  Sigma,
  Flame,
  GitCommitVertical,
  Zap,
  CheckCircle2,
  XCircle,
  Circle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { ClaimWithRelations } from "@/lib/eis";

type TheoremStatus = "active" | "pass" | "fail" | "pending";

interface TheoremSpec {
  id: number;
  name: string;
  statement: string;
  formula: string;
  icon: typeof GitBranch;
  color: string;
  bg: string;
  border: string;
  module: string;
  statusFor: (claim: ClaimWithRelations) => { status: TheoremStatus; detail: string };
}

const THEOREMS: TheoremSpec[] = [
  {
    id: 1,
    name: "Evidence Bound",
    statement: "Claim ≤ Evidence ≤ Verification ≤ Authorization ≤ Action",
    formula: "Claim ≤ Evidence ≤ Verification ≤ Authorization ≤ Action",
    icon: GitBranch,
    color: "text-emerald-700 dark:text-emerald-300",
    bg: "bg-emerald-500/10",
    border: "border-emerald-500/30",
    module: "types.ts · authorization.ts",
    statusFor: (c) => {
      const auth = c.authorizations[0];
      if (!auth) return { status: "pending", detail: "no authorization yet" };
      if (auth.authorized) return { status: "pass", detail: "bound satisfied — A=true" };
      const failed: string[] = [];
      if (!auth.claimOk) failed.push("C");
      if (!auth.evidenceOk) failed.push("E");
      if (!auth.integrityOk) failed.push("I");
      if (!auth.safetyOk) failed.push("S");
      if (!auth.reviewOk) failed.push("R");
      return { status: "fail", detail: `bound broken at: ${failed.join("·")}` };
    },
  },
  {
    id: 2,
    name: "N_ind Participation Ratio",
    statement: "N_ind = (Σλ_i)² / Σλ_i² — monotonic non-decreasing in true source count m",
    formula: "N_ind = (Σλ_i)² / Σλ_i²",
    icon: Sigma,
    color: "text-orange-700 dark:text-orange-300",
    bg: "bg-orange-500/10",
    border: "border-orange-500/30",
    module: "participation-ratio.ts",
    statusFor: (c) => {
      const n = c.nIndRecords[0];
      if (!n) return { status: "pending", detail: "N_ind not computed" };
      const threshold = c.safetyCritical ? 2 : 1;
      if (n.nInd >= threshold - 0.3)
        return { status: "pass", detail: `N_ind=${n.nInd.toFixed(2)} ≥ ${threshold - 0.3}` };
      return { status: "fail", detail: `N_ind=${n.nInd.toFixed(2)} < ${threshold - 0.3}` };
    },
  },
  {
    id: 3,
    name: "Heat-Kernel Diffusion",
    statement: "u_t = −κLu (L = D − A) — low-freq persists, high-freq dies, system converges",
    formula: "u_t = −κ L u",
    icon: Flame,
    color: "text-amber-700 dark:text-amber-300",
    bg: "bg-amber-500/10",
    border: "border-amber-500/30",
    module: "heat-kernel.ts",
    statusFor: (c) => {
      if (c.evidence.length === 0)
        return { status: "pending", detail: "no evidence to diffuse" };
      return {
        status: "active",
        detail: `${c.evidence.length} nodes · complete-graph Laplacian`,
      };
    },
  },
  {
    id: 4,
    name: "State-Lattice Closure",
    statement: "state(c) = max{state(e)} capped by claimType — PROVEN ≥ VERIFIED ≥ SUPPORTED ≥ OBSERVED",
    formula: "state(c) = max { state(e) } ⊓ cap(claimType)",
    icon: GitCommitVertical,
    color: "text-cyan-700 dark:text-cyan-300",
    bg: "bg-cyan-500/10",
    border: "border-cyan-500/30",
    module: "state-lattice.ts",
    statusFor: (c) => {
      if (c.state === "UNTESTED") return { status: "pending", detail: "untested" };
      if (c.state === "FALSIFIED") return { status: "fail", detail: "FALSIFIED — terminal" };
      return { status: "pass", detail: `state=${c.state} · cap=${c.claimType}` };
    },
  },
  {
    id: 5,
    name: "Fail-Closed Circuit Breaker",
    statement: "Loss of E → loss of V → loss of A → breaker trips; authorization revoked until reverification",
    formula: "¬E → ¬V → ¬A → trip",
    icon: Zap,
    color: "text-red-700 dark:text-red-300",
    bg: "bg-red-500/10",
    border: "border-red-500/30",
    module: "circuit-breaker.ts",
    statusFor: (c) => {
      const latest = c.circuitEvents[0];
      if (!latest) return { status: "pending", detail: "no breaker events" };
      if (latest.triggered)
        return { status: "fail", detail: `TRIPPED — ${latest.reason || "fail-closed"}` };
      return { status: "pass", detail: "closed — authorising" };
    },
  },
];

const STATUS_META: Record<
  TheoremStatus,
  { label: string; icon: typeof CheckCircle2; color: string }
> = {
  pass: { label: "PASS", icon: CheckCircle2, color: "text-emerald-600 dark:text-emerald-400" },
  fail: { label: "FAIL", icon: XCircle, color: "text-red-600 dark:text-red-400" },
  active: { label: "ACTIVE", icon: Circle, color: "text-amber-600 dark:text-amber-400" },
  pending: { label: "PENDING", icon: Circle, color: "text-muted-foreground" },
};

export function TheoremDeepDive({ claim }: { claim: ClaimWithRelations }) {
  return (
    <Card className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Theorem Deep-Dive</h3>
          <p className="font-mono text-[10px] text-muted-foreground">
            5-theorem substrate · live status for this claim
          </p>
        </div>
        <span className="rounded border border-foreground/20 bg-muted px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wider text-muted-foreground">
          EIS substrate
        </span>
      </div>
      <div className="space-y-2">
        {THEOREMS.map((t) => {
          const { status, detail } = t.statusFor(claim);
          const Icon = t.icon;
          const StatusIcon = STATUS_META[status].icon;
          return (
            <div
              key={t.id}
              className={cn("rounded-md border p-2.5 transition-colors", t.border, t.bg)}
            >
              <div className="flex items-start gap-2">
                <span className={cn("mt-0.5 rounded p-1", t.bg)}>
                  <Icon className={cn("h-3.5 w-3.5", t.color)} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <span className={cn("font-mono text-[10px] font-bold", t.color)}>
                        T{t.id}
                      </span>
                      <span className="text-xs font-semibold">{t.name}</span>
                    </div>
                    <span
                      className={cn(
                        "inline-flex items-center gap-1 rounded-full border border-border bg-background/60 px-1.5 py-0.5 font-mono text-[9px] font-bold uppercase tracking-wider",
                        STATUS_META[status].color,
                      )}
                    >
                      <StatusIcon className="h-2.5 w-2.5" />
                      {STATUS_META[status].label}
                    </span>
                  </div>
                  <p className="mt-0.5 font-mono text-[10px] leading-snug text-muted-foreground">
                    {t.statement}
                  </p>
                  <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1">
                    <code className="rounded bg-background/60 px-1.5 py-0.5 font-mono text-[10px] text-foreground">
                      {t.formula}
                    </code>
                    <span className={cn("font-mono text-[10px]", STATUS_META[status].color)}>
                      {detail}
                    </span>
                    <span className="font-mono text-[9px] text-muted-foreground">
                      module: {t.module}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <p className="mt-3 font-mono text-[10px] leading-snug text-muted-foreground">
        Each theorem is a formal guarantee implemented in the EIS library. The status reflects
        the current claim's position in the verification pipeline — pass = satisfied, fail =
        broken, active = running, pending = awaiting input.
      </p>
    </Card>
  );
}
