"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, ShieldAlert, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import type { AuthorizationResult } from "@/lib/eis";

const CONJUNCTS: { symbol: string; label: string; description: string }[] = [
  { symbol: "C", label: "Claim", description: "claim state ≥ SUPPORTED (and not FALSIFIED)" },
  { symbol: "E", label: "Evidence", description: "≥ 1 item AND (≥ 2 sources OR ≥ 3 items)" },
  { symbol: "I", label: "Integrity", description: "N_ind ≥ threshold − 0.3" },
  { symbol: "S", label: "Safety", description: "safety override (safety-critical only)" },
  { symbol: "R", label: "Review", description: "reviewer sign-off (safety-critical only)" },
];

export function AuthorizationPanel({
  auth,
  safetyCritical,
  onAuthorize,
  loading,
}: {
  auth: AuthorizationResult | null;
  safetyCritical: boolean;
  onAuthorize?: (safetyOverride: boolean, reviewSignedOff: boolean) => void;
  loading?: boolean;
}) {
  return (
    <Card className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Authorization</h3>
          <p className="font-mono text-[10px] text-muted-foreground">A = C ∧ E ∧ I ∧ S ∧ R</p>
        </div>
        <span className="rounded border border-emerald-500/30 bg-emerald-500/10 px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wider text-emerald-700 dark:text-emerald-300">
          Theorem 1, 4
        </span>
      </div>
      {!auth ? (
        <div className="rounded-md border border-dashed border-border/60 bg-muted/30 p-4 text-center font-mono text-[11px] text-muted-foreground">
          No authorization record yet. Run /api/authorize to evaluate A = C ∧ E ∧ I ∧ S ∧ R.
        </div>
      ) : (
        <div className="space-y-3">
          <div className="grid grid-cols-5 gap-2">
            {CONJUNCTS.map((c, i) => {
              const ok = [
                auth.claimOk,
                auth.evidenceOk,
                auth.integrityOk,
                auth.safetyOk,
                auth.reviewOk,
              ][i];
              const required = i < 3 || safetyCritical;
              return (
                <div
                  key={c.symbol}
                  className={cn(
                    "rounded-md border p-2 text-center",
                    ok
                      ? "border-emerald-500/30 bg-emerald-500/10"
                      : required
                        ? "border-red-500/30 bg-red-500/10"
                        : "border-border bg-muted/30",
                  )}
                >
                  <div className="flex items-center justify-center">
                    {ok ? (
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                    ) : required ? (
                      <XCircle className="h-3.5 w-3.5 text-red-600 dark:text-red-400" />
                    ) : (
                      <CheckCircle2 className="h-3.5 w-3.5 text-muted-foreground" />
                    )}
                  </div>
                  <div className="mt-1 font-mono text-base font-bold">{c.symbol}</div>
                  <div className="text-[9px] uppercase tracking-wider text-muted-foreground">
                    {c.label}
                  </div>
                </div>
              );
            })}
          </div>
          <div
            className={cn(
              "flex items-center gap-2 rounded-md border-2 p-3",
              auth.authorized
                ? "border-emerald-500/50 bg-emerald-500/5"
                : "border-red-500/50 bg-red-500/5",
            )}
          >
            {auth.authorized ? (
              <ShieldCheck className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
            ) : (
              <ShieldAlert className="h-5 w-5 text-red-600 dark:text-red-400" />
            )}
            <div>
              <div
                className={cn(
                  "font-mono text-lg font-bold tracking-wider",
                  auth.authorized
                    ? "text-emerald-700 dark:text-emerald-300"
                    : "text-red-700 dark:text-red-300",
                )}
              >
                A = {auth.authorized ? "TRUE" : "FALSE"}
              </div>
              <div className="font-mono text-[10px] leading-snug text-muted-foreground">
                {auth.reason}
              </div>
            </div>
          </div>
          {safetyCritical && onAuthorize && (
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              <Button
                size="sm"
                variant="outline"
                onClick={() => onAuthorize(true, false)}
                disabled={loading}
                className="border-amber-500/40 bg-amber-500/10 text-amber-700 hover:bg-amber-500/20 dark:text-amber-300"
              >
                Approve Safety (S)
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onAuthorize(false, true)}
                disabled={loading}
                className="border-cyan-500/40 bg-cyan-500/10 text-cyan-700 hover:bg-cyan-500/20 dark:text-cyan-300"
              >
                Sign Review (R)
              </Button>
              <Button
                size="sm"
                onClick={() => onAuthorize(true, true)}
                disabled={loading}
                className="bg-emerald-600 text-white hover:bg-emerald-700"
              >
                Approve Both
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => onAuthorize(false, false)}
                disabled={loading}
              >
                Re-run
              </Button>
            </div>
          )}
        </div>
      )}
    </Card>
  );
}
