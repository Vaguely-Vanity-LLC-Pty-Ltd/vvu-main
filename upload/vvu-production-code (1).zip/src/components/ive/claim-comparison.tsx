"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GitCompare, X, CheckCircle2, XCircle, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ClaimWithRelations } from "@/lib/eis";
import { StateBadge } from "./state-badge";

const CONJUNCTS = [
  { symbol: "C", label: "Claim" },
  { symbol: "E", label: "Evidence" },
  { symbol: "I", label: "Integrity" },
  { symbol: "S", label: "Safety" },
  { symbol: "R", label: "Review" },
] as const;

export function ClaimComparison({
  claims,
  onSelectClaim,
}: {
  claims: ClaimWithRelations[];
  onSelectClaim?: (id: string) => void;
}) {
  const [leftId, setLeftId] = useState<string | null>(claims[0]?.id ?? null);
  const [rightId, setRightId] = useState<string | null>(claims[1]?.id ?? null);

  const left = claims.find((c) => c.id === leftId) ?? null;
  const right = claims.find((c) => c.id === rightId) ?? null;

  const leftAuth = left?.authorizations[0] ?? null;
  const rightAuth = right?.authorizations[0] ?? null;

  const leftNInd = left?.nIndRecords[0]?.nInd ?? 0;
  const rightNInd = right?.nIndRecords[0]?.nInd ?? 0;

  return (
    <Card className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="flex items-center gap-1.5 text-sm font-semibold">
            <GitCompare className="h-3.5 w-3.5" />
            Claim Comparison
          </h3>
          <p className="font-mono text-[10px] text-muted-foreground">
            side-by-side conjunct diff · A = C ∧ E ∧ I ∧ S ∧ R
          </p>
        </div>
        <span className="rounded border border-foreground/20 bg-muted px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wider text-muted-foreground">
          Theorem 1, 4
        </span>
      </div>

      <div className="grid grid-cols-1 gap-3 md:grid-cols-[1fr_auto_1fr]">
        {/* LEFT */}
        <ClaimSelectColumn
          title="Left"
          claims={claims}
          selectedId={leftId}
          onSelect={setLeftId}
          claim={left}
          auth={leftAuth}
          nInd={leftNInd}
          onSelectClaim={onSelectClaim}
        />

        {/* DIFF ARROW */}
        <div className="flex flex-col items-center justify-center gap-2 py-2 md:py-0">
          <div className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            diff
          </div>
          <div className="flex flex-1 flex-col items-center justify-center gap-1.5 md:flex-row">
            {CONJUNCTS.map((c) => {
              const lOk = leftAuth
                ? (leftAuth as any)[
                    c.symbol === "C"
                      ? "claimOk"
                      : c.symbol === "E"
                        ? "evidenceOk"
                        : c.symbol === "I"
                          ? "integrityOk"
                          : c.symbol === "S"
                            ? "safetyOk"
                            : "reviewOk"
                  ]
                : null;
              const rOk = rightAuth
                ? (rightAuth as any)[
                    c.symbol === "C"
                      ? "claimOk"
                      : c.symbol === "E"
                        ? "evidenceOk"
                        : c.symbol === "I"
                          ? "integrityOk"
                          : c.symbol === "S"
                            ? "safetyOk"
                            : "reviewOk"
                  ]
                : null;
              const differ = lOk !== null && rOk !== null && lOk !== rOk;
              const bothOk = lOk === true && rOk === true;
              const bothFail = lOk === false && rOk === false;
              const color = differ
                ? "text-amber-700 dark:text-amber-300 bg-amber-500/10 border-amber-500/40"
                : bothOk
                  ? "text-emerald-700 dark:text-emerald-300 bg-emerald-500/10 border-emerald-500/30"
                  : bothFail
                    ? "text-red-700 dark:text-red-300 bg-red-500/10 border-red-500/30"
                    : "text-muted-foreground bg-muted/40 border-border";
              return (
                <div
                  key={c.symbol}
                  className={cn("flex items-center gap-1 rounded-md border px-1.5 py-0.5", color)}
                  title={`${c.label}: left=${lOk === null ? "—" : lOk ? "✓" : "✗"}, right=${rOk === null ? "—" : rOk ? "✓" : "✗"}`}
                >
                  <span className="font-mono text-[10px] font-bold">{c.symbol}</span>
                  {differ && <span className="font-mono text-[8px]">≠</span>}
                </div>
              );
            })}
          </div>
          <ArrowRight className="hidden h-4 w-4 text-muted-foreground md:block" />
        </div>

        {/* RIGHT */}
        <ClaimSelectColumn
          title="Right"
          claims={claims}
          selectedId={rightId}
          onSelect={setRightId}
          claim={right}
          auth={rightAuth}
          nInd={rightNInd}
          onSelectClaim={onSelectClaim}
        />
      </div>

      <p className="mt-3 font-mono text-[10px] leading-snug text-muted-foreground">
        Green = both pass · Red = both fail · Amber = they differ. Compare conjuncts across
        claims to see where the verification pipeline diverges.
      </p>
    </Card>
  );
}

function ClaimSelectColumn({
  title,
  claims,
  selectedId,
  onSelect,
  claim,
  auth,
  nInd,
  onSelectClaim,
}: {
  title: string;
  claims: ClaimWithRelations[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  claim: ClaimWithRelations | null;
  auth: any;
  nInd: number;
  onSelectClaim?: (id: string) => void;
}) {
  return (
    <div className="rounded-md border border-border bg-card p-2.5">
      <div className="mb-2 flex items-center justify-between gap-2">
        <span className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
          {title}
        </span>
        {claim && onSelectClaim && (
          <button
            onClick={() => onSelectClaim(claim.id)}
            className="font-mono text-[9px] text-emerald-700 hover:underline dark:text-emerald-300"
          >
            open →
          </button>
        )}
      </div>
      <select
        value={selectedId ?? ""}
        onChange={(e) => onSelect(e.target.value)}
        className="mb-2 w-full rounded-md border border-input bg-background px-2 py-1 font-mono text-[11px]"
      >
        {claims.map((c) => (
          <option key={c.id} value={c.id}>
            {c.title.slice(0, 50)}
            {c.title.length > 50 ? "…" : ""} · {c.estateKey}
          </option>
        ))}
      </select>

      {claim ? (
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5">
            <StateBadge state={claim.state} size="sm" />
            <span className="font-mono text-[9px] text-muted-foreground">
              {claim.claimType} · {claim.estateKey}
            </span>
          </div>
          <div className="grid grid-cols-5 gap-1">
            {CONJUNCTS.map((c) => {
              const ok = auth
                ? auth[
                    c.symbol === "C"
                      ? "claimOk"
                      : c.symbol === "E"
                        ? "evidenceOk"
                        : c.symbol === "I"
                          ? "integrityOk"
                          : c.symbol === "S"
                            ? "safetyOk"
                            : "reviewOk"
                  ]
                : null;
              return (
                <div
                  key={c.symbol}
                  className={cn(
                    "rounded border p-1 text-center",
                    ok === true
                      ? "border-emerald-500/30 bg-emerald-500/10"
                      : ok === false
                        ? "border-red-500/30 bg-red-500/10"
                        : "border-border bg-muted/30",
                  )}
                  title={c.label}
                >
                  <div className="flex justify-center">
                    {ok === true ? (
                      <CheckCircle2 className="h-3 w-3 text-emerald-600 dark:text-emerald-400" />
                    ) : ok === false ? (
                      <XCircle className="h-3 w-3 text-red-600 dark:text-red-400" />
                    ) : (
                      <span className="text-[9px] text-muted-foreground">—</span>
                    )}
                  </div>
                  <div className="mt-0.5 font-mono text-[9px] font-bold">{c.symbol}</div>
                </div>
              );
            })}
          </div>
          <div className="grid grid-cols-2 gap-1 font-mono text-[9px]">
            <div className="rounded border border-border bg-muted/30 px-1.5 py-1">
              <span className="text-muted-foreground">ev:</span>{" "}
              <span className="font-bold">{claim.evidence.length}</span>
            </div>
            <div className="rounded border border-border bg-muted/30 px-1.5 py-1">
              <span className="text-muted-foreground">N_ind:</span>{" "}
              <span className="font-bold">{nInd.toFixed(2)}</span>
            </div>
          </div>
          <div
            className={cn(
              "rounded-md border-2 p-1.5 text-center",
              auth?.authorized
                ? "border-emerald-500/50 bg-emerald-500/5"
                : "border-red-500/50 bg-red-500/5",
            )}
          >
            <span
              className={cn(
                "font-mono text-sm font-bold tracking-wider",
                auth?.authorized
                  ? "text-emerald-700 dark:text-emerald-300"
                  : "text-red-700 dark:text-red-300",
              )}
            >
              A = {auth?.authorized ? "TRUE" : "FALSE"}
            </span>
          </div>
        </div>
      ) : (
        <p className="font-mono text-[11px] text-muted-foreground">Select a claim.</p>
      )}
    </div>
  );
}
