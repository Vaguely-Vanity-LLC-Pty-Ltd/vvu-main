"use client";

import { Card } from "@/components/ui/card";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import {
  STATE_DESCRIPTIONS,
  STATE_RANK,
  statesInOrder,
  type VerificationState,
} from "@/lib/eis";

const ORDER: VerificationState[] = statesInOrder();

export function StateLattice({ current }: { current: VerificationState }) {
  const currentRank = STATE_RANK[current];
  return (
    <Card className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Verification State Lattice</h3>
          <p className="font-mono text-[10px] text-muted-foreground">
            state(c) = max &#123; state(e) &#125; capped by claimType
          </p>
        </div>
        <span className="rounded border border-emerald-500/30 bg-emerald-500/10 px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wider text-emerald-700 dark:text-emerald-300">
          Theorem 4
        </span>
      </div>
      <TooltipProvider delayDuration={150}>
        <div className="flex flex-wrap items-end gap-1">
          {ORDER.map((s, i) => {
            const rank = STATE_RANK[s];
            const isCurrent = s === current;
            const isReached = s !== "FALSIFIED" && rank <= currentRank && current !== "FALSIFIED";
            const isFalsified = s === "FALSIFIED";
            const showSeparator = i < ORDER.length - 1;
            const sepLabel = isFalsified ? "⊥" : "≥";
            return (
              <div key={s} className="flex items-end gap-1">
                <div className="flex flex-col items-center gap-0.5">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span
                        className={cn(
                          "cursor-help rounded-md border px-2 py-1 font-mono text-[10px] font-semibold tracking-wide",
                          isFalsified && isCurrent && "bg-red-500 text-white border-red-600",
                          !isFalsified && isCurrent && "bg-foreground text-background border-foreground",
                          !isCurrent && isReached && !isFalsified && "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/40",
                          !isCurrent && (!isReached || isFalsified) && "bg-muted/50 text-muted-foreground border-border",
                        )}
                      >
                        {s}
                      </span>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <div className="space-y-1">
                        <div className="font-mono text-[11px] font-bold">{s}</div>
                        <div className="text-[10px] leading-snug text-muted-foreground">
                          {STATE_DESCRIPTIONS[s]}
                        </div>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                  {/* ↓ current marker — appears only under the active badge */}
                  <span
                    className={cn(
                      "font-mono text-[9px] font-bold leading-none",
                      isCurrent
                        ? "text-foreground"
                        : "text-transparent",
                    )}
                    aria-hidden={!isCurrent}
                  >
                    ↓ current
                  </span>
                </div>
                {showSeparator && (
                  <span className="pb-3 font-mono text-[10px] text-muted-foreground">{sepLabel}</span>
                )}
              </div>
            );
          })}
        </div>
      </TooltipProvider>
      <p className="mt-3 font-mono text-[10px] text-muted-foreground">
        PROVEN ≥ VERIFIED ≥ SUPPORTED ≥ OBSERVED ≥ INCONCLUSIVE — FALSIFIED is incomparable and terminal.
      </p>
    </Card>
  );
}
