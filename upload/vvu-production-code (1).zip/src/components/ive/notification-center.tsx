"use client";

import { useEffect, useState, useRef } from "react";
import {
  Bell,
  X,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Info,
  Zap,
  Trash2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export interface Notification {
  id: string;
  title: string;
  description?: string;
  variant: "default" | "destructive" | "warning" | "info";
  at: number; // epoch ms
  read?: boolean;
  // optional deep link
  claimId?: string;
}

const STORAGE_KEY = "vvu-ive-notifications";
const MAX_NOTIFICATIONS = 50;
const CHANGED_EVENT = "vvu-ive-notifications-changed";

// Global in-memory bus so the NotificationCenter can subscribe to toast events.
type Listener = (n: Notification) => void;
const listeners = new Set<Listener>();

export function pushNotification(n: Omit<Notification, "id" | "at" | "read">) {
  const full: Notification = {
    ...n,
    id: `n-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    at: Date.now(),
    read: false,
  };
  // persist to localStorage
  try {
    if (typeof window !== "undefined") {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      const arr: Notification[] = raw ? JSON.parse(raw) : [];
      arr.unshift(full);
      const trimmed = arr.slice(0, MAX_NOTIFICATIONS);
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
      window.dispatchEvent(new Event(CHANGED_EVENT));
    }
  } catch {
    /* ignore */
  }
  // notify in-memory listeners (for the bell badge counter)
  listeners.forEach((l) => l(full));
}

function readNotifications(): Notification[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function writeNotifications(arr: Notification[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(arr));
    window.dispatchEvent(new Event(CHANGED_EVENT));
  } catch {
    /* ignore */
  }
}

const VARIANT_META: Record<
  Notification["variant"],
  { icon: typeof CheckCircle2; color: string; bg: string; border: string }
> = {
  default: {
    icon: CheckCircle2,
    color: "text-emerald-700 dark:text-emerald-300",
    bg: "bg-emerald-500/10",
    border: "border-emerald-500/30",
  },
  destructive: {
    icon: XCircle,
    color: "text-red-700 dark:text-red-300",
    bg: "bg-red-500/10",
    border: "border-red-500/30",
  },
  warning: {
    icon: AlertTriangle,
    color: "text-amber-700 dark:text-amber-300",
    bg: "bg-amber-500/10",
    border: "border-amber-500/30",
  },
  info: {
    icon: Info,
    color: "text-cyan-700 dark:text-cyan-300",
    bg: "bg-cyan-500/10",
    border: "border-cyan-500/30",
  },
};

function formatRelative(at: number): string {
  const diff = Date.now() - at;
  if (diff < 60_000) return `${Math.max(1, Math.floor(diff / 1000))}s ago`;
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`;
  return `${Math.floor(diff / 86_400_000)}d ago`;
}

export function NotificationCenter({
  onSelectClaim,
}: {
  onSelectClaim?: (id: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const load = () => setNotifications(readNotifications());
    load();
    const onChange = () => load();
    window.addEventListener(CHANGED_EVENT, onChange);
    window.addEventListener("storage", onChange);
    return () => {
      window.removeEventListener(CHANGED_EVENT, onChange);
      window.removeEventListener("storage", onChange);
    };
  }, []);

  // close on outside click
  useEffect(() => {
    if (!open) return;
    const onDocClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, [open]);

  const unread = notifications.filter((n) => !n.read).length;

  const markAllRead = () => {
    const next = notifications.map((n) => ({ ...n, read: true }));
    writeNotifications(next);
  };

  const clearAll = () => {
    writeNotifications([]);
  };

  const removeOne = (id: string) => {
    writeNotifications(notifications.filter((n) => n.id !== id));
  };

  return (
    <div className="relative" ref={ref}>
      <Button
        variant="outline"
        size="sm"
        onClick={() => setOpen((v) => !v)}
        className="relative gap-1"
        title="Notifications"
      >
        <Bell className="h-3.5 w-3.5" />
        {unread > 0 && (
          <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 font-mono text-[9px] font-bold text-white">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </Button>

      {open && (
        <div className="absolute right-0 z-50 mt-2 w-80 overflow-hidden rounded-lg border border-border bg-card shadow-xl">
          {/* header */}
          <div className="flex items-center justify-between border-b border-border px-3 py-2">
            <div className="flex items-center gap-1.5">
              <Bell className="h-3.5 w-3.5" />
              <span className="text-sm font-semibold">Notifications</span>
              {unread > 0 && (
                <span className="rounded-full bg-red-500/15 px-1.5 py-0.5 font-mono text-[9px] font-bold text-red-700 dark:text-red-300">
                  {unread} new
                </span>
              )}
            </div>
            <div className="flex items-center gap-1">
              {unread > 0 && (
                <button
                  onClick={markAllRead}
                  className="rounded px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-wider text-muted-foreground hover:bg-muted/50 hover:text-foreground"
                  title="Mark all as read"
                >
                  read all
                </button>
              )}
              {notifications.length > 0 && (
                <button
                  onClick={clearAll}
                  className="rounded px-1.5 py-0.5 text-muted-foreground hover:bg-muted/50 hover:text-foreground"
                  title="Clear all"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              )}
            </div>
          </div>

          {/* list */}
          <div className="ive-scroll max-h-96 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-8 text-center">
                <Bell className="h-6 w-6 text-muted-foreground/40" />
                <p className="font-mono text-[11px] text-muted-foreground">
                  No notifications yet.
                </p>
                <p className="font-mono text-[9px] text-muted-foreground">
                  Breaker trips, authorizations, and pipeline runs appear here.
                </p>
              </div>
            ) : (
              notifications.map((n) => {
                const meta = VARIANT_META[n.variant];
                const Icon = meta.icon;
                return (
                  <div
                    key={n.id}
                    className={cn(
                      "group relative flex gap-2 border-b border-border/50 px-3 py-2 transition-colors hover:bg-muted/30",
                      !n.read && "bg-muted/20",
                    )}
                  >
                    {/* unread indicator */}
                    {!n.read && (
                      <span className="absolute left-1 top-1/2 h-1.5 w-1.5 -translate-y-1/2 rounded-full bg-emerald-500" />
                    )}
                    <span className={cn("mt-0.5 shrink-0 rounded p-1", meta.bg)}>
                      <Icon className={cn("h-3 w-3", meta.color)} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-xs font-semibold leading-tight">
                          {n.title}
                        </span>
                        <span className="shrink-0 font-mono text-[9px] text-muted-foreground">
                          {formatRelative(n.at)}
                        </span>
                      </div>
                      {n.description && (
                        <p className="mt-0.5 line-clamp-2 font-mono text-[10px] leading-snug text-muted-foreground">
                          {n.description}
                        </p>
                      )}
                      {n.claimId && onSelectClaim && (
                        <button
                          onClick={() => {
                            onSelectClaim(n.claimId!);
                            setOpen(false);
                          }}
                          className="mt-1 font-mono text-[9px] text-emerald-700 hover:underline dark:text-emerald-300"
                        >
                          open claim →
                        </button>
                      )}
                    </div>
                    <button
                      onClick={() => removeOne(n.id)}
                      className="absolute right-1 top-1 opacity-0 transition-opacity hover:text-foreground group-hover:opacity-100"
                      title="Dismiss"
                    >
                      <X className="h-3 w-3 text-muted-foreground" />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}
