'use client';

/**
 * IveVerifyWorkspace — the IVE (Integrated Verification Environment) projection.
 * Wraps the standalone IVE dashboard into a workspace component for the hash router.
 * 
 * Accessible via #/ive-verify in the main dashboard.
 * 
 * The IVE is the 5-theorem verification cockpit:
 * 1. Evidence Bound — minimum independent evidence required
 * 2. N_ind — participation ratio from Gram matrix eigenvalues
 * 3. Heat-Kernel — epistemic diffusion across the evidence mesh
 * 4. State-Lattice Closure — 9-value verification lattice
 * 5. Fail-Closed Circuit Breaker — loss of E(S) → loss of V(S) → loss of A(S)
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ShieldCheck, Activity, Database, RefreshCw, Plus,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { StateBadge } from '@/components/ive/state-badge';
import { StateLattice } from '@/components/ive/state-lattice';
import { AuthorizationPanel } from '@/components/ive/authorization-panel';
import { EvidenceMeshPanel } from '@/components/ive/evidence-mesh-panel';
import { ParticipationRatioPanel } from '@/components/ive/participation-ratio-panel';
import { HeatKernelPanel } from '@/components/ive/heat-kernel-panel';
import { CircuitBreakerPanel } from '@/components/ive/circuit-breaker-panel';
import { EstatesPanel, type EstateSummary } from '@/components/ive/estates-panel';
import { GlobalStatsHero } from '@/components/ive/global-stats-hero';
import { VerdictBanner } from '@/components/ive/verdict-banner';
import { KeyboardHintBar } from '@/components/ive/keyboard-hint-bar';
import type {
  AuthorizationRecord,
  CircuitBreakerRecord,
  ClaimWithRelations,
  EstateKey,
  EstateSummary as EstateSum,
} from '@/lib/eis/types';

// Fallback types if the EIS types don't export everything
type Claim = {
  id: string;
  title: string;
  state: string;
  claimType?: string;
  safetyCritical?: boolean;
  estateKey?: string;
};

type Stats = {
  totalClaims: number;
  verified: number;
  falsified: number;
  authorized: number;
  circuitsTripped: number;
};

const MOCK_ESTATES: EstateSummary[] = [
  { key: 'canonical', name: 'Canonical IVE', description: 'IVE native demo claims', accent: 'cyan', theorem: 'Evidence Bound', claimCount: 0, evidenceCount: 0, verifiedCount: 0 },
  { key: 'hbk-mk2', name: 'HBK Mk-II', description: 'Hydro-Bayesian Kernel', accent: 'amber', theorem: 'Joukowsky Celerity', claimCount: 0, evidenceCount: 0, verifiedCount: 0 },
  { key: 'skylantern', name: 'Skylantern', description: 'Commercial pilot readiness', accent: 'emerald', theorem: 'Zero Fabrication', claimCount: 0, evidenceCount: 0, verifiedCount: 0 },
];

export function IveVerifyWorkspace() {
  const { toast } = useToast();
  const [claims, setClaims] = useState<Claim[]>([]);
  const [selectedClaim, setSelectedClaim] = useState<Claim | null>(null);
  const [stats, setStats] = useState<Stats>({
    totalClaims: 0, verified: 0, falsified: 0, authorized: 0, circuitsTripped: 0,
  });
  const [estates, setEstates] = useState<EstateSummary[]>(MOCK_ESTATES);
  const [loading, setLoading] = useState(true);

  // Fetch initial state from the IVE API
  useEffect(() => {
    const id = requestAnimationFrame(async () => {
      try {
        const res = await fetch('/api/ive/state');
        if (res.ok) {
          const data = await res.json();
          if (data.claims) setClaims(data.claims);
          if (data.stats) setStats(data.stats);
          if (data.estates) setEstates(data.estates);
        }
      } catch {
        // API may not be seeded yet — use mock data
      } finally {
        setLoading(false);
      }
    });
    return () => cancelAnimationFrame(id);
  }, []);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch('/api/ive/seed', { method: 'POST' });
      if (res.ok) {
        toast({ title: 'IVE seeded', description: 'Verification lattice initialized' });
        const stateRes = await fetch('/api/ive/state');
        if (stateRes.ok) {
          const data = await stateRes.json();
          if (data.claims) setClaims(data.claims);
          if (data.stats) setStats(data.stats);
        }
      }
    } catch {
      toast({ title: 'IVE', description: 'Using demo mode' });
    }
  }, [toast]);

  return (
    <div className="flex h-full flex-col overflow-hidden bg-[#06080c]">
      {/* Header strip */}
      <div className="flex items-center gap-3 border-b border-border/40 px-4 py-2">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-[#c8ff00]" />
          <span className="text-xs font-bold tracking-tight text-[#c8ff00]">IVE</span>
          <span className="text-[10px] text-muted-foreground">Integrated Verification Environment</span>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Button size="sm" variant="outline" className="h-7 gap-1 text-[10px]" onClick={refresh}>
            <RefreshCw className="h-3 w-3" /> Seed
          </Button>
        </div>
      </div>

      {/* Stats hero */}
      <div className="px-4 py-2">
        <GlobalStatsHero stats={stats} loading={loading} />
      </div>

      {/* Verdict banner */}
      <div className="px-4 pb-2">
        <VerdictBanner stats={stats} />
      </div>

      {/* Main content — scrollable */}
      <div className="flex-1 overflow-y-auto px-4 pb-4">
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
          {/* Left column */}
          <div className="space-y-3">
            <Card className="border-border bg-[#0a0f18] p-3">
              <h3 className="mb-2 text-xs font-semibold text-[#c8ff00]">State Lattice (9 values)</h3>
              <StateLattice claims={claims} selectedClaim={selectedClaim} onSelect={setSelectedClaim} />
            </Card>
            <Card className="border-border bg-[#0a0f18] p-3">
              <h3 className="mb-2 text-xs font-semibold text-[#6B8A40]">Estates</h3>
              <EstatesPanel estates={estates} />
            </Card>
          </div>

          {/* Right column */}
          <div className="space-y-3">
            <Card className="border-border bg-[#0a0f18] p-3">
              <h3 className="mb-2 text-xs font-semibold text-[#a78bfa]">Authorization (A=C∧E∧I∧S∧R)</h3>
              <AuthorizationPanel />
            </Card>
            <Card className="border-border bg-[#0a0f18] p-3">
              <h3 className="mb-2 text-xs font-semibold text-[#38bdf8]">Evidence Mesh</h3>
              <EvidenceMeshPanel />
            </Card>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Card className="border-border bg-[#0a0f18] p-3">
                <h3 className="mb-2 text-xs font-semibold text-[#fb923c]">N_ind Participation</h3>
                <ParticipationRatioPanel />
              </Card>
              <Card className="border-border bg-[#0a0f18] p-3">
                <h3 className="mb-2 text-xs font-semibold text-[#ef4444]">Circuit Breaker</h3>
                <CircuitBreakerPanel />
              </Card>
            </div>
            <Card className="border-border bg-[#0a0f18] p-3">
              <h3 className="mb-2 text-xs font-semibold text-[#22c55e]">Heat Kernel Diffusion</h3>
              <HeatKernelPanel />
            </Card>
          </div>
        </div>
      </div>

      {/* Keyboard hint bar */}
      <KeyboardHintBar />
    </div>
  );
}
