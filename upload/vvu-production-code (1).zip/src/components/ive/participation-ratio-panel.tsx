"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sigma, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ParticipationRatioResult } from "@/lib/eis";

export function ParticipationRatioPanel({
  result,
  threshold = 2,
  loading,
  onRecompute,
}: {
  result: ParticipationRatioResult | null;
  threshold?: number;
  loading?: boolean;
  onRecompute?: () => void;
}) {
  return (
    <Card className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="flex items-center gap-1.5 text-sm font-semibold">
            <Sigma className="h-3.5 w-3.5" />
            Participation Ratio
          </h3>
          <p className="font-mono text-[10px] text-muted-foreground">
            N_ind = (Σλ_i)² / Σλ_i²
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="rounded border border-emerald-500/30 bg-emerald-500/10 px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wider text-emerald-700 dark:text-emerald-300">
            Theorem 2
          </span>
          {onRecompute && (
            <Button size="sm" variant="outline" onClick={onRecompute} disabled={loading}>
              {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : null}
              Recompute
            </Button>
          )}
        </div>
      </div>
      {!result ? (
        <div className="rounded-md border border-dashed border-border/60 bg-muted/30 p-4 text-center font-mono text-[11px] text-muted-foreground">
          No N_ind computation yet. Run /api/n-ind to compute participation ratio.
        </div>
      ) : (
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            <div
              className={cn(
                "rounded-md border p-2 text-center",
                result.nInd >= threshold - 0.3
                  ? "border-emerald-500/30 bg-emerald-500/10"
                  : "border-red-500/30 bg-red-500/10",
              )}
            >
              <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                N_ind
              </div>
              <div className="font-mono text-lg font-bold">{result.nInd.toFixed(2)}</div>
            </div>
            <div className="rounded-md border border-border bg-card p-2 text-center">
              <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                Sources
              </div>
              <div className="font-mono text-lg font-bold">{result.numSources}</div>
            </div>
            <div className="rounded-md border border-border bg-card p-2 text-center">
              <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                γ (RBF)
              </div>
              <div className="font-mono text-lg font-bold">{result.gamma.toFixed(2)}</div>
            </div>
          </div>
          <div>
            <div className="mb-1 flex items-center justify-between">
              <span className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                Eigenvalue spectrum
              </span>
              <span className="font-mono text-[9px] text-muted-foreground">
                {result.eigenvalues.length} λ · top {Math.min(12, result.eigenvalues.length)} shown
              </span>
            </div>
            <div className="relative flex h-20 items-end gap-0.5 rounded-md border bg-muted/20 p-1.5">
              {/* baseline axis line */}
              <div className="pointer-events-none absolute inset-x-1.5 bottom-1.5 h-px bg-border" />
              {result.eigenvalues.slice(0, 12).map((v, i) => {
                const max = Math.max(...result.eigenvalues.map((x) => Math.abs(x)), 1e-9);
                const h = (Math.abs(v) / max) * 100;
                const significant = Math.abs(v) / max > 0.1;
                return (
                  <div
                    key={i}
                    title={`λ_${i + 1} = ${v.toFixed(4)}`}
                    className="relative flex-1 rounded-t transition-all hover:opacity-80"
                    style={{
                      height: `${Math.max(2, h)}%`,
                      background: significant
                        ? "linear-gradient(to top, oklch(0.646 0.222 41.116), oklch(0.7 0.18 60))"
                        : "var(--muted-foreground)",
                      opacity: significant ? 1 : 0.4,
                    }}
                  >
                    {significant && i < 4 && (
                      <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 font-mono text-[7px] text-muted-foreground">
                        {v.toFixed(2)}
                      </span>
                    )}
                  </div>
                );
              })}
              {result.eigenvalues.length === 0 && (
                <div className="w-full text-center font-mono text-[10px] text-muted-foreground">
                  no eigenvalues
                </div>
              )}
            </div>
          </div>
          <p className="font-mono text-[10px] leading-snug text-muted-foreground">
            Median-heuristic γ = 1 / median(‖φ_i − φ_j‖²). Monotonic non-decreasing in true
            source count m.
          </p>
        </div>
      )}
    </Card>
  );
}
