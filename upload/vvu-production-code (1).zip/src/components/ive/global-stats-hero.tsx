"use client";

import { cn } from "@/lib/utils";
import {
  Layers,
  ShieldCheck,
  ShieldAlert,
  Database,
  GitBranch,
  Activity,
  Zap,
} from "lucide-react";

interface Summary {
  totalClaims: number;
  authorizedClaims: number;
  breakerTripped: number;
  totalEvidence: number;
  stateCounts: Record<string, number>;
  evidenceBound: string;
  authorizationFormula: string;
  failClosed: boolean;
}

// Verification-state → color (mirrors state-badge + estates-panel palette).
const STATE_COLORS: Record<string, string> = {
  PROVEN: "oklch(0.646 0.222 41.116)", // emerald
  VERIFIED: "oklch(0.696 0.17 162.48)", // green
  SUPPORTED: "oklch(0.768 0.188 70.08)", // lime-ish — use a brighter green-yellow
  OBSERVED: "oklch(0.7 0.15 75)", // amber
  INCONCLUSIVE: "oklch(0.704 0.191 22.216)", // orange
  UNVALIDATED: "oklch(0.556 0 0)", // zinc-ish
  UNTESTED: "oklch(0.556 0 0)", // slate-ish
  STALE: "oklch(0.556 0 0)", // stone-ish
  FALSIFIED: "oklch(0.577 0.245 27.325)", // red
};

const STATE_ORDER = [
  "PROVEN",
  "VERIFIED",
  "SUPPORTED",
  "OBSERVED",
  "INCONCLUSIVE",
  "UNVALIDATED",
  "UNTESTED",
  "STALE",
  "FALSIFIED",
] as const;

export function GlobalStatsHero({
  summary,
  claims,
}: {
  summary: Summary | undefined;
  claims: { claimType: string; state: string }[];
}) {
  const total = summary?.totalClaims ?? 0;
  const authorized = summary?.authorizedClaims ?? 0;
  const tripped = summary?.breakerTripped ?? 0;
  const evidence = summary?.totalEvidence ?? 0;
  const claimTypes = new Set(claims.map((c) => c.claimType)).size;
  const stateValues = Object.keys(summary?.stateCounts ?? {}).length;

  // Donut chart geometry — compute cumulative offsets immutably.
  const stateCounts = summary?.stateCounts ?? {};
  const presentStates = STATE_ORDER.filter((s) => (stateCounts[s] ?? 0) > 0);
  const R = 26;
  const C = 2 * Math.PI * R;
  // precompute the cumulative fractions for offset calculation
  const cumulativeFractions: number[] = [];
  let acc = 0;
  for (const s of presentStates) {
    cumulativeFractions.push(acc);
    acc += total > 0 ? (stateCounts[s] ?? 0) / total : 0;
  }
  const segments = presentStates.map((s, i) => {
    const count = stateCounts[s] ?? 0;
    const fraction = total > 0 ? count / total : 0;
    const dash = fraction * C;
    const offset = -cumulativeFractions[i] * C;
    return { state: s, count, fraction, dash, offset, color: STATE_COLORS[s] ?? "oklch(0.5 0 0)" };
  });

  const kpis = [
    {
      icon: Layers,
      label: "Claims",
      value: total,
      sub: `${claimTypes} types`,
      tone: "neutral" as const,
      theorem: "T1",
      theoremColor: "text-emerald-600 dark:text-emerald-400",
    },
    {
      icon: ShieldCheck,
      label: "Authorized",
      value: authorized,
      sub: total > 0 ? `${Math.round((authorized / total) * 100)}%` : "—",
      tone: "emerald" as const,
      theorem: "A",
      theoremColor: "text-emerald-600 dark:text-emerald-400",
    },
    {
      icon: ShieldAlert,
      label: "Tripped",
      value: tripped,
      sub: total > 0 ? `${Math.round((tripped / total) * 100)}%` : "—",
      tone: tripped > 0 ? ("red" as const) : ("emerald" as const),
      theorem: "T5",
      theoremColor: "text-red-600 dark:text-red-400",
    },
    {
      icon: Database,
      label: "Evidence",
      value: evidence,
      sub: total > 0 ? `${(evidence / total).toFixed(1)} ev/claim` : "—",
      tone: "neutral" as const,
      theorem: "T1",
      theoremColor: "text-emerald-600 dark:text-emerald-400",
    },
    {
      icon: Activity,
      label: "States",
      value: stateValues,
      sub: "lattice values",
      tone: "neutral" as const,
      theorem: "T4",
      theoremColor: "text-cyan-600 dark:text-cyan-400",
    },
  ];

  return (
    <div className="border-b border-border bg-gradient-to-b from-muted/40 to-muted/10">
      <div className="mx-auto flex w-full max-w-[1600px] flex-col gap-3 px-4 py-3 lg:flex-row lg:items-stretch">
        {/* KPI cards */}
        <div className="grid flex-1 grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
          {kpis.map((k) => {
            const Icon = k.icon;
            const toneCls =
              k.tone === "emerald"
                ? "text-emerald-700 dark:text-emerald-300"
                : k.tone === "red"
                  ? "text-red-700 dark:text-red-300"
                  : "text-foreground";
            return (
              <div
                key={k.label}
                className={cn(
                  "group relative flex items-center gap-2 overflow-hidden rounded-md border border-border bg-card p-2.5 transition-all hover:-translate-y-0.5 hover:border-foreground/30 hover:shadow-md",
                )}
                title={`${k.value} · ${k.label}`}
              >
                {/* theorem tag */}
                <span
                  className={cn(
                    "absolute right-1 top-1 font-mono text-[8px] font-bold",
                    k.theoremColor,
                  )}
                >
                  {k.theorem}
                </span>
                <Icon className="h-4 w-4 shrink-0 text-muted-foreground" />
                <div className="min-w-0">
                  <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                    {k.label}
                  </div>
                  <div className={cn("font-mono text-lg font-bold tabular-nums", toneCls)}>
                    {k.value}
                  </div>
                  <div className="font-mono text-[9px] text-muted-foreground">{k.sub}</div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Donut chart — state distribution */}
        <div className="flex items-center gap-3 rounded-md border border-border bg-card p-2.5 lg:w-[280px]">
          <div className="relative h-16 w-16 shrink-0">
            <svg viewBox="0 0 64 64" className="h-full w-full -rotate-90">
              {/* background ring */}
              <circle cx="32" cy="32" r={R} fill="none" stroke="var(--muted)" strokeWidth="6" />
              {segments.map((seg) => (
                <circle
                  key={seg.state}
                  cx="32"
                  cy="32"
                  r={R}
                  fill="none"
                  stroke={seg.color}
                  strokeWidth="6"
                  strokeDasharray={`${seg.dash} ${C - seg.dash}`}
                  strokeDashoffset={seg.offset}
                  className="transition-all duration-500"
                >
                  <title>
                    {seg.state}: {seg.count} ({(seg.fraction * 100).toFixed(0)}%)
                  </title>
                </circle>
              ))}
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="font-mono text-sm font-bold tabular-nums">{total}</span>
              <span className="font-mono text-[7px] uppercase tracking-wider text-muted-foreground">
                claims
              </span>
            </div>
          </div>
          <div className="min-w-0 flex-1">
            <div className="mb-1 font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
              State distribution
            </div>
            <div className="flex flex-wrap gap-x-2 gap-y-0.5">
              {presentStates.map((s) => (
                <div
                  key={s}
                  className="flex items-center gap-1 font-mono text-[9px]"
                  title={`${s}: ${stateCounts[s]}`}
                >
                  <span
                    className="h-2 w-2 rounded-sm"
                    style={{ backgroundColor: STATE_COLORS[s] ?? "oklch(0.5 0 0)" }}
                  />
                  <span className="text-muted-foreground">{s.slice(0, 3)}</span>
                  <span className="font-bold">{stateCounts[s]}</span>
                </div>
              ))}
              {presentStates.length === 0 && (
                <span className="font-mono text-[10px] text-muted-foreground">no claims</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
