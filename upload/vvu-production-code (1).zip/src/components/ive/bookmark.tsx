"use client";

import { useEffect, useState } from "react";
import { Bookmark, BookmarkCheck } from "lucide-react";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "vvu-ive-bookmarks";

function readBookmarks(): Set<string> {
  if (typeof window === "undefined") return new Set();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return new Set();
    const arr = JSON.parse(raw);
    if (Array.isArray(arr)) return new Set(arr.filter((x) => typeof x === "string"));
    return new Set();
  } catch {
    return new Set();
  }
}

function writeBookmarks(set: Set<string>) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(Array.from(set)));
  } catch {
    /* ignore quota errors */
  }
}

// Shared event so all BookmarkButton instances stay in sync across the page.
const BOOKMARK_EVENT = "vvu-ive-bookmarks-changed";

export function useBookmarks() {
  const [bookmarks, setBookmarks] = useState<Set<string>>(new Set());

  useEffect(() => {
    Promise.resolve().then(() => setBookmarks(readBookmarks()));
    const onChange = () => setBookmarks(readBookmarks());
    window.addEventListener(BOOKMARK_EVENT, onChange);
    window.addEventListener("storage", onChange);
    return () => {
      window.removeEventListener(BOOKMARK_EVENT, onChange);
      window.removeEventListener("storage", onChange);
    };
  }, []);

  const toggle = (id: string) => {
    setBookmarks((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      writeBookmarks(next);
      window.dispatchEvent(new Event(BOOKMARK_EVENT));
      return next;
    });
  };

  const has = (id: string) => bookmarks.has(id);
  return { bookmarks, has, toggle };
}

export function BookmarkButton({
  claimId,
  size = "sm",
  className,
}: {
  claimId: string;
  size?: "sm" | "md";
  className?: string;
}) {
  const { has, toggle } = useBookmarks();
  const active = has(claimId);
  const sizeCls = size === "sm" ? "h-7 w-7" : "h-9 w-9";
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        e.preventDefault();
        toggle(claimId);
      }}
      title={active ? "Remove bookmark" : "Bookmark this claim"}
      className={cn(
        "inline-flex shrink-0 items-center justify-center rounded-md border transition-colors",
        sizeCls,
        active
          ? "border-amber-500/40 bg-amber-500/15 text-amber-700 hover:bg-amber-500/25 dark:text-amber-300"
          : "border-border bg-card text-muted-foreground hover:bg-muted/50 hover:text-foreground",
        className,
      )}
    >
      {active ? (
        <BookmarkCheck className={size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4"} />
      ) : (
        <Bookmark className={size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4"} />
      )}
    </button>
  );
}
