"use client";

import { useEffect, useState } from "react";
import {
  Settings,
  Sun,
  Moon,
  Trash2,
  RefreshCw,
  X,
  Palette,
  Building2,
  Clock,
} from "lucide-react";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "vvu-ive-settings";

export interface Ivesettings {
  theme: "dark" | "light";
  defaultEstate: string; // "all" | "canonical" | "hbk-mk2" | "skylantern"
  autoRefresh: boolean;
  autoRefreshMs: number;
}

const DEFAULTS: Ivesettings = {
  theme: "dark",
  defaultEstate: "all",
  autoRefresh: false,
  autoRefreshMs: 15000,
};

function readSettings(): Ivesettings {
  if (typeof window === "undefined") return DEFAULTS;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULTS;
    const parsed = JSON.parse(raw);
    return { ...DEFAULTS, ...parsed };
  } catch {
    return DEFAULTS;
  }
}

function writeSettings(s: Ivesettings) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
    window.dispatchEvent(new Event("vvu-ive-settings-changed"));
  } catch {
    /* ignore */
  }
}

export function useSettings() {
  const [settings, setSettings] = useState<Ivesettings>(DEFAULTS);

  useEffect(() => {
    const s = readSettings();
    Promise.resolve().then(() => setSettings(s));
    // apply theme on mount
    if (typeof document !== "undefined") {
      if (s.theme === "dark") {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
    }
    const onChange = () => setSettings(readSettings());
    window.addEventListener("vvu-ive-settings-changed", onChange);
    window.addEventListener("storage", onChange);
    return () => {
      window.removeEventListener("vvu-ive-settings-changed", onChange);
      window.removeEventListener("storage", onChange);
    };
  }, []);

  const update = (patch: Partial<Ivesettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      writeSettings(next);
      // apply theme immediately
      if (typeof document !== "undefined") {
        if (next.theme === "dark") {
          document.documentElement.classList.add("dark");
        } else {
          document.documentElement.classList.remove("dark");
        }
      }
      return next;
    });
  };

  return { settings, update };
}

export function SettingsModal({
  onClose,
  onClearBookmarks,
  onApplyDefaultEstate,
}: {
  onClose: () => void;
  onClearBookmarks: () => void;
  onApplyDefaultEstate: (estate: string) => void;
}) {
  const { settings, update } = useSettings();

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-lg border border-border bg-card p-6 shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            <h2 className="text-base font-bold">Settings</h2>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Theme */}
          <div>
            <label className="mb-1.5 flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
              <Palette className="h-3 w-3" /> Theme
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => update({ theme: "dark" })}
                className={cn(
                  "flex items-center justify-center gap-1.5 rounded-md border py-2 text-sm transition-colors",
                  settings.theme === "dark"
                    ? "border-foreground bg-foreground text-background"
                    : "border-border bg-card hover:bg-muted/50",
                )}
              >
                <Moon className="h-3.5 w-3.5" /> Dark
              </button>
              <button
                onClick={() => update({ theme: "light" })}
                className={cn(
                  "flex items-center justify-center gap-1.5 rounded-md border py-2 text-sm transition-colors",
                  settings.theme === "light"
                    ? "border-foreground bg-foreground text-background"
                    : "border-border bg-card hover:bg-muted/50",
                )}
              >
                <Sun className="h-3.5 w-3.5" /> Light
              </button>
            </div>
          </div>

          {/* Default estate */}
          <div>
            <label className="mb-1.5 flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
              <Building2 className="h-3 w-3" /> Default estate filter
            </label>
            <select
              value={settings.defaultEstate}
              onChange={(e) => update({ defaultEstate: e.target.value })}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
            >
              <option value="all">All estates</option>
              <option value="canonical">Canonical IVE</option>
              <option value="hbk-mk2">HBK Mk-II Estate</option>
              <option value="skylantern">Skylantern Estate</option>
            </select>
            <button
              onClick={() => onApplyDefaultEstate(settings.defaultEstate)}
              className="mt-1.5 w-full rounded-md border border-border bg-muted/30 py-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground hover:bg-muted/50"
            >
              Apply now
            </button>
          </div>

          {/* Auto-refresh */}
          <div>
            <label className="mb-1.5 flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
              <Clock className="h-3 w-3" /> Auto-refresh
            </label>
            <div className="flex items-center justify-between rounded-md border border-border bg-card p-2.5">
              <span className="text-sm">Poll /api/state periodically</span>
              <button
                onClick={() => update({ autoRefresh: !settings.autoRefresh })}
                className={cn(
                  "relative h-5 w-9 rounded-full transition-colors",
                  settings.autoRefresh ? "bg-emerald-500" : "bg-muted-foreground/30",
                )}
              >
                <span
                  className={cn(
                    "absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform",
                    settings.autoRefresh ? "translate-x-4" : "translate-x-0.5",
                  )}
                />
              </button>
            </div>
            {settings.autoRefresh && (
              <div className="mt-1.5 flex items-center gap-2">
                <input
                  type="range"
                  min={5000}
                  max={60000}
                  step={5000}
                  value={settings.autoRefreshMs}
                  onChange={(e) => update({ autoRefreshMs: Number(e.target.value) })}
                  className="flex-1 accent-emerald-600"
                />
                <span className="font-mono text-[10px] text-muted-foreground">
                  {(settings.autoRefreshMs / 1000).toFixed(0)}s
                </span>
              </div>
            )}
          </div>

          {/* Danger zone */}
          <div>
            <label className="mb-1.5 flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
              <Trash2 className="h-3 w-3" /> Bookmarks
            </label>
            <button
              onClick={onClearBookmarks}
              className="flex w-full items-center justify-center gap-1.5 rounded-md border border-red-500/40 bg-red-500/10 py-2 text-sm text-red-700 transition-colors hover:bg-red-500/20 dark:text-red-300"
            >
              <Trash2 className="h-3.5 w-3.5" /> Clear all bookmarks
            </button>
          </div>
        </div>

        <p className="mt-4 font-mono text-[10px] leading-snug text-muted-foreground">
          Settings persist to localStorage under `vvu-ive-settings`. The theme toggle adds/removes
          the `.dark` class on &lt;html&gt; (the layout defaults to dark).
        </p>
      </div>
    </div>
  );
}
