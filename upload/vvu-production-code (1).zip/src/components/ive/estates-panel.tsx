"use client";

import { Card } from "@/components/ui/card";
import { Zap } from "lucide-react";
import { cn } from "@/lib/utils";

export interface EstateSummary {
  id: string;
  key: string;
  name: string;
  description: string;
  accent: string;
  theorem: string;
  totalClaims: number;
  totalEvidence: number;
  authorizedClaims: number;
  breakerTripped: number;
  stateCounts: Record<string, number>;
}

// Global summary shape passed in from the page for the state-distribution
// mini-chart + the system circuit-breaker health strip at the bottom.
export interface GlobalSummary {
  totalClaims: number;
  breakerTripped: number;
  stateCounts: Record<string, number>;
}

const ACCENT_CLASSES: Record<string, { text: string; border: string; bg: string; dot: string }> = {
  emerald: { text: "text-emerald-700 dark:text-emerald-300", border: "border-emerald-500/40", bg: "bg-emerald-500/10", dot: "bg-emerald-500" },
  amber: { text: "text-amber-700 dark:text-amber-300", border: "border-amber-500/40", bg: "bg-amber-500/10", dot: "bg-amber-500" },
  cyan: { text: "text-cyan-700 dark:text-cyan-300", border: "border-cyan-500/40", bg: "bg-cyan-500/10", dot: "bg-cyan-500" },
};

// Bar colours per verification state (mirrors state-badge.tsx).
const STATE_BAR_COLOR: Record<string, string> = {
  PROVEN: "bg-emerald-500",
  VERIFIED: "bg-green-500",
  SUPPORTED: "bg-lime-500",
  OBSERVED: "bg-amber-500",
  INCONCLUSIVE: "bg-orange-500",
  UNVALIDATED: "bg-zinc-500",
  UNTESTED: "bg-slate-500",
  STALE: "bg-stone-500",
  FALSIFIED: "bg-red-500",
};

// Lattice order (PROVEN … STALE, then FALSIFIED last — terminal).
const STATE_ORDER = [
  "PROVEN",
  "VERIFIED",
  "SUPPORTED",
  "OBSERVED",
  "INCONCLUSIVE",
  "UNVALIDATED",
  "UNTESTED",
  "STALE",
  "FALSIFIED",
] as const;

export function EstatesPanel({
  estates,
  selectedKey,
  onSelect,
  summary,
}: {
  estates: EstateSummary[];
  selectedKey?: string;
  onSelect?: (key: string) => void;
  summary?: GlobalSummary;
}) {
  const totalClaims = summary?.totalClaims ?? 0;
  const breakerTripped = summary?.breakerTripped ?? 0;
  const trippedRatio = totalClaims === 0 ? 0 : breakerTripped / totalClaims;
  const healthy = breakerTripped === 0;
  // pick a colour: green (0) → amber (some) → red (>50%)
  const healthDot = healthy
    ? "bg-emerald-500"
    : trippedRatio > 0.5
      ? "bg-red-500"
      : "bg-amber-500";
  const healthText = healthy
    ? "text-emerald-700 dark:text-emerald-300"
    : trippedRatio > 0.5
      ? "text-red-700 dark:text-red-300"
      : "text-amber-700 dark:text-amber-300";
  const healthLabel = healthy
    ? "ALL CLOSED — AUTHORISING"
    : trippedRatio > 0.5
      ? "MAJORITY TRIPPED — FAIL-CLOSED"
      : "PARTIAL — INVESTIGATE";

  // State distribution: count per state, max for bar scaling.
  const stateCounts = summary?.stateCounts ?? {};
  const presentStates = STATE_ORDER.filter((s) => (stateCounts[s] ?? 0) > 0);
  const maxCount = Math.max(1, ...presentStates.map((s) => stateCounts[s] ?? 0));

  return (
    <Card className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Estates Under the Canonical</h3>
          <p className="font-mono text-[10px] text-muted-foreground">
            estates → canonical IVE pipeline
          </p>
        </div>
        <span className="rounded border border-foreground/20 bg-muted px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wider text-muted-foreground">
          {estates.length} estates
        </span>
      </div>
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
        {estates.map((e) => {
          const a = ACCENT_CLASSES[e.accent] ?? ACCENT_CLASSES.emerald;
          const active = selectedKey === e.key;
          const authRatio = e.totalClaims > 0 ? e.authorizedClaims / e.totalClaims : 0;
          // progress ring geometry
          const R = 16;
          const C = 2 * Math.PI * R;
          const dash = authRatio * C;
          // sparkline of state distribution (present states in lattice order)
          const sparkStates = STATE_ORDER.filter((s) => (e.stateCounts[s] ?? 0) > 0);
          const sparkMax = Math.max(1, ...sparkStates.map((s) => e.stateCounts[s] ?? 0));
          return (
            <button
              key={e.key}
              onClick={() => onSelect?.(e.key)}
              className={cn(
                "group rounded-md border p-2.5 text-left transition-all hover:-translate-y-0.5",
                active
                  ? `${a.border} ${a.bg} ring-1 ring-offset-0`
                  : "border-border bg-card hover:bg-muted/50 hover:shadow-md",
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex min-w-0 items-center gap-1.5">
                  <span className={cn("h-2 w-2 shrink-0 rounded-full", a.dot)} />
                  <span className={cn("truncate font-mono text-[11px] font-bold", a.text)}>{e.name}</span>
                </div>
                {/* progress ring: authorized / total claims */}
                <svg width="36" height="36" viewBox="0 0 36 36" className="shrink-0">
                  <circle
                    cx="18"
                    cy="18"
                    r={R}
                    fill="none"
                    stroke="var(--muted)"
                    strokeWidth="3"
                  />
                  <circle
                    cx="18"
                    cy="18"
                    r={R}
                    fill="none"
                    stroke={
                      e.accent === "emerald"
                        ? "oklch(0.646 0.222 41.116)"
                        : e.accent === "amber"
                          ? "oklch(0.7 0.18 60)"
                          : "oklch(0.7 0.15 200)"
                    }
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeDasharray={`${dash} ${C}`}
                    transform="rotate(-90 18 18)"
                    className="transition-all duration-500"
                  />
                  <text
                    x="18"
                    y="20.5"
                    textAnchor="middle"
                    className="fill-foreground font-mono text-[9px] font-bold"
                  >
                    {e.authorizedClaims}/{e.totalClaims}
                  </text>
                </svg>
              </div>
              <p className="mt-1 line-clamp-2 text-[10px] leading-snug text-muted-foreground">
                {e.description}
              </p>
              <div className="mt-2 grid grid-cols-2 gap-1 font-mono text-[9px]">
                <div className="text-muted-foreground">
                  claims: <span className="font-bold text-foreground">{e.totalClaims}</span>
                </div>
                <div className="text-muted-foreground">
                  evidence: <span className="font-bold text-foreground">{e.totalEvidence}</span>
                </div>
                <div className="text-muted-foreground">
                  authorized:{" "}
                  <span className="font-bold text-emerald-700 dark:text-emerald-300">
                    {e.authorizedClaims}
                  </span>
                </div>
                <div className="text-muted-foreground">
                  tripped:{" "}
                  <span className={cn("font-bold", e.breakerTripped > 0 ? "text-red-700 dark:text-red-300" : "text-foreground")}>
                    {e.breakerTripped}
                  </span>
                </div>
              </div>
              {/* sparkline: per-state distribution */}
              {sparkStates.length > 0 && (
                <div className="mt-1.5 flex h-4 items-end gap-0.5">
                  {sparkStates.map((s) => {
                    const c = e.stateCounts[s] ?? 0;
                    const h = (c / sparkMax) * 100;
                    return (
                      <div
                        key={s}
                        title={`${s}: ${c}`}
                        className={cn("flex-1 rounded-sm transition-all", STATE_BAR_COLOR[s] ?? "bg-slate-500")}
                        style={{ height: `${Math.max(15, h)}%`, opacity: 0.7 }}
                      />
                    );
                  })}
                </div>
              )}
              <div className="mt-1.5 font-mono text-[9px] text-muted-foreground">{e.theorem}</div>
            </button>
          );
        })}
      </div>

      {/* State distribution mini-chart */}
      {summary && (
        <div className="mt-4 rounded-md border border-border bg-muted/30 p-2.5">
          <div className="mb-2 flex items-center justify-between">
            <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
              Global state distribution
            </span>
            <span className="font-mono text-[9px] text-muted-foreground">
              {totalClaims} claim{totalClaims === 1 ? "" : "s"} · {presentStates.length} state
              {presentStates.length === 1 ? "" : "s"}
            </span>
          </div>
          {presentStates.length === 0 ? (
            <p className="font-mono text-[10px] text-muted-foreground">
              no claims in the lattice yet.
            </p>
          ) : (
            <div className="space-y-1">
              {presentStates.map((s) => {
                const count = stateCounts[s] ?? 0;
                const pct = (count / maxCount) * 100;
                return (
                  <div key={s} className="flex items-center gap-2">
                    <span className="w-[88px] shrink-0 font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                      {s}
                    </span>
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                      <div
                        className={cn("h-full rounded-full", STATE_BAR_COLOR[s] ?? "bg-slate-500")}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <span className="w-6 shrink-0 text-right font-mono text-[9px] font-bold">
                      {count}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* System health overview (global circuit-breaker status) */}
      {summary && (
        <div className="mt-2 flex items-center justify-between rounded-md border border-border bg-muted/30 p-2.5">
          <div className="flex items-center gap-2">
            <Zap className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
              System health
            </span>
            <span className={cn("h-2.5 w-2.5 rounded-full", healthDot)} />
          </div>
          <div className="text-right">
            <div className={cn("font-mono text-[11px] font-bold tracking-wider", healthText)}>
              {healthLabel}
            </div>
            <div className="font-mono text-[9px] text-muted-foreground">
              {breakerTripped} of {totalClaims} breaker{totalClaims === 1 ? "" : "s"} tripped
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}
