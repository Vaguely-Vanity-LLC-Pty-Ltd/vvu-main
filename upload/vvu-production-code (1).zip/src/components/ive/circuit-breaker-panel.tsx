"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Zap,
  ShieldCheck,
  ShieldAlert,
  ChevronDown,
  ChevronUp,
  Activity,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { describeBreakerReason } from "@/lib/eis";

interface CircuitBreakerRecord {
  id: string;
  claimId: string;
  triggered: boolean;
  reason: string;
  trippedAt: string;
}

const REASON_COLORS: Record<string, string> = {
  evidence_lost: "text-red-700 dark:text-red-300 border-red-500/40 bg-red-500/10",
  verification_failed: "text-red-700 dark:text-red-300 border-red-500/40 bg-red-500/10",
  safety_violation: "text-amber-700 dark:text-amber-300 border-amber-500/40 bg-amber-500/10",
  stale_evidence: "text-orange-700 dark:text-orange-300 border-orange-500/40 bg-orange-500/10",
  integrity_breach: "text-red-700 dark:text-red-300 border-red-500/40 bg-red-500/10",
};

function formatRelative(iso: string): string {
  const t = new Date(iso).getTime();
  if (!isFinite(t)) return iso;
  const diff = Date.now() - t;
  if (diff < 60_000) return `${Math.max(1, Math.floor(diff / 1000))}s ago`;
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`;
  return `${Math.floor(diff / 86_400_000)}d ago`;
}

function formatTime(iso: string): string {
  try {
    return new Date(iso).toLocaleString(undefined, {
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  } catch {
    return iso;
  }
}

export function CircuitBreakerPanel({
  events,
  safetyCritical,
}: {
  events: CircuitBreakerRecord[];
  safetyCritical: boolean;
}) {
  const [expanded, setExpanded] = useState(false);
  const tripped = events[0]?.triggered ?? false;
  const latestReason = events[0]?.reason ?? "";
  const tripCount = events.filter((e) => e.triggered).length;
  const clearCount = events.filter((e) => !e.triggered).length;

  // Show up to 5 events when collapsed, all when expanded.
  const visibleEvents = expanded ? events : events.slice(0, 5);

  return (
    <Card
      className={cn(
        "p-4",
        tripped
          ? "border-red-500/50 bg-red-500/5"
          : "border-emerald-500/30 bg-emerald-500/5",
      )}
    >
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="flex items-center gap-1.5 text-sm font-semibold">
            <Zap className="h-3.5 w-3.5" />
            Circuit Breaker
          </h3>
          <p className="font-mono text-[10px] text-muted-foreground">
            fail-closed: loss of E → loss of V → loss of A
          </p>
        </div>
        <span className="rounded border border-red-500/30 bg-red-500/10 px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wider text-red-700 dark:text-red-300">
          Theorem 5
        </span>
      </div>

      {/* Verdict box */}
      <div
        className={cn(
          "mb-3 flex items-center justify-between rounded-md border-2 p-3",
          tripped ? "border-red-500/50 bg-red-500/5" : "border-emerald-500/40 bg-emerald-500/5",
        )}
      >
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "relative flex h-3 w-3",
            )}
          >
            {tripped && (
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75" />
            )}
            <span
              className={cn(
                "relative inline-flex h-3 w-3 rounded-full",
                tripped ? "bg-red-500" : "bg-emerald-500",
              )}
            />
          </span>
          <div
            className={cn(
              "font-mono text-base font-bold tracking-wider",
              tripped ? "text-red-700 dark:text-red-300" : "text-emerald-700 dark:text-emerald-300",
            )}
          >
            {tripped ? "TRIPPED — FAIL CLOSED" : "CLOSED — AUTHORIZING"}
          </div>
        </div>
        {tripped && latestReason && (
          <span
            className={cn(
              "rounded border px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider",
              REASON_COLORS[latestReason] ?? "text-muted-foreground border-border bg-muted",
            )}
          >
            {describeBreakerReason(latestReason as any)}
          </span>
        )}
      </div>

      {/* Quick stats */}
      <div className="mb-3 grid grid-cols-3 gap-2">
        <div className="rounded-md border border-border bg-card p-2 text-center">
          <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
            Safety-critical
          </div>
          <div className={cn("font-mono text-sm font-bold", safetyCritical ? "text-amber-700 dark:text-amber-300" : "text-foreground")}>
            {safetyCritical ? "YES" : "no"}
          </div>
        </div>
        <div className="rounded-md border border-red-500/20 bg-red-500/5 p-2 text-center">
          <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
            Trips
          </div>
          <div className="font-mono text-sm font-bold text-red-700 dark:text-red-300">
            {tripCount}
          </div>
        </div>
        <div className="rounded-md border border-emerald-500/20 bg-emerald-500/5 p-2 text-center">
          <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
            Clears
          </div>
          <div className="font-mono text-sm font-bold text-emerald-700 dark:text-emerald-300">
            {clearCount}
          </div>
        </div>
      </div>

      {/* Event history timeline */}
      {events.length > 0 ? (
        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <span className="flex items-center gap-1 font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
              <Activity className="h-3 w-3" /> Event history
            </span>
            <span className="font-mono text-[9px] text-muted-foreground">
              {events.length} event{events.length === 1 ? "" : "s"}
            </span>
          </div>
          <div className="space-y-1">
            {visibleEvents.map((e, i) => {
              const isLast = i === visibleEvents.length - 1;
              const isTrip = e.triggered;
              const reasonClass = REASON_COLORS[e.reason] ?? "text-muted-foreground border-border bg-muted";
              return (
                <div key={e.id} className="relative flex gap-2 pl-0.5">
                  {!isLast && (
                    <span className="absolute left-[7px] top-5 h-[calc(100%-0.25rem)] w-px bg-border" />
                  )}
                  <span
                    className={cn(
                      "relative z-10 mt-1 flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full border",
                      isTrip
                        ? "border-red-500/50 bg-red-500/20"
                        : "border-emerald-500/50 bg-emerald-500/20",
                    )}
                  >
                    {isTrip ? (
                      <Zap className="h-2 w-2 text-red-600 dark:text-red-400" />
                    ) : (
                      <ShieldCheck className="h-2 w-2 text-emerald-600 dark:text-emerald-400" />
                    )}
                  </span>
                  <div className="min-w-0 flex-1 pb-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className={cn(
                          "font-mono text-[10px] font-semibold",
                          isTrip
                            ? "text-red-700 dark:text-red-300"
                            : "text-emerald-700 dark:text-emerald-300",
                        )}
                      >
                        {isTrip ? "TRIPPED" : "CLEARED"}
                      </span>
                      <span
                        className="font-mono text-[9px] text-muted-foreground"
                        title={formatTime(e.trippedAt)}
                      >
                        {formatRelative(e.trippedAt)}
                      </span>
                    </div>
                    {isTrip && e.reason && (
                      <span
                        className={cn(
                          "mt-0.5 inline-block rounded border px-1.5 py-0.5 font-mono text-[8px] font-semibold uppercase tracking-wider",
                          reasonClass,
                        )}
                      >
                        {describeBreakerReason(e.reason as any)}
                      </span>
                    )}
                    {!isTrip && (
                      <span className="mt-0.5 block font-mono text-[9px] text-muted-foreground">
                        reverification restored the evidence bound
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          {events.length > 5 && (
            <Button
              variant="ghost"
              size="sm"
              className="mt-1 h-7 w-full gap-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground"
              onClick={() => setExpanded((v) => !v)}
            >
              {expanded ? (
                <>
                  <ChevronUp className="h-3 w-3" /> Show less
                </>
              ) : (
                <>
                  <ChevronDown className="h-3 w-3" /> Show {events.length - 5} more
                </>
              )}
            </Button>
          )}
        </div>
      ) : (
        <div className="rounded-md border border-dashed border-border/60 bg-muted/20 p-3 text-center font-mono text-[10px] text-muted-foreground">
          No breaker events — the claim has not been through reverification yet.
        </div>
      )}

      <p className="mt-3 font-mono text-[10px] leading-snug text-muted-foreground">
        When tripped, all authorization is revoked until reverification restores the
        evidence bound.
      </p>
    </Card>
  );
}
