"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search, Globe, FileText, Activity, Database, Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { cn } from "@/lib/utils";
import type { EvidenceItem, EvidenceSource } from "@/lib/eis";

const SOURCE_META: Record<
  EvidenceSource,
  { icon: typeof Search; color: string; bg: string; label: string }
> = {
  "you.com": {
    icon: Search,
    color: "text-rose-600 dark:text-rose-400",
    bg: "bg-rose-500/10",
    label: "you.com",
  },
  brave: {
    icon: Globe,
    color: "text-orange-600 dark:text-orange-400",
    bg: "bg-orange-500/10",
    label: "brave",
  },
  firecrawl: {
    icon: FileText,
    color: "text-amber-700 dark:text-amber-300",
    bg: "bg-amber-500/10",
    label: "firecrawl",
  },
  watchdog: {
    icon: Activity,
    color: "text-cyan-700 dark:text-cyan-300",
    bg: "bg-cyan-500/10",
    label: "watchdog",
  },
};

const ALL_SOURCES: EvidenceSource[] = ["you.com", "brave", "firecrawl", "watchdog"];

export function EvidenceMeshPanel({
  evidence,
  onIngest,
  loading,
}: {
  evidence: EvidenceItem[];
  onIngest?: () => void;
  loading?: boolean;
}) {
  const [expandedSource, setExpandedSource] = useState<EvidenceSource | null>(null);
  const totalItems = evidence.length;
  const distinctSrcCount = new Set(evidence.map((e) => e.source)).size;
  // aggregate weight = mean of per-source weights (each source contributes once)
  const perSourceAvg =
    distinctSrcCount > 0
      ? ALL_SOURCES.reduce((acc, src) => {
          const items = evidence.filter((e) => e.source === src);
          if (items.length === 0) return acc;
          const max = Math.max(...items.map((i) => i.weight));
          return acc + max;
        }, 0) / 4
      : 0;

  return (
    <Card className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Evidence Mesh</h3>
          <p className="font-mono text-[10px] text-muted-foreground">
            E(c) = E_you ∪ E_brave ∪ E_firecrawl ∪ E_watchdog
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="rounded border border-emerald-500/30 bg-emerald-500/10 px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wider text-emerald-700 dark:text-emerald-300">
            Theorem 4 §4
          </span>
          {onIngest && (
            <Button size="sm" variant="outline" onClick={onIngest} disabled={loading}>
              {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : <Database className="h-3 w-3" />}
              Ingest
            </Button>
          )}
        </div>
      </div>

      {/* Aggregate mesh summary */}
      <div className="mb-3 grid grid-cols-3 gap-2">
        <div className="rounded-md border border-border bg-card p-2 text-center">
          <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
            Items
          </div>
          <div className="font-mono text-base font-bold tabular-nums">{totalItems}</div>
        </div>
        <div className="rounded-md border border-border bg-card p-2 text-center">
          <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
            Distinct src
          </div>
          <div className="font-mono text-base font-bold tabular-nums">
            {distinctSrcCount}
            <span className="text-[10px] font-normal text-muted-foreground">/4</span>
          </div>
        </div>
        <div className="rounded-md border border-border bg-card p-2 text-center">
          <div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
            Mesh weight
          </div>
          <div className="font-mono text-base font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
            {perSourceAvg.toFixed(2)}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-4">
        {ALL_SOURCES.map((src) => {
          const meta = SOURCE_META[src];
          const items = evidence.filter((e) => e.source === src);
          const Icon = meta.icon;
          const maxWeight = items.length > 0 ? Math.max(...items.map((i) => i.weight)) : 0;
          const expanded = expandedSource === src;
          return (
            <div
              key={src}
              className={cn(
                "rounded-md border transition-colors",
                items.length === 0
                  ? "border-dashed border-border/60 bg-muted/30"
                  : expanded
                    ? `${meta.bg} ${meta.color.replace("text-", "border-").replace(/-600|-400/, "-500/40")}`
                    : "border-border bg-card hover:bg-muted/40",
              )}
            >
              <button
                type="button"
                disabled={items.length === 0}
                onClick={() => setExpandedSource(expanded ? null : src)}
                className="flex w-full items-center gap-1.5 p-2 text-left disabled:cursor-default"
              >
                <span className={cn("rounded p-1", meta.bg)}>
                  <Icon className={cn("h-3 w-3", meta.color)} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="font-mono text-[10px] font-semibold">{meta.label}</div>
                  <div className="text-[9px] text-muted-foreground">
                    {items.length} item{items.length === 1 ? "" : "s"}
                  </div>
                </div>
                {items.length > 1 && (
                  <span className="font-mono text-[9px] text-muted-foreground">
                    {expanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                  </span>
                )}
              </button>
              {items.length > 0 ? (
                <div className="px-2 pb-2">
                  {expanded && items.length > 1 ? (
                    <div className="space-y-1">
                      {items.map((it) => (
                        <div key={it.id} className="rounded border border-border/50 bg-background/40 p-1.5">
                          <p className="line-clamp-2 text-[9px] leading-snug text-muted-foreground">
                            {it.content.slice(0, 80)}
                            {it.content.length > 80 ? "…" : ""}
                          </p>
                          <div className="mt-1 flex items-center gap-1">
                            <div className="h-1 flex-1 overflow-hidden rounded-full bg-muted">
                              <div
                                className="h-full rounded-full bg-emerald-500"
                                style={{ width: `${Math.min(100, it.weight * 100)}%` }}
                              />
                            </div>
                            <span className="font-mono text-[9px] text-muted-foreground">
                              {it.weight.toFixed(2)}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <>
                      <p className="line-clamp-2 text-[9px] leading-snug text-muted-foreground">
                        {items[0].content.slice(0, 70)}
                        {items[0].content.length > 70 ? "…" : ""}
                      </p>
                      <div className="mt-1.5 flex items-center gap-1">
                        <div className="h-1 flex-1 overflow-hidden rounded-full bg-muted">
                          <div
                            className="h-full rounded-full bg-emerald-500"
                            style={{ width: `${Math.min(100, maxWeight * 100)}%` }}
                          />
                        </div>
                        <span className="font-mono text-[9px] text-muted-foreground">
                          {maxWeight.toFixed(2)}
                        </span>
                      </div>
                      {items.length > 1 && (
                        <p className="mt-1 text-center font-mono text-[8px] text-muted-foreground">
                          + {items.length - 1} more · click to expand
                        </p>
                      )}
                    </>
                  )}
                </div>
              ) : (
                <p className="px-2 pb-2 text-[9px] italic text-muted-foreground">no evidence</p>
              )}
            </div>
          );
        })}
      </div>
      <div className="mt-3 rounded-md border border-amber-500/30 bg-amber-500/10 p-2 text-[10px] text-amber-800 dark:text-amber-200">
        ⚠ Multiple sources ≠ independent. N_ind identifies the true latent source count.
        {distinctSrcCount >= 2 && totalItems >= 3 && (
          <span className="ml-1 font-mono text-emerald-700 dark:text-emerald-300">
            ✓ E conjunct satisfied (≥2 src ∨ ≥3 items)
          </span>
        )}
      </div>
    </Card>
  );
}
