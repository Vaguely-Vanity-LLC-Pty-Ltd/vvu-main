"use client";

import { cn } from "@/lib/utils";

// Lightweight skeleton primitives for loading states — shimmer via animate-pulse.

export function SkeletonLine({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "animate-pulse rounded bg-muted/60",
        className,
      )}
    />
  );
}

export function SkeletonCard({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "animate-pulse rounded-md border border-border bg-muted/30 p-4",
        className,
      )}
    >
      <div className="mb-2 h-3 w-1/3 rounded bg-muted" />
      <div className="h-6 w-1/2 rounded bg-muted" />
    </div>
  );
}

export function SkeletonClaimList() {
  return (
    <div className="space-y-1.5">
      {Array.from({ length: 6 }).map((_, i) => (
        <div
          key={i}
          className="flex items-center gap-2 rounded-md border border-border bg-muted/20 p-2"
        >
          <div className="h-2 w-2 rounded-full bg-muted" />
          <div className="flex-1 space-y-1.5">
            <SkeletonLine className="h-3 w-3/4" />
            <SkeletonLine className="h-2 w-1/2" />
          </div>
        </div>
      ))}
    </div>
  );
}

export function SkeletonClaimDetail() {
  return (
    <div className="space-y-4">
      <div className="rounded-md border border-border bg-muted/20 p-4">
        <div className="mb-2 flex gap-2">
          <SkeletonLine className="h-4 w-16" />
          <SkeletonLine className="h-4 w-20" />
        </div>
        <SkeletonLine className="mb-2 h-5 w-2/3" />
        <SkeletonLine className="h-4 w-full" />
        <SkeletonLine className="h-4 w-4/5" />
        <div className="mt-3 flex gap-2">
          <SkeletonLine className="h-8 w-28" />
          <SkeletonLine className="h-8 w-24" />
        </div>
      </div>
      <div className="h-10 rounded-md bg-muted/20" />
      <div className="grid grid-cols-2 gap-4">
        <SkeletonCard />
        <SkeletonCard />
        <SkeletonCard />
        <SkeletonCard />
      </div>
    </div>
  );
}
