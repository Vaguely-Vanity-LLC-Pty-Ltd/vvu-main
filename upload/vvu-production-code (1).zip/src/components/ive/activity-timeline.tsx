"use client";

import { Card } from "@/components/ui/card";
import {
  Database,
  GitBranch,
  Sigma,
  ShieldCheck,
  ShieldAlert,
  Zap,
  Plus,
  Trash2,
  CheckCircle2,
  XCircle,
  Activity,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type {
  AuthorizationRecord,
  CircuitBreakerRecord,
  ClaimWithRelations,
  EvidenceItem,
  NIndRecord,
} from "@/lib/eis";

interface TimelineEvent {
  id: string;
  kind:
    | "claim_created"
    | "claim_deleted"
    | "evidence_ingested"
    | "verified"
    | "n_ind"
    | "authorized"
    | "breaker_trip"
    | "breaker_clear";
  at: string; // ISO
  icon: typeof Database;
  color: string; // tailwind text-color
  bg: string; // tailwind bg-color
  title: string;
  detail: string;
}

function buildTimeline(claim: ClaimWithRelations): TimelineEvent[] {
  const events: TimelineEvent[] = [];

  events.push({
    id: `claim-${claim.id}`,
    kind: "claim_created",
    at: claim.createdAt,
    icon: Plus,
    color: "text-emerald-700 dark:text-emerald-300",
    bg: "bg-emerald-500/10",
    title: "Claim created",
    detail: `"${claim.title}" · ${claim.claimType} · estate: ${claim.estateKey}`,
  });

  for (const e of claim.evidence as EvidenceItem[]) {
    events.push({
      id: `ev-${e.id}`,
      kind: "evidence_ingested",
      at: e.collectedAt,
      icon: Database,
      color: "text-rose-700 dark:text-rose-300",
      bg: "bg-rose-500/10",
      title: "Evidence ingested",
      detail: `${e.source} · w=${e.weight.toFixed(2)} · state=${e.state}`,
    });
  }

  for (const n of claim.nIndRecords as NIndRecord[]) {
    events.push({
      id: `nind-${n.id}`,
      kind: "n_ind",
      at: n.createdAt,
      icon: Sigma,
      color: "text-orange-700 dark:text-orange-300",
      bg: "bg-orange-500/10",
      title: "N_ind computed",
      detail: `N_ind=${n.nInd.toFixed(2)} · sources=${n.numSources} · γ=${n.gamma.toFixed(2)}`,
    });
  }

  for (const a of claim.authorizations as AuthorizationRecord[]) {
    events.push({
      id: `auth-${a.id}`,
      kind: "authorized",
      at: a.createdAt,
      icon: a.authorized ? CheckCircle2 : ShieldAlert,
      color: a.authorized
        ? "text-emerald-700 dark:text-emerald-300"
        : "text-red-700 dark:text-red-300",
      bg: a.authorized ? "bg-emerald-500/10" : "bg-red-500/10",
      title: a.authorized ? "Authorized — A = TRUE" : "Authorization blocked — A = FALSE",
      detail: a.reason,
    });
  }

  for (const c of claim.circuitEvents as CircuitBreakerRecord[]) {
    const tripped = c.triggered;
    events.push({
      id: `cb-${c.id}`,
      kind: tripped ? "breaker_trip" : "breaker_clear",
      at: c.trippedAt,
      icon: tripped ? Zap : ShieldCheck,
      color: tripped
        ? "text-red-700 dark:text-red-300"
        : "text-emerald-700 dark:text-emerald-300",
      bg: tripped ? "bg-red-500/10" : "bg-emerald-500/10",
      title: tripped ? `Breaker tripped — ${c.reason || "fail-closed"}` : "Breaker cleared — reverification restored the evidence bound",
      detail: tripped
        ? "Theorem 5: authorization revoked until reverification."
        : "Theorem 5: evidence bound restored; authorizing resumes.",
    });
  }

  // sort desc by time (most recent first)
  events.sort((a, b) => (a.at < b.at ? 1 : a.at > b.at ? -1 : 0));
  return events;
}

function formatRelative(iso: string): string {
  const t = new Date(iso).getTime();
  if (!isFinite(t)) return iso;
  const diff = Date.now() - t;
  if (diff < 60_000) return `${Math.max(1, Math.floor(diff / 1000))}s ago`;
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`;
  return `${Math.floor(diff / 86_400_000)}d ago`;
}

function formatTime(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleString(undefined, {
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  } catch {
    return iso;
  }
}

export function ActivityTimeline({ claim }: { claim: ClaimWithRelations }) {
  const events = buildTimeline(claim);
  const tripped = events.filter((e) => e.kind === "breaker_trip").length;
  const cleared = events.filter((e) => e.kind === "breaker_clear").length;
  const authorized = events.filter((e) => e.kind === "authorized").length;

  return (
    <Card className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h3 className="flex items-center gap-1.5 text-sm font-semibold">
            <Activity className="h-3.5 w-3.5" />
            Activity Timeline
          </h3>
          <p className="font-mono text-[10px] text-muted-foreground">
            audit trail · evidence → verification → authorization → breaker
          </p>
        </div>
        <span className="rounded border border-foreground/20 bg-muted px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-wider text-muted-foreground">
          {events.length} events
        </span>
      </div>

      {/* summary chips */}
      <div className="mb-3 flex flex-wrap gap-1.5">
        <span className="inline-flex items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 font-mono text-[9px] font-semibold text-emerald-700 dark:text-emerald-300">
          <CheckCircle2 className="h-2.5 w-2.5" /> {authorized} auth
        </span>
        <span className="inline-flex items-center gap-1 rounded-full border border-red-500/30 bg-red-500/10 px-2 py-0.5 font-mono text-[9px] font-semibold text-red-700 dark:text-red-300">
          <Zap className="h-2.5 w-2.5" /> {tripped} trips
        </span>
        {cleared > 0 && (
          <span className="inline-flex items-center gap-1 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 font-mono text-[9px] font-semibold text-emerald-700 dark:text-emerald-300">
            <ShieldCheck className="h-2.5 w-2.5" /> {cleared} cleared
          </span>
        )}
      </div>

      {events.length === 0 ? (
        <div className="rounded-md border border-dashed border-border/60 bg-muted/30 p-4 text-center font-mono text-[11px] text-muted-foreground">
          No events yet for this claim.
        </div>
      ) : (
        <div className="ive-scroll max-h-[420px] space-y-2 overflow-y-auto pr-1">
          {events.map((e, i) => {
            const Icon = e.icon;
            const isLast = i === events.length - 1;
            return (
              <div key={e.id} className="relative flex gap-2.5 pl-1">
                {/* vertical connector line */}
                {!isLast && (
                  <span className="absolute left-[14px] top-7 h-[calc(100%-0.5rem)] w-px bg-border" />
                )}
                <span
                  className={cn(
                    "relative z-10 mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border",
                    e.bg,
                    e.color,
                    "border-border",
                  )}
                >
                  <Icon className="h-3.5 w-3.5" />
                </span>
                <div className="min-w-0 flex-1 pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-mono text-[11px] font-semibold leading-tight">
                      {e.title}
                    </span>
                    <span className="shrink-0 font-mono text-[9px] text-muted-foreground" title={formatTime(e.at)}>
                      {formatRelative(e.at)}
                    </span>
                  </div>
                  <p className="mt-0.5 font-mono text-[9px] leading-snug text-muted-foreground">
                    {e.detail}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}
      <p className="mt-3 font-mono text-[10px] leading-snug text-muted-foreground">
        Each event is persisted to the WORM-style SQLite ledger (Theorem 1: Claim ≤ Evidence ≤
        Verification ≤ Authorization ≤ Action).
      </p>
    </Card>
  );
}
