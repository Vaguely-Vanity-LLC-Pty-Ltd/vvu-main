'use client';

import { useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from '@/components/ui/chart';
import {
  Area, AreaChart, Line, LineChart, Bar, BarChart,
  ResponsiveContainer, XAxis, YAxis, CartesianGrid, Cell, ReferenceLine, ReferenceDot, Tooltip as RechartsTooltip,
} from 'recharts';
import { Radio, Wifi, WifiOff } from 'lucide-react';
import type { TelemetryRow } from './telemetry-feed';
import type { WsTelemetry } from '@/hooks/use-vvu-socket';
import { SANS_CELERITY_BOUNDS, APU_THERMAL_BOUNDS } from '@/lib/vvu-telemetry';

interface LiveChartsPanelProps {
  rows: TelemetryRow[];
  wsHistory?: WsTelemetry[];
  wsConnected?: boolean;
  wsSource?: boolean;
  onToggleWs?: () => void;
}

const chartConfig = {
  flowRate:    { label: 'Flow (L/s)',    color: '#38bdf8' },
  pressure:    { label: 'Pressure (m)',  color: '#c8ff00' },
  celerity:    { label: 'Celerity (m/s)', color: '#a78bfa' },
  apuTemp:     { label: 'APU Temp (°C)', color: '#fb923c' },
  invariant:   { label: 'InvariantOK',   color: '#22c55e' },
} satisfies ChartConfig;

function fmtTime(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } catch {
    return '?';
  }
}

export function LiveChartsPanel({ rows, wsHistory, wsConnected, wsSource, onToggleWs }: LiveChartsPanelProps) {
  // Merge REST + WS data into a unified chart format.
  // If wsSource is true and we have WS data, use WS data; otherwise use REST.
  const data = useMemo(() => {
    const useWs = wsSource && wsHistory && wsHistory.length > 0;
    const sourceRows = useWs ? wsHistory! : rows;

    if (useWs) {
      return (wsHistory!).slice(-50).map((r) => ({
        ts: new Date(r.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        flowRate: Number(r.flowRateLs.toFixed(2)),
        pressure: Number(r.pressureHeadM.toFixed(2)),
        celerity: Number(r.estimatedCelerity.toFixed(0)),
        apuTemp: Number(r.apuTemperatureC.toFixed(1)),
        invariantOk: r.invariantOk ? 1 : 0,
        state: r.systemState,
      }));
    }

    return rows.slice(-50).map((r) => ({
      ts: fmtTime(r.createdAt),
      flowRate: Number(r.flowRateLs.toFixed(2)),
      pressure: Number(r.pressureHeadM.toFixed(2)),
      celerity: Number(r.estimatedCelerity.toFixed(0)),
      apuTemp: Number(r.apuTemperatureC.toFixed(1)),
      invariantOk: r.invariantOk ? 1 : 0,
      state: r.systemState,
    }));
  }, [rows, wsHistory, wsSource]);

  const last = data[data.length - 1];
  const avgCelerity = data.length > 0 ? Math.round(data.reduce((s, d) => s + d.celerity, 0) / data.length) : 0;
  const maxApu = data.length > 0 ? Math.max(...data.map((d) => d.apuTemp)) : 0;
  const minApu = data.length > 0 ? Math.min(...data.map((d) => d.apuTemp)) : 0;
  const violationCount = data.filter((d) => d.invariantOk === 0).length;
  const integrityPct = data.length > 0 ? Math.round(((data.length - violationCount) / data.length) * 1000) / 10 : 100;

  // Compute FSM state transition points for chart annotations
  const transitions = useMemo(() => {
    const pts: Array<{ ts: string; celerity: number; apuTemp: number; fromState: string; toState: string; color: string }> = [];
    for (let i = 1; i < data.length; i++) {
      if (data[i].state !== data[i - 1].state) {
        const color =
          data[i].state === 'FAIL_CLOSED_LOCKDOWN' ? '#ef4444'
          : data[i].state === 'THERMAL_THROTTLE' ? '#ff8a00'
          : data[i].state === 'LEAK_SIMULATION_ACTIVE' ? '#C46D1A'
          : '#c8ff00';
        pts.push({
          ts: data[i].ts,
          celerity: data[i].celerity,
          apuTemp: data[i].apuTemp,
          fromState: data[i - 1].state,
          toState: data[i].state,
          color,
        });
      }
    }
    return pts;
  }, [data]);

  // Chart zoom — disabled (simplified hook still causes client-side crash with recharts)
  // The useChartZoom hook is available in chart-zoom-controls.tsx but not wired here.
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-semibold">Live Telemetry Charts</h3>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {onToggleWs && (
            <Button
              size="sm"
              variant="ghost"
              className={`h-7 gap-1 px-2 text-[10px] font-mono ${
                wsSource
                  ? 'border border-lime-700 bg-lime-950/40 text-lime-300'
                  : 'border border-muted bg-muted/30 text-muted-foreground'
              }`}
              onClick={onToggleWs}
              title="Toggle between WebSocket push (real-time) and REST polling"
            >
              {wsSource ? <Wifi className="h-3 w-3" /> : <Radio className="h-3 w-3" />}
              {wsSource ? 'WS LIVE' : 'REST'}
              {wsConnected !== undefined && (
                <span className={`ml-1 inline-block h-1.5 w-1.5 rounded-full ${wsConnected ? 'bg-lime-400 animate-pulse' : 'bg-slate-600'}`} />
              )}
            </Button>
          )}
          <Badge variant="outline" className="font-mono border-lime-700 bg-lime-950/50 text-lime-300">
            N = {data.length}
          </Badge>
          <Badge variant="outline" className="font-mono border-violet-700 bg-violet-950/50 text-violet-300">
            avg a = {avgCelerity} m/s
          </Badge>
          <Badge variant="outline" className="font-mono border-orange-700 bg-orange-950/50 text-orange-300">
            APU {minApu.toFixed(1)}–{maxApu.toFixed(1)}°C
          </Badge>
          <Badge variant="outline" className="font-mono border-emerald-700 bg-emerald-950/50 text-emerald-300">
            integrity {integrityPct}%
          </Badge>
        </div>
      </div>

      {/* Big 2x2 grid */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
        {/* Flow + Pressure chart */}
        <Card className="border-border vvu-card-surface p-3">
          <div className="mb-2 flex items-center justify-between">
            <h4 className="text-xs font-semibold text-muted-foreground">Flow Rate & Pressure Head</h4>
            <span className="text-[10px] text-muted-foreground">last {data.length} events</span>
          </div>
          <ChartContainer config={chartConfig} className="aspect-auto h-[180px] w-full">
            <ResponsiveContainer>
              <AreaChart data={data} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                <defs>
                  <linearGradient id="gradFlow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%"  stopColor={chartConfig.flowRate.color} stopOpacity={0.4} />
                    <stop offset="100%" stopColor={chartConfig.flowRate.color} stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gradPressure" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%"  stopColor={chartConfig.pressure.color} stopOpacity={0.4} />
                    <stop offset="100%" stopColor={chartConfig.pressure.color} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a2436" vertical={false} />
                <XAxis dataKey="ts" tickLine={false} axisLine={false} tick={{ fontSize: 9, fill: '#64748b' }} interval="preserveStartEnd" minTickGap={40} />
                <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 9, fill: '#64748b' }} width={32} />
                <ChartTooltip content={<ChartTooltipContent labelClassName="text-foreground" />} />
                <Area type="monotone" dataKey="flowRate" stroke={chartConfig.flowRate.color} strokeWidth={1.5} fill="url(#gradFlow)" name="Flow (L/s)" />
                <Area type="monotone" dataKey="pressure" stroke={chartConfig.pressure.color} strokeWidth={1.5} fill="url(#gradPressure)" name="Pressure (m)" />
              </AreaChart>
            </ResponsiveContainer>
          </ChartContainer>
        </Card>

        {/* Celerity chart with safe-harbour band */}
        <Card className="border-border vvu-card-surface p-3">
          <div className="mb-2 flex items-center justify-between">
            <h4 className="text-xs font-semibold text-muted-foreground">Joukowsky Celerity (SANS 200–1400 m/s)</h4>
            <span className="text-[10px] text-muted-foreground">a (m/s)</span>
          </div>
          <ChartContainer config={chartConfig} className="aspect-auto h-[180px] w-full">
            <ResponsiveContainer>
              <LineChart data={data} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a2436" vertical={false} />
                <XAxis dataKey="ts" tickLine={false} axisLine={false} tick={{ fontSize: 9, fill: '#64748b' }} interval="preserveStartEnd" minTickGap={40} />
                <YAxis
                  tickLine={false} axisLine={false} tick={{ fontSize: 9, fill: '#64748b' }} width={32}
                  domain={[SANS_CELERITY_BOUNDS.min, SANS_CELERITY_BOUNDS.max + 50]}
                />
                <ChartTooltip content={<ChartTooltipContent />} />
                <ReferenceLine y={SANS_CELERITY_BOUNDS.min} stroke="#22c55e" strokeDasharray="4 4" strokeOpacity={0.5} label={{ value: 'min', fontSize: 9, fill: '#22c55e' }} />
                <ReferenceLine y={SANS_CELERITY_BOUNDS.max} stroke="#ef4444" strokeDasharray="4 4" strokeOpacity={0.5} label={{ value: 'max', fontSize: 9, fill: '#ef4444' }} />
                <Line type="monotone" dataKey="celerity" stroke={chartConfig.celerity.color} strokeWidth={2} dot={false} name="Celerity" />
                {/* FSM state transition annotations */}
                {transitions.map((t, i) => (
                  <ReferenceDot
                    key={`cel-t-${i}`}
                    x={t.ts}
                    y={t.celerity}
                    r={5}
                    fill={t.color}
                    stroke="#06080c"
                    strokeWidth={1.5}
                    isFront
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        </Card>

        {/* APU temp chart with thresholds */}
        <Card className="border-border vvu-card-surface p-3">
          <div className="mb-2 flex items-center justify-between">
            <h4 className="text-xs font-semibold text-muted-foreground">APU Thermal Drift (65 throttle / 85 fail-closed)</h4>
            <span className="text-[10px] text-muted-foreground">T (°C)</span>
          </div>
          <ChartContainer config={chartConfig} className="aspect-auto h-[180px] w-full">
            <ResponsiveContainer>
              <LineChart data={data} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a2436" vertical={false} />
                <XAxis dataKey="ts" tickLine={false} axisLine={false} tick={{ fontSize: 9, fill: '#64748b' }} interval="preserveStartEnd" minTickGap={40} />
                <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 9, fill: '#64748b' }} width={32} domain={[20, 100]} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <ReferenceLine y={APU_THERMAL_BOUNDS.throttle} stroke="#ff8a00" strokeDasharray="4 4" strokeOpacity={0.5} label={{ value: 'throttle', fontSize: 9, fill: '#ff8a00' }} />
                <ReferenceLine y={APU_THERMAL_BOUNDS.failClosed} stroke="#ef4444" strokeDasharray="4 4" strokeOpacity={0.5} label={{ value: 'fail-closed', fontSize: 9, fill: '#ef4444' }} />
                <Line type="monotone" dataKey="apuTemp" stroke={chartConfig.apuTemp.color} strokeWidth={2} dot={false} name="APU Temp" />
                {/* FSM state transition annotations on APU chart */}
                {transitions.map((t, i) => (
                  <ReferenceDot
                    key={`apu-t-${i}`}
                    x={t.ts}
                    y={t.apuTemp}
                    r={5}
                    fill={t.color}
                    stroke="#06080c"
                    strokeWidth={1.5}
                    isFront
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        </Card>

        {/* Invariant bar chart */}
        <Card className="border-border vvu-card-surface p-3">
          <div className="mb-2 flex items-center justify-between">
            <h4 className="text-xs font-semibold text-muted-foreground">Invariant Integrity (per event)</h4>
            <span className="text-[10px] text-muted-foreground">0 = violated · 1 = ok</span>
          </div>
          <ChartContainer config={chartConfig} className="aspect-auto h-[180px] w-full">
            <ResponsiveContainer>
              <BarChart data={data} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a2436" vertical={false} />
                <XAxis dataKey="ts" tickLine={false} axisLine={false} tick={{ fontSize: 9, fill: '#64748b' }} interval="preserveStartEnd" minTickGap={40} />
                <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 9, fill: '#64748b' }} width={32} domain={[0, 1]} ticks={[0, 1]} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="invariantOk" radius={2} name="Inv">
                  {data.map((d, i) => (
                    <Cell key={i} fill={d.invariantOk === 1 ? chartConfig.invariant.color : '#ef4444'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </Card>
      </div>

      {last && (
        <Card className="border-border/40 bg-gradient-to-r from-lime-950/30 via-violet-950/20 to-orange-950/30 p-3">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="inline-block h-2 w-2 rounded-full bg-lime-400 animate-pulse" />
              <span className="text-xs text-muted-foreground">Latest event</span>
              <span className="font-mono text-xs text-lime-300">{last.ts}</span>
              <span className="text-xs text-muted-foreground">·</span>
              <span className="font-mono text-xs text-sky-300">Q={last.flowRate.toFixed(1)} L/s</span>
              <span className="text-xs text-muted-foreground">·</span>
              <span className="font-mono text-xs text-sky-300">H={last.pressure.toFixed(1)} m</span>
              <span className="text-xs text-muted-foreground">·</span>
              <span className="font-mono text-xs text-violet-300">a={last.celerity} m/s</span>
              <span className="text-xs text-muted-foreground">·</span>
              <span className="font-mono text-xs text-orange-300">T={last.apuTemp.toFixed(1)}°C</span>
            </div>
            <span className={`font-mono text-[10px] px-1.5 py-0.5 rounded ${last.invariantOk === 1 ? 'bg-lime-500/20 text-lime-300' : 'bg-red-500/20 text-red-300'}`}>
              {last.invariantOk === 1 ? 'INVARIANT OK' : 'INVARIANT VIOLATED'}
            </span>
          </div>
        </Card>
      )}

      {/* FSM transition legend */}
      {transitions.length > 0 && (
        <Card className="border-border/40 vvu-card-surface p-2">
          <div className="flex items-center gap-3 flex-wrap text-[9px] text-muted-foreground">
            <span className="font-semibold text-foreground">FSM transitions on charts:</span>
            <span className="flex items-center gap-1">
              <span className="inline-block h-2 w-2 rounded-full" style={{ background: '#c8ff00' }} />
              recovery
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block h-2 w-2 rounded-full" style={{ background: '#C46D1A' }} />
              leak start
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block h-2 w-2 rounded-full" style={{ background: '#ff8a00' }} />
              thermal throttle
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block h-2 w-2 rounded-full" style={{ background: '#ef4444' }} />
              fail-closed
            </span>
            <span className="ml-auto font-mono">{transitions.length} transitions detected</span>
          </div>
        </Card>
      )}
    </div>
  );
}
