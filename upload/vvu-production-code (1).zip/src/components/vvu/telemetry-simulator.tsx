'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Play, Pause, RotateCcw, Zap, Activity, Thermometer, Gauge } from 'lucide-react';
import { mockTelemetry, estimateCelerity, classifyThermal, SANS_CELERITY_BOUNDS } from '@/lib/vvu-telemetry';
import { VVU_SITES } from '@/lib/vvu-sites';

interface TelemetrySimulatorProps {
  tenantId: string;
  tenantSlug: string;
  onIngest: (payload: {
    nodeId: string;
    flowRateLs: number;
    pressureHeadM: number;
    acousticAbnormal: boolean;
    apuTemperatureC: number;
    tenantId: string;
  }) => Promise<void>;
  onSimulateLeak?: () => void;
}

export function TelemetrySimulator({ tenantId, tenantSlug, onIngest, onSimulateLeak }: TelemetrySimulatorProps) {
  const [running, setRunning] = useState(true);
  const [tick, setTick] = useState(0);
  const [flowRateLs, setFlowRateLs] = useState(15);
  const [pressureHeadM, setPressureHeadM] = useState(35);
  const [apuTempC, setApuTempC] = useState(48);
  const [lastResult, setLastResult] = useState<{
    celerity: number;
    state: string;
    invariantOk: boolean;
  } | null>(null);
  const [ingesting, setIngesting] = useState(false);

  const site = VVU_SITES.find((s) => s.slug === tenantSlug) ?? VVU_SITES[0];

  useEffect(() => {
    if (!running) return;
    const interval = setInterval(async () => {
      const t = tick + 1;
      setTick(t);
      const node = site.nodes[t % site.nodes.length];
      const mock = mockTelemetry(tenantId, node.id, t);
      // blend with user override
      mock.flowRateLs = Math.round(((mock.flowRateLs + flowRateLs) / 2) * 10) / 10;
      mock.pressureHeadM = Math.round(((mock.pressureHeadM + pressureHeadM) / 2) * 10) / 10;
      // inject a thermal drift toward the user value, but never let it just sit
      const drift = (apuTempC - mock.apuTemperatureC) * 0.4;
      mock.apuTemperatureC = Math.max(20, Math.min(95, Math.round((mock.apuTemperatureC + drift) * 10) / 10));
      try {
        setIngesting(true);
        await onIngest(mock);
        const celerity = estimateCelerity({
          pressureHeadM: mock.pressureHeadM,
          flowRateLs: mock.flowRateLs,
        });
        const cls = classifyThermal(mock.apuTemperatureC);
        setLastResult({ celerity, state: cls.state, invariantOk: cls.invariantOk });
      } finally {
        setIngesting(false);
      }
    }, 2200);
    return () => clearInterval(interval);
  }, [running, tick, tenantId, flowRateLs, pressureHeadM, apuTempC, tenantSlug, site.nodes, onIngest]);

  function dispatchLeak() {
    setPressureHeadM(Math.round((12 + Math.random() * 6) * 10) / 10);
    setFlowRateLs(Math.round((48 + Math.random() * 12) * 10) / 10);
    onSimulateLeak?.();
  }

  function reset() {
    setFlowRateLs(15);
    setPressureHeadM(35);
    setApuTempC(48);
  }

  return (
    <Card className="border-border vvu-card-surface p-3 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">Edge Telemetry Simulator</h3>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant={running ? 'default' : 'outline'}
            className="h-7 gap-1 text-[11px]"
            onClick={() => setRunning((r) => !r)}
          >
            {running ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
            {running ? 'Pause' : 'Run'}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 text-[11px]"
            onClick={reset}
          >
            <RotateCcw className="h-3 w-3" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-7 gap-1 border-orange-700 bg-orange-950/40 text-orange-300 hover:bg-orange-950 text-[11px]"
            onClick={dispatchLeak}
          >
            <Zap className="h-3 w-3" /> Simulate leak
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
        <div className="space-y-1">
          <Label className="flex items-center justify-between text-[10px]">
            <span className="flex items-center gap-1"><Activity className="h-3 w-3" /> Flow rate</span>
            <span className="font-mono">{flowRateLs.toFixed(1)} L/s</span>
          </Label>
          <Input
            type="number"
            step="0.1"
            value={flowRateLs}
            onChange={(e) => setFlowRateLs(parseFloat(e.target.value) || 0)}
            className="h-8 text-xs font-mono"
          />
        </div>
        <div className="space-y-1">
          <Label className="flex items-center justify-between text-[10px]">
            <span className="flex items-center gap-1"><Gauge className="h-3 w-3" /> Pressure head</span>
            <span className="font-mono">{pressureHeadM.toFixed(1)} m</span>
          </Label>
          <Input
            type="number"
            step="0.1"
            value={pressureHeadM}
            onChange={(e) => setPressureHeadM(parseFloat(e.target.value) || 0)}
            className="h-8 text-xs font-mono"
          />
        </div>
        <div className="space-y-1">
          <Label className="flex items-center justify-between text-[10px]">
            <span className="flex items-center gap-1"><Thermometer className="h-3 w-3" /> APU temp</span>
            <span className="font-mono">{apuTempC.toFixed(1)} °C</span>
          </Label>
          <Input
            type="number"
            step="0.1"
            value={apuTempC}
            onChange={(e) => setApuTempC(parseFloat(e.target.value) || 0)}
            className="h-8 text-xs font-mono"
          />
        </div>
      </div>

      {lastResult && (
        <div className="grid grid-cols-3 gap-2 text-[10px]">
          <div className="rounded border border-border px-2 py-1">
            <div className="text-muted-foreground">Celerity (recomputed)</div>
            <div className="font-mono text-sky-300">
              {lastResult.celerity.toFixed(0)} m/s
              <span className="ml-1 text-[9px] text-muted-foreground">/ {SANS_CELERITY_BOUNDS.min}–{SANS_CELERITY_BOUNDS.max}</span>
            </div>
          </div>
          <div className="rounded border border-border px-2 py-1">
            <div className="text-muted-foreground">Derived FSM state</div>
            <div className="font-mono text-lime-400">{lastResult.state.replace(/_/g, ' ')}</div>
          </div>
          <div className="rounded border border-border px-2 py-1">
            <div className="text-muted-foreground">Invariant</div>
            <div className={`font-mono ${lastResult.invariantOk ? 'text-lime-400' : 'text-red-400'}`}>
              {lastResult.invariantOk ? 'OK' : 'VIOLATED'}
            </div>
          </div>
        </div>
      )}

      {ingesting && (
        <div className="text-[10px] text-muted-foreground animate-pulse">
          Ingesting edge payload to /api/vvu/telemetry…
        </div>
      )}
    </Card>
  );
}
