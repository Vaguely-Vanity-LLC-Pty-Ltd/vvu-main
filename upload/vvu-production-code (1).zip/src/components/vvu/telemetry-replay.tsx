'use client';

import { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Play, Pause, SkipBack, SkipForward, Rewind, Clock, Gauge, Radio, Wifi } from 'lucide-react';
import type { TelemetryRow } from './telemetry-feed';
import type { WsTelemetry } from '@/hooks/use-vvu-socket';

interface TelemetryReplayProps {
  rows: TelemetryRow[];
  wsHistory?: WsTelemetry[];
  wsSource?: boolean;
}

export function TelemetryReplay({ rows, wsHistory, wsSource }: TelemetryReplayProps) {
  const [position, setPosition] = useState(0); // 0..rows.length-1
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1); // 1x, 2x, 4x
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Use WS history if available and wsSource is true, otherwise use REST rows
  const sourceRows = useMemo(() => {
    if (wsSource && wsHistory && wsHistory.length > 0) {
      // Convert WsTelemetry to TelemetryRow-compatible format
      return wsHistory.map((w) => ({
        id: `ws-${w.tick}`,
        nodeId: w.nodeId,
        flowRateLs: w.flowRateLs,
        pressureHeadM: w.pressureHeadM,
        apuTemperatureC: w.apuTemperatureC,
        acousticAbnormal: w.acousticAbnormal,
        estimatedCelerity: w.estimatedCelerity,
        invariantOk: w.invariantOk,
        systemState: w.systemState,
        createdAt: new Date(w.at).toISOString(),
      } as TelemetryRow));
    }
    return rows;
  }, [rows, wsHistory, wsSource]);

  const chronRows = useMemo(() => [...sourceRows].reverse(), [sourceRows]); // oldest first
  const max = Math.max(0, chronRows.length - 1);

  const current = chronRows[position];

  // Auto-play
  useEffect(() => {
    if (!playing || max === 0) return;
    intervalRef.current = setInterval(() => {
      setPosition((p) => {
        if (p >= max) {
          setPlaying(false);
          return max;
        }
        return p + 1;
      });
    }, 1000 / speed); // 1s per step at 1x
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [playing, speed, max]);

  const jumpTo = useCallback((idx: number) => {
    setPosition(Math.max(0, Math.min(max, idx)));
  }, [max]);

  const replay = useCallback(() => {
    setPosition(0);
    setPlaying(true);
  }, []);

  const fmtTime = (iso: string) => {
    try {
      return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    } catch {
      return '?';
    }
  };

  if (chronRows.length === 0) {
    return (
      <Card className="border-border vvu-card-surface p-3">
        <h3 className="text-sm font-semibold mb-2">Telemetry Replay</h3>
        <p className="text-[11px] text-muted-foreground">No telemetry data to replay yet.</p>
      </Card>
    );
  }

  // Build mini sparkline data for the scrubber track
  const sparkline = chronRows.map((r) => Number(r.estimatedCelerity.toFixed(0)));
  const sparkMin = Math.min(...sparkline);
  const sparkMax = Math.max(...sparkline);
  const sparkRange = Math.max(1, sparkMax - sparkMin);

  return (
    <Card className="border-border vvu-card-surface p-3 space-y-3 vvu-glow-hover">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-semibold">Telemetry Replay</h3>
          <Badge variant="outline" className="font-mono text-[9px] border-violet-700 bg-violet-950/40 text-violet-300">
            <Clock className="mr-1 h-2.5 w-2.5" />
            {chronRows.length} events
          </Badge>
          {wsSource && wsHistory && wsHistory.length > 0 && (
            <Badge variant="outline" className="font-mono text-[9px] border-lime-700 bg-lime-950/40 text-lime-300">
              <Wifi className="mr-1 h-2.5 w-2.5" />
              WS LIVE
            </Badge>
          )}
          {!wsSource && (
            <Badge variant="outline" className="font-mono text-[9px] border-muted bg-muted/30 text-muted-foreground">
              <Radio className="mr-1 h-2.5 w-2.5" />
              REST
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0"
            onClick={() => jumpTo(0)}
            disabled={position === 0}
            title="Jump to start"
          >
            <SkipBack className="h-3 w-3" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0"
            onClick={() => jumpTo(Math.max(0, position - 10))}
            disabled={position === 0}
            title="Back 10 steps"
          >
            <Rewind className="h-3 w-3" />
          </Button>
          <Button
            size="sm"
            variant={playing ? 'default' : 'outline'}
            className="h-7 gap-1 text-[11px]"
            onClick={() => setPlaying((p) => !p)}
          >
            {playing ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
            {playing ? 'Pause' : 'Play'}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 gap-1 text-[11px]"
            onClick={replay}
            title="Replay from start"
          >
            <SkipForward className="h-3 w-3" /> Replay
          </Button>
          <Select
            value={String(speed)}
            onValueChange={(v) => setSpeed(Number(v))}
          >
            <SelectTrigger className="h-7 w-[60px] text-[10px] gap-1 px-2">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1×</SelectItem>
              <SelectItem value="2">2×</SelectItem>
              <SelectItem value="4">4×</SelectItem>
              <SelectItem value="8">8×</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Scrubber with sparkline background */}
      <div className="relative">
        <div className="relative h-12 rounded border border-border vvu-surface-deeper overflow-hidden">
          {/* Sparkline */}
          <svg
            viewBox={`0 0 ${chronRows.length} 40`}
            preserveAspectRatio="none"
            className="absolute inset-0 w-full h-full"
          >
            <polyline
              points={sparkline.map((v, i) => {
                const x = i;
                const y = 40 - ((v - sparkMin) / sparkRange) * 36 - 2;
                return `${x},${y}`;
              }).join(' ')}
              fill="none"
              stroke="#a78bfa"
              strokeWidth="1"
              strokeOpacity="0.5"
            />
            {/* Filled area under sparkline */}
            <polygon
              points={`0,40 ${sparkline.map((v, i) => {
                const x = i;
                const y = 40 - ((v - sparkMin) / sparkRange) * 36 - 2;
                return `${x},${y}`;
              }).join(' ')} ${chronRows.length - 1},40`}
              fill="url(#replay-grad)"
              opacity="0.3"
            />
            <defs>
              <linearGradient id="replay-grad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#a78bfa" stopOpacity="0.6" />
                <stop offset="100%" stopColor="#a78bfa" stopOpacity="0" />
              </linearGradient>
            </defs>
            {/* Position marker */}
            {current && (
              <line
                x1={position}
                y1="0"
                x2={position}
                y2="40"
                stroke="#c8ff00"
                strokeWidth="0.5"
                strokeOpacity="0.8"
              />
            )}
          </svg>
        </div>
        {/* Slider overlay */}
        <Slider
          value={[position]}
          min={0}
          max={max}
          step={1}
          onValueChange={(v) => { setPosition(v[0]); setPlaying(false); }}
          className="absolute inset-0 opacity-0 cursor-pointer"
        />
      </div>

      {/* Position info */}
      <div className="flex items-center justify-between text-[10px] font-mono text-muted-foreground">
        <span>
          Step {position + 1} / {chronRows.length}
        </span>
        <span>
          {current ? fmtTime(current.createdAt) : '—'}
        </span>
      </div>

      {/* Current event details */}
      {current && (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 text-[10px] font-mono">
          <div className="rounded border border-border/40 vvu-surface-deeper px-2 py-1">
            <div className="text-muted-foreground text-[9px] uppercase">Node</div>
            <div className="text-lime-400">{current.nodeId}</div>
          </div>
          <div className="rounded border border-border/40 vvu-surface-deeper px-2 py-1">
            <div className="text-muted-foreground text-[9px] uppercase">Q (L/s)</div>
            <div className="text-sky-300">{current.flowRateLs.toFixed(1)}</div>
          </div>
          <div className="rounded border border-border/40 vvu-surface-deeper px-2 py-1">
            <div className="text-muted-foreground text-[9px] uppercase">H (m)</div>
            <div className="text-sky-300">{current.pressureHeadM.toFixed(1)}</div>
          </div>
          <div className="rounded border border-border/40 vvu-surface-deeper px-2 py-1">
            <div className="text-muted-foreground text-[9px] uppercase">a (m/s)</div>
            <div className="text-violet-300">{current.estimatedCelerity.toFixed(0)}</div>
          </div>
          <div className="rounded border border-border/40 vvu-surface-deeper px-2 py-1">
            <div className="text-muted-foreground text-[9px] uppercase">APU (°C)</div>
            <div className={current.apuTemperatureC >= 85 ? 'text-red-400' : current.apuTemperatureC >= 65 ? 'text-orange-400' : 'text-lime-400'}>
              {current.apuTemperatureC.toFixed(1)}
            </div>
          </div>
          <div className="rounded border border-border/40 vvu-surface-deeper px-2 py-1">
            <div className="text-muted-foreground text-[9px] uppercase">State</div>
            <div className="text-foreground truncate" title={current.systemState}>
              {current.systemState.replace(/_/g, ' ')}
            </div>
          </div>
          <div className="rounded border border-border/40 vvu-surface-deeper px-2 py-1">
            <div className="text-muted-foreground text-[9px] uppercase">Invariant</div>
            <div className={current.invariantOk ? 'text-lime-400' : 'text-red-400'}>
              {current.invariantOk ? '✓ OK' : '✗ VIOLATED'}
            </div>
          </div>
          <div className="rounded border border-border/40 vvu-surface-deeper px-2 py-1">
            <div className="text-muted-foreground text-[9px] uppercase">Acoustic</div>
            <div className={current.acousticAbnormal ? 'text-red-400' : 'text-muted-foreground'}>
              {current.acousticAbnormal ? '⚠ ABNORMAL' : 'normal'}
            </div>
          </div>
        </div>
      )}

      {/* Progress bar */}
      <div className="flex items-center gap-2">
        <Gauge className="h-3 w-3 text-muted-foreground" />
        <div className="flex-1 h-1 rounded-full bg-muted overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-violet-500 to-lime-400 transition-all duration-200"
            style={{ width: `${max > 0 ? (position / max) * 100 : 0}%` }}
          />
        </div>
        <span className="text-[9px] text-muted-foreground font-mono">
          {max > 0 ? Math.round((position / max) * 100) : 0}%
        </span>
      </div>
    </Card>
  );
}

// Inline Select import to avoid circular dep issues
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
