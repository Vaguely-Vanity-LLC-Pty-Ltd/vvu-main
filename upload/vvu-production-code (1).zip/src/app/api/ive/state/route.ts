import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  EVIDENCE_BOUND,
  AUTHORIZATION_FORMULA,
  type ClaimWithRelations,
  type EstateKey,
} from "@/lib/eis";

export const dynamic = "force-dynamic";

// GET /api/state — the full aggregate: claims[] with nested evidence,
// authorizations (last 5), circuitEvents (last 5), nIndRecords (last 3) + summary.
export async function GET() {
  const claims = await db.claim.findMany({
    orderBy: { createdAt: "asc" },
    include: {
      evidence: { orderBy: { collectedAt: "asc" } },
      authorizations: { orderBy: { createdAt: "desc" }, take: 5 },
      circuitEvents: { orderBy: { trippedAt: "desc" }, take: 5 },
      nIndRecords: { orderBy: { createdAt: "desc" }, take: 3 },
      estate: true,
    },
  });

  const serialised = claims.map((c: any): ClaimWithRelations => ({
    id: c.id,
    title: c.title,
    description: c.description,
    claimType: c.claimType,
    state: c.state,
    intendedAction: c.intendedAction,
    safetyCritical: c.safetyCritical,
    estateId: c.estateId,
    estateKey: (c.estateKey ?? "canonical") as EstateKey,
    createdAt: c.createdAt instanceof Date ? c.createdAt.toISOString() : String(c.createdAt),
    updatedAt: c.updatedAt instanceof Date ? c.updatedAt.toISOString() : String(c.updatedAt),
    evidence: (c.evidence ?? []).map((e: any) => ({
      id: e.id,
      claimId: e.claimId,
      source: e.source,
      content: e.content,
      embedding: safeParseArray(e.embedding),
      weight: e.weight,
      state: e.state,
      collectedAt:
        e.collectedAt instanceof Date ? e.collectedAt.toISOString() : String(e.collectedAt),
    })),
    authorizations: (c.authorizations ?? []).map((a: any) => ({
      id: a.id,
      claimId: a.claimId,
      claimOk: a.claimOk,
      evidenceOk: a.evidenceOk,
      integrityOk: a.integrityOk,
      safetyOk: a.safetyOk,
      reviewOk: a.reviewOk,
      authorized: a.authorized,
      reason: a.reason,
      createdAt:
        a.createdAt instanceof Date ? a.createdAt.toISOString() : String(a.createdAt),
    })),
    circuitEvents: (c.circuitEvents ?? []).map((e: any) => ({
      id: e.id,
      claimId: e.claimId,
      triggered: e.triggered,
      reason: e.reason,
      trippedAt:
        e.trippedAt instanceof Date ? e.trippedAt.toISOString() : String(e.trippedAt),
    })),
    nIndRecords: (c.nIndRecords ?? []).map((n: any) => ({
      id: n.id,
      claimId: n.claimId,
      numEvidence: n.numEvidence,
      numSources: n.numSources,
      nInd: n.nInd,
      gamma: n.gamma,
      eigenvalues: safeParseArray(n.eigenvalues),
      createdAt:
        n.createdAt instanceof Date ? n.createdAt.toISOString() : String(n.createdAt),
    })),
  }));

  const stateCounts: Record<string, number> = {};
  let totalEvidence = 0;
  let authorizedClaims = 0;
  let breakerTripped = 0;
  for (const c of serialised) {
    stateCounts[c.state] = (stateCounts[c.state] ?? 0) + 1;
    totalEvidence += c.evidence.length;
    if (c.authorizations[0]?.authorized) authorizedClaims++;
    if (c.circuitEvents[0]?.triggered) breakerTripped++;
  }

  return NextResponse.json({
    claims: serialised,
    summary: {
      totalClaims: serialised.length,
      authorizedClaims,
      breakerTripped,
      totalEvidence,
      stateCounts,
      evidenceBound: EVIDENCE_BOUND,
      authorizationFormula: AUTHORIZATION_FORMULA,
      failClosed: true,
    },
  });
}

function safeParseArray(raw: unknown): number[] {
  if (Array.isArray(raw)) return raw as number[];
  if (typeof raw !== "string") return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? (v as number[]) : [];
  } catch {
    return [];
  }
}
