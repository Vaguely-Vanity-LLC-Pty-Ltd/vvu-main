import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ESTATE_META, type EstateKey } from "@/lib/eis";

export const dynamic = "force-dynamic";

// GET /api/estates — list estates with per-estate summary counts.
export async function GET() {
  const estates = await db.estate.findMany({ orderBy: { createdAt: "asc" } });
  const claims = await db.claim.findMany({
    include: {
      evidence: true,
      authorizations: { orderBy: { createdAt: "desc" }, take: 1 },
      circuitEvents: { orderBy: { trippedAt: "desc" }, take: 1 },
    },
  });

  const out = estates.map((e: any) => {
    const meta = ESTATE_META[e.key as EstateKey] ?? ESTATE_META.canonical;
    const estateClaims = claims.filter((c: any) => c.estateKey === e.key);
    const totalClaims = estateClaims.length;
    let totalEvidence = 0;
    let authorizedClaims = 0;
    let breakerTripped = 0;
    const stateCounts: Record<string, number> = {};
    for (const c of estateClaims as any[]) {
      totalEvidence += c.evidence.length;
      if (c.authorizations[0]?.authorized) authorizedClaims++;
      if (c.circuitEvents[0]?.triggered) breakerTripped++;
      stateCounts[c.state] = (stateCounts[c.state] ?? 0) + 1;
    }
    return {
      id: e.id,
      key: e.key,
      name: meta.name,
      description: meta.description,
      accent: meta.accent,
      theorem: meta.theorem,
      totalClaims,
      totalEvidence,
      authorizedClaims,
      breakerTripped,
      stateCounts,
    };
  });

  return NextResponse.json({ estates: out });
}
