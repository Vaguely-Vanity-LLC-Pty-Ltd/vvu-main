import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  computeClaimState,
  computeParticipationRatio,
  evaluateAuthorization,
  queryEvidenceMeshForEstate,
  recomputeClaimState,
  ESTATE_META,
  type EvidenceSource,
  type VerificationState,
} from "@/lib/eis";
import { SEED_CLAIMS } from "@/lib/eis/estate-seed";

export const dynamic = "force-dynamic";

// POST /api/seed — idempotent. Wipes all 6 canonical tables + Estate,
// then inserts the Estate metadata + the SEED_CLAIMS (with evidence,
// N_ind, authorization, circuit-breaker events where appropriate).
export async function POST() {
  // wipe in dependency order
  await db.heatKernelStep.deleteMany();
  await db.circuitBreaker.deleteMany();
  await db.authorization.deleteMany();
  await db.nIndComputation.deleteMany();
  await db.evidence.deleteMany();
  await db.claim.deleteMany();
  await db.estate.deleteMany();

  // insert estates
  const estateIdByKey: Record<string, string> = {};
  for (const [key, meta] of Object.entries(ESTATE_META)) {
    const e = await db.estate.create({
      data: {
        key,
        name: meta.name,
        description: meta.description,
        accent: meta.accent,
        theorem: meta.theorem,
      },
    });
    estateIdByKey[key] = e.id;
  }

  const created: any[] = [];
  for (let i = 0; i < SEED_CLAIMS.length; i++) {
    const spec = SEED_CLAIMS[i];
    const estateId = estateIdByKey[spec.estateKey] ?? null;
    const claim = await db.claim.create({
      data: {
        title: spec.title,
        description: spec.description,
        claimType: spec.claimType,
        state: "UNTESTED",
        intendedAction: spec.intendedAction,
        safetyCritical: spec.safetyCritical,
        estateId,
        estateKey: spec.estateKey,
      },
    });

    // ingest mesh evidence with estate flavor + explicit per-source states
    const mesh = queryEvidenceMeshForEstate(spec.title, spec.seed, spec.estateKey);
    const evidenceRows: any[] = [];
    for (let j = 0; j < mesh.length; j++) {
      const m = mesh[j];
      const overrideState = spec.sourceStates?.[m.source as EvidenceSource];
      const state: VerificationState =
        overrideState ?? (m.state as VerificationState);
      const ev = await db.evidence.create({
        data: {
          claimId: claim.id,
          source: m.source,
          content: m.content,
          embedding: JSON.stringify(m.embedding),
          weight: m.weight,
          state,
        },
      });
      evidenceRows.push(ev);
    }

    // compute claim state (Theorem 4)
    const evidenceStates = evidenceRows.map((e) => e.state as VerificationState);
    const newState = computeClaimState(spec.claimType, evidenceStates);
    await db.claim.update({ where: { id: claim.id }, data: { state: newState } });

    // compute N_ind (Theorem 2)
    const embeddings = evidenceRows.map((e) => safeParseArray(e.embedding));
    const pr = computeParticipationRatio(embeddings);
    const nIndRow = await db.nIndComputation.create({
      data: {
        claimId: claim.id,
        numEvidence: pr.numEvidence,
        numSources: pr.numSources,
        nInd: pr.nInd,
        gamma: pr.gamma,
        eigenvalues: JSON.stringify(pr.eigenvalues),
      },
    });

    // evaluate authorization (Theorem 1) — leave safety + review unsigned for
    // safety-critical claims so the dashboard demonstrates fail-closed A=false.
    const auth = evaluateAuthorization({
      claimType: spec.claimType,
      claimState: newState,
      evidence: evidenceRows.map((e) => ({
        id: e.id,
        claimId: e.claimId,
        source: e.source,
        content: e.content,
        embedding: safeParseArray(e.embedding),
        weight: e.weight,
        state: e.state,
        collectedAt: e.collectedAt.toISOString(),
      })),
      nInd: pr.nInd,
      safetyCritical: spec.safetyCritical,
      safetyOverride: false,
      reviewSignedOff: false,
    });
    const authRow = await db.authorization.create({
      data: {
        claimId: claim.id,
        claimOk: auth.claimOk,
        evidenceOk: auth.evidenceOk,
        integrityOk: auth.integrityOk,
        safetyOk: auth.safetyOk,
        reviewOk: auth.reviewOk,
        authorized: auth.authorized,
        reason: auth.reason,
      },
    });

    // circuit-breaker (Theorem 5) — trip for claims that fail integrity/safety.
    let trip = false;
    let reason: string = "";
    if (pr.nInd < (spec.safetyCritical ? 2 : 1) - 0.5) {
      trip = true;
      reason = "integrity_breach";
    } else if (spec.safetyCritical && !auth.safetyOk) {
      trip = true;
      reason = "safety_violation";
    } else if (newState === "UNTESTED" || newState === "STALE") {
      trip = true;
      reason = "verification_failed";
    }
    if (trip) {
      await db.circuitBreaker.create({
        data: { claimId: claim.id, triggered: true, reason },
      });
    }

    created.push({
      claim,
      evidenceCount: evidenceRows.length,
      nInd: nIndRow,
      authorization: authRow,
      circuitTripped: trip,
      circuitReason: reason,
    });
  }

  return NextResponse.json({ seeded: true, count: created.length, items: created });
}

function safeParseArray(raw: unknown): number[] {
  if (Array.isArray(raw)) return raw as number[];
  if (typeof raw !== "string") return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? (v as number[]) : [];
  } catch {
    return [];
  }
}
