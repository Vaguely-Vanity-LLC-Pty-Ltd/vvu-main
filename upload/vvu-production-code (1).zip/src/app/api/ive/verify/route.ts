import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { computeClaimState, statesInOrder } from "@/lib/eis";

export const dynamic = "force-dynamic";

// POST /api/verify — { claimId }
// Lifts the claim state: state(c) = max { state(e) } capped by claimType.
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const claimId = String(body.claimId ?? "");
  if (!claimId) return NextResponse.json({ error: "claimId required" }, { status: 400 });

  const claim = await db.claim.findUnique({
    where: { id: claimId },
    include: { evidence: { orderBy: { collectedAt: "asc" } } },
  });
  if (!claim) return NextResponse.json({ error: "claim not found" }, { status: 404 });

  const previousState = claim.state as any;
  const evidenceStates = claim.evidence.map((e) => e.state as any);
  const newState = computeClaimState(claim.claimType as any, evidenceStates);
  if (newState !== previousState) {
    await db.claim.update({ where: { id: claimId }, data: { state: newState } });
  }

  return NextResponse.json({
    trace: {
      previousState,
      newState,
      evidenceStates,
      claimType: claim.claimType,
      appliedCap: newState,
      latticeOrder: statesInOrder(),
      rule: "state(c) = max { state(e) : e ∈ E(c) } capped by claimType",
    },
  });
}
