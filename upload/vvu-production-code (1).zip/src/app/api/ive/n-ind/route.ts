import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { computeParticipationRatio } from "@/lib/eis";

export const dynamic = "force-dynamic";

// GET /api/n-ind?claimId=...
export async function GET(req: Request) {
  const url = new URL(req.url);
  const claimId = url.searchParams.get("claimId");
  if (!claimId) return NextResponse.json({ error: "claimId required" }, { status: 400 });
  const records = await db.nIndComputation.findMany({
    where: { claimId },
    orderBy: { createdAt: "desc" },
  });
  const serialised = records.map((r) => ({
    ...r,
    eigenvalues: safeParseArray(r.eigenvalues),
  }));
  return NextResponse.json({ records: serialised });
}

// POST /api/n-ind — { claimId, gamma? }
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const claimId = String(body.claimId ?? "");
  if (!claimId) return NextResponse.json({ error: "claimId required" }, { status: 400 });
  const gammaOverride = body.gamma !== undefined ? Number(body.gamma) : undefined;

  const claim = await db.claim.findUnique({
    where: { id: claimId },
    include: { evidence: { orderBy: { collectedAt: "asc" } } },
  });
  if (!claim) return NextResponse.json({ error: "claim not found" }, { status: 404 });

  const embeddings = claim.evidence.map((e) => safeParseArray(e.embedding));
  const pr = computeParticipationRatio(embeddings, gammaOverride);

  const row = await db.nIndComputation.create({
    data: {
      claimId,
      numEvidence: pr.numEvidence,
      numSources: pr.numSources,
      nInd: pr.nInd,
      gamma: pr.gamma,
      eigenvalues: JSON.stringify(pr.eigenvalues),
    },
  });

  return NextResponse.json({
    ...pr,
    id: row.id,
    claimId: row.claimId,
    createdAt: row.createdAt instanceof Date ? row.createdAt.toISOString() : String(row.createdAt),
  });
}

function safeParseArray(raw: unknown): number[] {
  if (Array.isArray(raw)) return raw as number[];
  if (typeof raw !== "string") return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? (v as number[]) : [];
  } catch {
    return [];
  }
}
