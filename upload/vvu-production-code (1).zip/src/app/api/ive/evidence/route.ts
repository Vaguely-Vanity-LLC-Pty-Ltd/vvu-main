import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  queryEvidenceMeshForEstate,
  synthesizeEmbedding,
  type EvidenceSource,
} from "@/lib/eis";

export const dynamic = "force-dynamic";

// GET /api/evidence?claimId=...
export async function GET(req: Request) {
  const url = new URL(req.url);
  const claimId = url.searchParams.get("claimId");
  if (!claimId) {
    return NextResponse.json({ error: "claimId required" }, { status: 400 });
  }
  const evidence = await db.evidence.findMany({
    where: { claimId },
    orderBy: { collectedAt: "asc" },
  });
  const serialised = evidence.map((e) => ({
    ...e,
    embedding: safeParseArray(e.embedding),
  }));
  return NextResponse.json({ evidence: serialised });
}

// POST /api/evidence — { claimId, source?, content?, weight?, state="OBSERVED", seed? }
//   If `source` provided → single item; else full Mesh query.
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const claimId = String(body.claimId ?? "");
  if (!claimId) return NextResponse.json({ error: "claimId required" }, { status: 400 });
  const seed = Number(body.seed ?? Math.floor(Math.random() * 9999));

  const claim = await db.claim.findUnique({ where: { id: claimId } });
  if (!claim) return NextResponse.json({ error: "claim not found" }, { status: 404 });

  if (body.source) {
    // single evidence item
    const source = String(body.source) as EvidenceSource;
    const content = String(body.content ?? `Manual evidence item from ${source}.`);
    const weight = Number(body.weight ?? 0.8);
    const state = String(body.state ?? "OBSERVED");
    const embedding = synthesizeEmbedding(source, seed * 10 + 1);
    const ev = await db.evidence.create({
      data: {
        claimId,
        source,
        content,
        embedding: JSON.stringify(embedding),
        weight,
        state,
      },
    });
    return NextResponse.json({
      evidence: { ...ev, embedding: safeParseArray(ev.embedding) },
    });
  }

  // full mesh query with estate flavor
  const mesh = queryEvidenceMeshForEstate(claim.title, seed, claim.estateKey ?? "canonical");
  const created: any[] = [];
  for (const m of mesh) {
    const ev = await db.evidence.create({
      data: {
        claimId,
        source: m.source,
        content: m.content,
        embedding: JSON.stringify(m.embedding),
        weight: m.weight,
        state: m.state as string,
      },
    });
    created.push({ ...ev, embedding: safeParseArray(ev.embedding) });
  }
  return NextResponse.json({ evidence: created });
}

function safeParseArray(raw: unknown): number[] {
  if (Array.isArray(raw)) return raw as number[];
  if (typeof raw !== "string") return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? (v as number[]) : [];
  } catch {
    return [];
  }
}
