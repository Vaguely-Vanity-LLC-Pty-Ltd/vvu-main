import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  computeParticipationRatio,
  evaluateAuthorization,
  recomputeClaimState,
} from "@/lib/eis";

export const dynamic = "force-dynamic";

// POST /api/authorize — { claimId, safetyOverride=false, reviewSignedOff=false }
// Lifts the claim state, computes N_ind inline if missing, evaluates A = C∧E∧I∧S∧R,
// persists the Authorization row, returns the full result.
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const claimId = String(body.claimId ?? "");
  if (!claimId) return NextResponse.json({ error: "claimId required" }, { status: 400 });
  const safetyOverride = !!body.safetyOverride;
  const reviewSignedOff = !!body.reviewSignedOff;

  const claim = await db.claim.findUnique({
    where: { id: claimId },
    include: { evidence: { orderBy: { collectedAt: "asc" } } },
  });
  if (!claim) return NextResponse.json({ error: "claim not found" }, { status: 404 });

  // recompute claim state (lift if evidence changed since verify)
  const newState = recomputeClaimState(claim.claimType as any, claim.evidence as any);
  if (newState !== claim.state) {
    await db.claim.update({ where: { id: claimId }, data: { state: newState } });
  }

  // compute N_ind inline if no recent record
  let nIndValue = 0;
  let nIndRecord = await db.nIndComputation.findFirst({
    where: { claimId },
    orderBy: { createdAt: "desc" },
  });
  if (!nIndRecord) {
    const embeddings = claim.evidence.map((e) => safeParseArray(e.embedding));
    const pr = computeParticipationRatio(embeddings);
    nIndRecord = await db.nIndComputation.create({
      data: {
        claimId,
        numEvidence: pr.numEvidence,
        numSources: pr.numSources,
        nInd: pr.nInd,
        gamma: pr.gamma,
        eigenvalues: JSON.stringify(pr.eigenvalues),
      },
    });
    nIndValue = pr.nInd;
  } else {
    nIndValue = nIndRecord.nInd;
  }

  const auth = evaluateAuthorization({
    claimType: claim.claimType as any,
    claimState: newState,
    evidence: claim.evidence.map((e) => ({
      id: e.id,
      claimId: e.claimId,
      source: e.source as any,
      content: e.content,
      embedding: safeParseArray(e.embedding),
      weight: e.weight,
      state: e.state as any,
      collectedAt: e.collectedAt instanceof Date ? e.collectedAt.toISOString() : String(e.collectedAt),
    })),
    nInd: nIndValue,
    safetyCritical: claim.safetyCritical,
    safetyOverride,
    reviewSignedOff,
  });

  const row = await db.authorization.create({
    data: {
      claimId,
      claimOk: auth.claimOk,
      evidenceOk: auth.evidenceOk,
      integrityOk: auth.integrityOk,
      safetyOk: auth.safetyOk,
      reviewOk: auth.reviewOk,
      authorized: auth.authorized,
      reason: auth.reason,
    },
  });

  // Theorem 5 (fail-closed): when reverification restores the evidence
  // bound (authorized=true), clear the breaker by appending a
  // non-triggered event. When authorization fails, ensure a breaker trip
  // is recorded so the fail-closed state is visible.
  if (auth.authorized) {
    await db.circuitBreaker.create({
      data: { claimId, triggered: false, reason: "" },
    });
  } else {
    // only add a trip if the latest event isn't already tripped (avoid spam)
    const latest = await db.circuitBreaker.findFirst({
      where: { claimId },
      orderBy: { trippedAt: "desc" },
    });
    if (!latest || !latest.triggered) {
      let reason = "safety_violation";
      if (!auth.claimOk) reason = "verification_failed";
      else if (!auth.integrityOk) reason = "integrity_breach";
      await db.circuitBreaker.create({
        data: { claimId, triggered: true, reason },
      });
    }
  }

  return NextResponse.json({
    ...auth,
    id: row.id,
    claimId: row.claimId,
    claimState: newState,
    nInd: nIndValue,
    createdAt: row.createdAt instanceof Date ? row.createdAt.toISOString() : String(row.createdAt),
  });
}

function safeParseArray(raw: unknown): number[] {
  if (Array.isArray(raw)) return raw as number[];
  if (typeof raw !== "string") return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? (v as number[]) : [];
  } catch {
    return [];
  }
}
