import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { computeClaimState } from "@/lib/eis";

export const dynamic = "force-dynamic";

// GET /api/claims — all claims with nested evidence + relations.
export async function GET() {
  const claims = await db.claim.findMany({
    orderBy: { createdAt: "asc" },
    include: {
      evidence: { orderBy: { collectedAt: "asc" } },
      authorizations: { orderBy: { createdAt: "desc" } },
      circuitEvents: { orderBy: { trippedAt: "desc" } },
      nIndRecords: { orderBy: { createdAt: "desc" } },
      estate: true,
    },
  });
  return NextResponse.json({ claims });
}

// POST /api/claims — create a new claim (state=UNTESTED).
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const title = String(body.title ?? "").trim();
  if (!title) {
    return NextResponse.json({ error: "title is required" }, { status: 400 });
  }
  const description = String(body.description ?? "").trim();
  const claimType = (body.claimType ?? "empirical") as string;
  const intendedAction = String(body.intendedAction ?? "deploy");
  const safetyCritical = body.safetyCritical ?? true;
  const estateKey = (body.estateKey ?? "canonical") as string;

  // resolve estate id
  const estate = await db.estate.findUnique({ where: { key: estateKey } });
  const claim = await db.claim.create({
    data: {
      title,
      description,
      claimType,
      state: "UNTESTED",
      intendedAction,
      safetyCritical,
      estateId: estate?.id ?? null,
      estateKey,
    },
  });
  // touch computeClaimState for type-checking (no evidence yet → UNTESTED)
  void computeClaimState(claimType as any, []);
  return NextResponse.json({ claim });
}
