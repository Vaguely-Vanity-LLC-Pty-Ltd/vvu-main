import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

interface Ctx {
  params: Promise<{ id: string }>;
}

// GET /api/claims/[id]
export async function GET(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const claim = await db.claim.findUnique({
    where: { id },
    include: {
      evidence: { orderBy: { collectedAt: "asc" } },
      authorizations: { orderBy: { createdAt: "desc" }, take: 5 },
      circuitEvents: { orderBy: { trippedAt: "desc" }, take: 5 },
      nIndRecords: { orderBy: { createdAt: "desc" }, take: 3 },
      estate: true,
    },
  });
  if (!claim) return NextResponse.json({ error: "not found" }, { status: 404 });
  const serialised = {
    ...claim,
    evidence: (claim.evidence as any[]).map((e) => ({
      ...e,
      embedding: safeParseArray(e.embedding),
    })),
    nIndRecords: (claim.nIndRecords as any[]).map((n) => ({
      ...n,
      eigenvalues: safeParseArray(n.eigenvalues),
    })),
  };
  return NextResponse.json({ claim: serialised });
}

// PATCH /api/claims/[id]
export async function PATCH(req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  const data: Record<string, unknown> = {};
  if (body.state !== undefined) data.state = String(body.state);
  if (body.safetyCritical !== undefined) data.safetyCritical = !!body.safetyCritical;
  if (body.intendedAction !== undefined) data.intendedAction = String(body.intendedAction);
  if (body.claimType !== undefined) data.claimType = String(body.claimType);
  const claim = await db.claim.update({ where: { id }, data });
  return NextResponse.json({ claim });
}

// DELETE /api/claims/[id]
export async function DELETE(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  await db.claim.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}

function safeParseArray(raw: unknown): number[] {
  if (Array.isArray(raw)) return raw as number[];
  if (typeof raw !== "string") return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? (v as number[]) : [];
  } catch {
    return [];
  }
}
