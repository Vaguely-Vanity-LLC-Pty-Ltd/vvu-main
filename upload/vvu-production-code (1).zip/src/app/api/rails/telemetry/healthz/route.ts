import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET /api/rails/telemetry/healthz — replaces :3003/healthz
// The watchdog probes this to check if the telemetry rail is UP.
export async function GET() {
  return NextResponse.json({
    ok: true,
    service: 'telemetry-service',
    port: 3003,
    status: 'healthy',
    nodeId: 'ESP32-S3-HUB-01',
    fsmState: 'STEADY_STATE_LOCKED',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
}
