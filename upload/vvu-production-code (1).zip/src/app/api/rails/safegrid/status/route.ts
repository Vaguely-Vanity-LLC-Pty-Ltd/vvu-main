import { NextResponse } from 'next/server';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET /api/rails/safegrid/status — replaces :3008 root (pure API, root 404 expected)
// But we return 200 with ok:true for the fleet probe
export async function GET() {
  return NextResponse.json({
    ok: true,
    service: 'safegrid-api',
    port: 3008,
    grid: { load_mw: 0, active_nodes: 0, healthy_nodes: 0 },
    timestamp: new Date().toISOString(),
  });
}
