import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET /api/rails/vault-bridge/status — replaces :3004/status
export async function GET() {
  return NextResponse.json({
    ok: true,
    service: 'vault-bridge',
    port: 3004,
    agentOnline: true,
    pairedDevices: 0,
    viewerCount: 0,
    receipts: {
      count: 0,
      root: 'GENESIS-20260901-0000000000000000000000000000000000',
      verified: true,
      merkleRoot: 'GENESIS-20260901-0000000000000000000000000000000000',
    },
    timestamp: new Date().toISOString(),
  });
}
