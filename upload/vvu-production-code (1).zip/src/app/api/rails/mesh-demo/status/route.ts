import { NextResponse } from 'next/server';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET /api/rails/mesh-demo/status — replaces :3007 root
export async function GET() {
  return NextResponse.json({
    ok: true,
    service: 'mesh-demo',
    port: 3007,
    peers: { online: 0, capacity: 100 },
    mesh: { diameter: 0, edges: 0 },
    timestamp: new Date().toISOString(),
  });
}
