import { NextResponse } from 'next/server';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET /api/rails/wildfire-mesh/status — replaces :3006 root
export async function GET() {
  return NextResponse.json({
    ok: true,
    service: 'wildfire-mesh',
    port: 3006,
    chain: { depth: 0, head: 'GENESIS-20260901-0000000000000000000000000000000000' },
    sensors: { active: 0, alerts: 0 },
    timestamp: new Date().toISOString(),
  });
}
