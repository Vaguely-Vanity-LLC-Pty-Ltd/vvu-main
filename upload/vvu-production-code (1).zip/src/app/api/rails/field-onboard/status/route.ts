import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// GET /api/rails/field-onboard/status — replaces :3005/status
export async function GET() {
  return NextResponse.json({
    ok: true,
    service: 'vvu-field-onboard',
    port: 3005,
    node: 'FIELD-NODE-01',
    protocol: 'BLE+TOTP',
    agentOnline: true,
    pairedDevices: 0,
    receipts: {
      count: 0,
      root: 'GENESIS-20260901-0000000000000000000000000000000000',
      verified: true,
    },
    timestamp: new Date().toISOString(),
  });
}
