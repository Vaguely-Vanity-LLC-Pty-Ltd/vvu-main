import { NextResponse } from "next/server";
import { turso, isTurso } from "@/lib/turso";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    if (isTurso) {
      const subjects = await turso.execute("SELECT * FROM GovernanceSubject LIMIT 50");
      const policies = await turso.execute("SELECT * FROM GovernancePolicyState LIMIT 50");
      return NextResponse.json({
        ok: true,
        subjects: subjects.rows,
        policies: policies.rows,
      });
    } else {
      const subjects = await db.governanceSubject.findMany({ take: 50 });
      const policies = await db.governancePolicyState.findMany({ take: 50 });
      return NextResponse.json({ ok: true, subjects, policies });
    }
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 502 });
  }
}
