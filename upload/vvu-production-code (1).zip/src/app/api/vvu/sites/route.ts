import { NextResponse } from 'next/server';
import { VVU_SITES } from '@/lib/vvu-sites';

export const dynamic = 'force-dynamic';

// GET /api/vvu/sites — return all VVU site configurations
export async function GET() {
  return NextResponse.json({
    ok: true,
    count: VVU_SITES.length,
    sites: VVU_SITES.map((s) => ({
      slug: s.slug,
      name: s.name,
      region: s.region,
      latitude: s.latitude,
      longitude: s.longitude,
      altitudeM: s.altitudeM,
      accent: s.accent,
      accentSoft: s.accentSoft,
      nodeCount: s.nodes.length,
      nodes: s.nodes,
    })),
  });
}
