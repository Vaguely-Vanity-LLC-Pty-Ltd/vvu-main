import { NextResponse } from 'next/server';
import { HYDRAULIC_INVARIANTS, HARDWARE_BOM } from '@/lib/vvu-release-manifest';
import { SANS_CELERITY_BOUNDS, APU_THERMAL_BOUNDS, FAVAD_EXPONENT_BOUNDS, FACTOR_OF_SAFETY_BOUNDS } from '@/lib/vvu-telemetry';

export const dynamic = 'force-dynamic';

// GET /api/vvu/invariants — return the safe-harbour hydraulic + thermal invariants
export async function GET() {
  return NextResponse.json({
    ok: true,
    sansCelerityBounds: SANS_CELERITY_BOUNDS,
    apuThermalBounds: APU_THERMAL_BOUNDS,
    favadExponentBounds: FAVAD_EXPONENT_BOUNDS,
    factorOfSafetyBounds: FACTOR_OF_SAFETY_BOUNDS,
    hydraulic: HYDRAULIC_INVARIANTS,
    hardware: HARDWARE_BOM,
  });
}
