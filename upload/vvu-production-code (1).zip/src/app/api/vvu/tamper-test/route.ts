import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { seedSovereignDb } from '@/lib/vvu-seed';
import { flagTampered } from '@/lib/vvu-ledger';

export const dynamic = 'force-dynamic';

// POST /api/vvu/tamper-test — artificially flag a ledger entry as tampered.
// Auto-restores after 10s to demo the active tamper alert.
export async function POST(request: Request) {
  await seedSovereignDb();
  let body: { fileId?: string; tenantSlug?: string };
  try {
    body = await request.json();
  } catch {
    body = {};
  }
  const tenantSlug = body.tenantSlug ?? 'gqeberha';
  const tenant = await db.tenant.findUnique({ where: { slug: tenantSlug } });
  if (!tenant) return NextResponse.json({ ok: false, error: 'unknown tenant' }, { status: 404 });

  // Pick the first ledger entry that isn't already tampered
  let entry = body.fileId
    ? await db.ledgerEntry.findFirst({ where: { tenantId: tenant.id, fileId: body.fileId } })
    : await db.ledgerEntry.findFirst({ where: { tenantId: tenant.id, tampered: false } });
  if (!entry) {
    return NextResponse.json({ ok: false, error: 'no ledger entry to tamper' }, { status: 404 });
  }

  const tampered = await flagTampered(entry.fileId, true);
  if (!tampered) {
    return NextResponse.json({ ok: false, error: 'flag failed' }, { status: 500 });
  }

  // Append audit entry
  await db.auditLog.create({
    data: {
      tenantId: tenant.id,
      actor: 'tamper-test',
      action: 'TAMPER_TEST_FLAG',
      reason: `Manual tamper drill on ${entry.fileId} (${entry.filename})`,
      metadata: JSON.stringify({ fileId: entry.fileId, originalSha: entry.sha256 }),
    },
  });

  // Auto-restore after 10s
  setTimeout(async () => {
    try {
      await flagTampered(entry!.fileId, false);
      await db.auditLog.create({
        data: {
          tenantId: tenant!.id,
          actor: 'tamper-test',
          action: 'TAMPER_TEST_AUTO_RESTORE',
          reason: `Auto-restore of ${entry!.fileId}`,
          metadata: JSON.stringify({ fileId: entry!.fileId }),
        },
      });
    } catch (e) {
      console.error('auto-restore failed', e);
    }
  }, 10_000);

  return NextResponse.json({
    ok: true,
    fileId: entry.fileId,
    filename: entry.filename,
    originalSha256: entry.sha256,
    tamperedSha256: tampered.sha256,
    autoRestoreInMs: 10_000,
  });
}
