import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { seedSovereignDb } from '@/lib/vvu-seed';

export const dynamic = 'force-dynamic';

// GET /api/vvu/state?tenant=gqeberha — aggregate dashboard state for one tenant
export async function GET(request: Request) {
  await seedSovereignDb();
  const { searchParams } = new URL(request.url);
  const tenantSlug = searchParams.get('tenant') ?? 'gqeberha';
  const tenant = await db.tenant.findUnique({ where: { slug: tenantSlug } });
  if (!tenant) return NextResponse.json({ ok: false, error: 'unknown tenant' }, { status: 404 });

  const [lastTelemetry, tamperedCount, totalLedger, auditCount, telemetryCount] = await Promise.all([
    db.telemetryLog.findFirst({
      where: { tenantId: tenant.id },
      orderBy: { createdAt: 'desc' },
    }),
    db.ledgerEntry.count({ where: { tenantId: tenant.id, tampered: true } }),
    db.ledgerEntry.count({ where: { tenantId: tenant.id } }),
    db.auditLog.count({ where: { tenantId: tenant.id } }),
    db.telemetryLog.count({ where: { tenantId: tenant.id } }),
  ]);

  return NextResponse.json({
    ok: true,
    tenant: { slug: tenant.slug, name: tenant.name, region: tenant.region, id: tenant.id },
    currentState: lastTelemetry?.systemState ?? 'DISCONNECTED',
    lastTelemetry: lastTelemetry
      ? {
          nodeId: lastTelemetry.nodeId,
          flowRateLs: lastTelemetry.flowRateLs,
          pressureHeadM: lastTelemetry.pressureHeadM,
          apuTemperatureC: lastTelemetry.apuTemperatureC,
          estimatedCelerity: lastTelemetry.estimatedCelerity,
          invariantOk: lastTelemetry.invariantOk,
          acousticAbnormal: lastTelemetry.acousticAbnormal,
          at: lastTelemetry.createdAt,
        }
      : null,
    ledger: { tampered: tamperedCount, total: totalLedger, verified: totalLedger - tamperedCount },
    audit: { count: auditCount },
    telemetry: { count: telemetryCount },
  });
}
