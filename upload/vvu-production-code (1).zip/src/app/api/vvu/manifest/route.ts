import { NextResponse } from 'next/server';
import { RELEASE_MANIFEST, RELEASE_STAMP, RELEASE_VERSION, CORPORATE_FACTS } from '@/lib/vvu-release-manifest';

export const dynamic = 'force-dynamic';

// GET /api/vvu/manifest — VVU HBK Mk-II 15-file release manifest (Design Freeze Level 1)
export async function GET() {
  return NextResponse.json({
    stamp: RELEASE_STAMP,
    version: RELEASE_VERSION,
    corporate: CORPORATE_FACTS,
    fileCount: RELEASE_MANIFEST.length,
    totalSizeBytes: RELEASE_MANIFEST.reduce((s, f) => s + f.sizeBytes, 0),
    files: RELEASE_MANIFEST,
  });
}
