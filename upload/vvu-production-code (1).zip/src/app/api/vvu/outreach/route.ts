import { NextResponse } from "next/server";
import { turso, isTurso } from "@/lib/turso";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    if (isTurso) {
      const targets = await turso.execute("SELECT COUNT(*) as count FROM OutreachTarget");
      const emails = await turso.execute("SELECT COUNT(*) as count FROM OutreachEmail");
      return NextResponse.json({
        targets: (targets.rows[0] as any)?.count ?? 0,
        emails: (emails.rows[0] as any)?.count ?? 0,
      });
    } else {
      const targets = await db.outreachTarget.count();
      const emails = await db.outreachEmail.count();
      return NextResponse.json({ targets, emails });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
