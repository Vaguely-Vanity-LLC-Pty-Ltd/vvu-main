import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

// POST /api/vvu/verify-hash — server-side SHA-256 of an inline content stream
export async function POST(request: Request) {
  let body: { content?: string; filename?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'invalid JSON' }, { status: 400 });
  }
  const content = body.content ?? '';
  const filename = body.filename ?? 'inline';
  if (!content) {
    return NextResponse.json({ ok: false, error: 'missing content' }, { status: 400 });
  }

  const t0 = performance.now();
  const enc = new TextEncoder().encode(content);
  const digest = await crypto.subtle.digest('SHA-256', enc);
  const hex = Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
  const durationUs = Math.round((performance.now() - t0) * 1000);

  return NextResponse.json({
    ok: true,
    filename,
    sha256: hex,
    bytes: enc.length,
    durationUs,
  });
}
