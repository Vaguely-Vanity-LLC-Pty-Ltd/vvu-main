import { NextRequest, NextResponse } from "next/server";
import { Apinator } from "@apinator/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const client = new Apinator({
  appId: "53cd1754-56eb-4711-b006-612e38724875",
  key: "app_129060d2a83c30bb63a3d5ca143970a26a5c4936",
  secret: process.env.APINATOR_SECRET || "4eca9e26e063b94bdfe6b23142cdaf8422c886ccbab2638560de80d2ff8a005b",
  cluster: "eu"
});

// POST /api/realtime/auth — authenticate private/presence channels
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { socket_id, channel_name } = body;

    if (!socket_id || !channel_name) {
      return NextResponse.json({ error: "missing socket_id or channel_name" }, { status: 400 });
    }

    // Presence channels require user_id + user_info
    const channelData = channel_name.startsWith("presence-")
      ? JSON.stringify({ user_id: "vvu-operator", user_info: { name: "VVU Operator" } })
      : undefined;

    const auth = client.authenticateChannel(socket_id, channel_name, channelData);
    return NextResponse.json(auth);
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : String(e) }, { status: 500 });
  }
}
