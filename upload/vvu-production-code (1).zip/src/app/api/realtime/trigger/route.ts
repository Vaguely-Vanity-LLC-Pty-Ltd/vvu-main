import { NextRequest, NextResponse } from "next/server";
import { Apinator } from "@apinator/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const client = new Apinator({
  appId: "53cd1754-56eb-4711-b006-612e38724875",
  key: "app_129060d2a83c30bb63a3d5ca143970a26a5c4936",
  secret: process.env.APINATOR_SECRET || "4eca9e26e063b94bdfe6b23142cdaf8422c886ccbab2638560de80d2ff8a005b",
  cluster: "eu"
});

// POST /api/realtime/trigger — publish an event to a channel
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, channel, data } = body;

    if (!name || !channel || !data) {
      return NextResponse.json({ error: "missing name, channel, or data" }, { status: 400 });
    }

    await client.trigger({
      name,
      channel,
      data: typeof data === "string" ? data : JSON.stringify(data)
    });

    return NextResponse.json({ ok: true, published: { name, channel } });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : String(e) }, { status: 500 });
  }
}

// GET /api/realtime/trigger — return Apinator config for the client
export async function GET() {
  return NextResponse.json({
    appKey: "app_129060d2a83c30bb63a3d5ca143970a26a5c4936",
    cluster: "eu",
    authEndpoint: "/api/realtime/auth",
    wsUrl: "wss://ws-eu.apinator.io"
  });
}
