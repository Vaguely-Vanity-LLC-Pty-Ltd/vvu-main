// src/app/api/guardian/route.ts — R66 · the :3000 guardian's own report.
// ─────────────────────────────────────────────────────────────────────────────
// The guardian (.zscripts/guardian.py, daemonized) watches next-server's
// kernel-reported VmRSS against the OOM guard and the port-3000 liveness,
// and performs the R63-playbook CONTROLLED BOUNCE before the kernel's OOM
// killer can do it mid-compile. This endpoint is the READ side:
//
//   status  vvu-trust/guardian/status.json   — rewritten by the guardian
//                                              every pass (20s)
//   journal vvu-trust/guardian/bounces.jsonl — one append-only line per
//                                              bounce attempt
//
// Honesty rules:
//   - present:false when no status file exists → the UI says GUARDIAN OFF
//     (no invention, no fake green).
//   - stale:true when the last pass is older than 3× the guardian's own
//     interval → the UI says STALE (a dead guardian must be visible, not
//     silent).
//   - The guardian pid is re-verified from .zscripts/guardian.pid — a file
//     that says ARMED means nothing if the process is gone.
//   - READ-ONLY: this route never writes, never bounces, never kills.
// ─────────────────────────────────────────────────────────────────────────────

import { NextResponse } from 'next/server';
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { buildIntervalSeries } from '@/lib/intervals';
import { buildRailProjection } from '@/lib/operator-projection';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ROOT = process.cwd();
const STATUS_PATH = join(ROOT, 'vvu-trust', 'guardian', 'status.json');
const JOURNAL_PATH = join(ROOT, 'vvu-trust', 'guardian', 'bounces.jsonl');
const GUARDIAN_PIDFILE = join(ROOT, '.zscripts', 'guardian.pid');
const GUARDIAN_LOG = join(ROOT, '.zscripts', 'guardian.log');
const GUARDIAN_LOG_PREV = `${GUARDIAN_LOG}.1`; // R73 — rotated generation (older)

interface GuardianStatus {
  mode: string;
  guardianPid: number;
  startedAtUtc: string;
  intervalSec: number;
  guardMb: number;
  availFloorMb?: number;
  devPid: number | null;
  devPidAlive: boolean;
  nextServerPid: number | null;
  rssKb: number | null;
  hwmKb: number | null;
  boxAvailKb?: number | null;
  portOk: boolean;
  duplicateDetected: boolean;
  consecutiveOver: number;
  consecutiveDead: number;
  consecutiveLow?: number;
  consecutiveCrit?: number;
  availCriticalMb?: number;
  bounces: number;
  lastAction: string;
  lastBounceAtUtc: string | null;
  lastPassAtUtc: string;
  /** R93 — the bounded memory-pressure series (oldest first, ≤90 samples ≈
   *  30 min at the 20s pass): the kernel-race made visible. Lives in the
   *  guardian's memory, so a re-arm resets it — arm-span scope, honest; the
   *  journal remains the durable record. Pre-R93 status files lack the key
   *  and the UI renders that absence honestly (the R75 contract). */
  memSeries?: Array<{ t: string; rssKb: number | null; availKb: number | null }>;
}

function parseUtc(label: string): number {
  // guardian.py stamps "%Y-%m-%d %H:%M:%S UTC" — parse on the server clock,
  // no client-side re-interpretation.
  const m = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2}) UTC$/.exec(label.trim());
  if (!m) return NaN;
  return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
}

function pidAlive(pid: number | null): boolean {
  if (!pid || !Number.isFinite(pid)) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return (e as NodeJS.ErrnoException).code === 'EPERM';
  }
}

// R69 — the warm plateau, read from the guardian's OWN pass log. Every pass
// line carries the same VmRSS the OOM killer weighs; the median of the last
// N healthy passes is the estate's honest operating baseline, and the
// distance from that baseline to the guard is the real headroom. This is
// the recalibration tripwire R68 asked for: if the plateau climbs toward
// the guard, the guard must move or the journal fills with bounces.
// R70 — the plateau TREND joins it: across a wider window (up to 120 passes,
// ~40 minutes) the median of the newest half minus the median of the oldest
// half. A level tells the operator where the estate sits; a trend tells them
// where it is GOING — and it was a climbing plateau (1736 → 1912 MB inside
// one uptime) that made R69's "cosmetic recalibration" suggestion the wrong
// move: amber at a climbing plateau is the gauge telling the truth, not a
// calibration error. The 10-pass window sees only ~3 minutes and would hide
// the climb; the baseline CONTRACT is unchanged (median of the 10 newest).
// The pass-line regex is tolerant of the log's older format (early lines
// carry no avail= field — they are history too). A drop in the trend is
// usually a fresh boot after a save — the window may span a bounce.
interface PassSample {
  at: string;
  rssKb: number;
}

function medianKbOf(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 1
    ? (sorted[mid] ?? 0)
    : Math.round(((sorted[mid - 1] ?? 0) + (sorted[mid] ?? 0)) / 2);
}

function readGuardianLogText(): string {
  // R73 — BOTH generations, rotated (older) first: a copytruncate rotation
  // restarts the live log empty, and a live-only read would drop the trend
  // to nulls for ~4 min (until 12 samples re-accumulate). Concatenated
  // [.1, live] keeps the newest-first walk correct across the boundary.
  // One unreadable generation degrades to the other — never a crash.
  let text = '';
  for (const p of [GUARDIAN_LOG_PREV, GUARDIAN_LOG]) {
    try {
      if (existsSync(p)) text += readFileSync(p, 'utf8');
    } catch {
      // skip the unreadable generation
    }
  }
  return text;
}

function computePlateau(guardMb: number | null): {
  baselineMb: number | null;
  headroomMb: number | null;
  driftMb: number | null;
  samples: number;
  since: string | null;
  until: string | null;
} | null {
  if (guardMb == null) return null;
  const text = readGuardianLogText();
  if (!text) return null; // guardian off or no log generation readable — honest null
  const lines = text.split('\n');
  const samples: PassSample[] = [];
  // Newest-first walk over the pass log; tolerant of the older line format
  // (no avail= field). Cap = trend window + the 10 the baseline needs.
  for (let i = lines.length - 1; i >= 0 && samples.length < 130; i--) {
    const m = /^\[([^\]]+)\] pass nextPid=\S+ rss=(\d+) hwm=\d+ (?:avail=\S+ )?port=UP /.exec(lines[i] ?? '');
    if (m && m[1] && m[2]) {
      samples.push({ at: m[1], rssKb: Number(m[2]) });
    }
  }
  if (samples.length === 0) return null;
  // Baseline contract (R69, unchanged): median of the 10 NEWEST passes.
  const baselineMb = Math.round(medianKbOf(samples.slice(0, 10).map((s) => s.rssKb)) / 1024);
  // R70 trend: restore chronological order and compare the half-medians of
  // the sampled window (up to 120 passes). Fewer than 12 cannot carry a
  // trend honestly — null, not a guess.
  const window = samples.slice(0, 120);
  const chron = [...window].reverse();
  let driftMb: number | null = null;
  if (chron.length >= 12) {
    const half = Math.floor(chron.length / 2);
    const oldMed = medianKbOf(chron.slice(0, half).map((s) => s.rssKb));
    const newMed = medianKbOf(chron.slice(chron.length - half).map((s) => s.rssKb));
    driftMb = Math.round((newMed - oldMed) / 1024);
  }
  return {
    baselineMb,
    headroomMb: guardMb - baselineMb,
    driftMb,
    samples: window.length,
    since: window[window.length - 1]?.at ?? null,
    until: window[0]?.at ?? null,
  };
}

export async function GET() {
  if (!existsSync(STATUS_PATH)) {
    return NextResponse.json(
      {
        present: false,
        armCommand:
          'python3 .zscripts/daemonize.py --cwd /home/z/my-project --pidfile .zscripts/guardian.pid --log .zscripts/guardian.log -- python3 .zscripts/guardian.py',
      },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  }

  let status: GuardianStatus | null = null;
  try {
    status = JSON.parse(readFileSync(STATUS_PATH, 'utf8')) as GuardianStatus;
  } catch {
    return NextResponse.json(
      { present: false, error: 'status.json unreadable' },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  }

  // Liveness + staleness from OUR vantage (the server's own clock), not
  // taken on faith from the status file.
  let guardianFilePid: number | null = null;
  try {
    guardianFilePid = Number(readFileSync(GUARDIAN_PIDFILE, 'utf8').trim());
  } catch {
    guardianFilePid = null;
  }
  const guardianAlive = pidAlive(guardianFilePid ?? status.guardianPid);

  const lastPassMs = parseUtc(status.lastPassAtUtc);
  const staleAfterMs = 3 * (status.intervalSec ?? 20) * 1000;
  const stale =
    !guardianAlive || !Number.isFinite(lastPassMs) || Date.now() - lastPassMs > staleAfterMs;

  // Journal — ONE read serves the tail, the total, the drills and the R90
  // resilience aggregate. A missing/empty journal is the CLEAN record (no
  // bounces yet), not an error. Rows stay chronological here; the UI tail
  // is reversed at the slice.
  let allRows: Array<Record<string, unknown>> = [];
  if (existsSync(JOURNAL_PATH)) {
    try {
      allRows = readFileSync(JOURNAL_PATH, 'utf8')
        .split('\n')
        .filter(Boolean)
        .map((line) => {
          try {
            return JSON.parse(line) as Record<string, unknown>;
          } catch {
            return { unparsable: true, raw: line.slice(0, 200) };
          }
        });
    } catch {
      allRows = [];
    }
  }

  const bounces: Array<Record<string, unknown>> = allRows.slice(-5).reverse();
  const journalRowsTotal = allRows.length;

  // R67 — drill summary. guardian.py --drill exercises the full bounce
  // machinery against a throwaway victim and journals rows marked
  // drill:true; they are EVIDENCE OF READINESS, not bounces of the real
  // surface, so they are counted separately and the latest is surfaced.
  const drillRows = allRows.filter((r) => r.drill === true);
  const drills: { count: number; landed: number; last: Record<string, unknown> | null } = {
    count: drillRows.length,
    landed: drillRows.filter((r) => r.ok === true).length,
    last: drillRows.length > 0 ? drillRows[drillRows.length - 1] ?? null : null,
  };

  // R90 — LANDING RESILIENCE, computed over EVERY real (non-drill) save on
  // record. The journal is the honest dataset: it knows when each save
  // landed and what the landing cost. Derived, never invented:
  //   span         first→last real save (the journal's own coverage — the
  //                pre-journal history is unknowable and never guessed)
  //   total/mean/
  //   median/long  the downtime distribution — what a controlled landing
  //                actually costs the estate
  //   slowLandings downtime > 45s — R89's #14/#15 class (48.4s/47.0s); the
  //                count that tells the operator whether long landings are
  //                the exception or the new normal
  //   byReason     the R88/R89 calibration question (port-probe vs rss)
  //   witnessRows  rows carrying an R90 crash witness — the forensics
  //                coverage, which grows from R90 onward
  const realRows = allRows.filter((r) => r.drill !== true);
  const downtimes = realRows
    .map((r) => r.downtimeMs)
    .filter((d): d is number => typeof d === 'number' && Number.isFinite(d));
  const sortedDt = [...downtimes].sort((a, b) => a - b);
  const firstRealAt = parseUtc(String(realRows[0]?.at ?? ''));
  const lastRealAt = parseUtc(String(realRows[realRows.length - 1]?.at ?? ''));
  const longestRow = realRows.reduce<Record<string, unknown> | null>((acc, r) => {
    const d = r.downtimeMs;
    if (typeof d !== 'number' || !Number.isFinite(d)) return acc;
    if (acc == null || d > Number(acc.downtimeMs ?? 0)) return r;
    return acc;
  }, null);
  const byReason: Record<string, number> = {};
  for (const r of realRows) {
    const k = String(r.reason ?? 'unknown');
    byReason[k] = (byReason[k] ?? 0) + 1;
  }

  // R92 — THE RELIABILITY LEDGER: the resilience distribution read as TIME
  // BETWEEN failures and availability over the journal's own coverage.
  //   mtbf         mean of the consecutive-save intervals (the journal's
  //                mean time between failures) — null with fewer than two
  //                real saves, because one event has no interval
  //   availability 1 − totalDowntime/span over the SAME span the resilience
  //                block already claims — an availability number that cannot
  //                outlive its own evidence window (never presented as arm
  //                age or as all-time)
  //   longestCalm  the widest gap between consecutive saves (with its from→
  //                to stamps) — the estate's calmest stretch on record
  //   storm        the NARROWEST interval — the fastest double-bounce, the
  //                shape of the worst hour
  //   currentCalm  now − last save, from the SERVER clock — the live streak,
  //                reset by every save and never backfilled
  //   cadence      the recent-3 intervals against the overall mean — the
  //                acceleration question R91 left open ("watch the cadence")
  //   downtimeSeries the per-save downtime tail (≤40) for the UI sparkline
  const realAts = realRows
    .map((r) => parseUtc(String(r.at ?? '')))
    .filter((t) => Number.isFinite(t));
  const intervals: number[] = [];
  for (let i = 1; i < realAts.length; i++) {
    const gap = (realAts[i] as number) - (realAts[i - 1] as number);
    if (Number.isFinite(gap) && gap >= 0) intervals.push(gap);
  }
  const spanMs =
    Number.isFinite(firstRealAt) && Number.isFinite(lastRealAt) && lastRealAt > firstRealAt
      ? lastRealAt - firstRealAt
      : 0;
  const totalDowntime = downtimes.reduce((a, b) => a + b, 0);
  let longestCalmIdx = -1;
  for (let i = 1; i < intervals.length + 1; i++) {
    if (longestCalmIdx < 0 || (intervals[i - 1] as number) > (intervals[longestCalmIdx] as number)) {
      longestCalmIdx = i - 1;
    }
  }
  const meanInterval = intervals.length > 0 ? intervals.reduce((a, b) => a + b, 0) / intervals.length : null;
  const recentMean =
    intervals.length >= 6
      ? intervals.slice(-3).reduce((a, b) => a + b, 0) / 3
      : null;
  const cadence =
    meanInterval != null && recentMean != null
      ? recentMean / meanInterval <= 0.67
        ? ('accelerating' as const)
        : recentMean / meanInterval >= 1.5
          ? ('cooling' as const)
          : ('steady' as const)
      : null;
  const resilience = {
    count: realRows.length,
    spanHours:
      Number.isFinite(firstRealAt) && Number.isFinite(lastRealAt) && lastRealAt > firstRealAt
        ? (lastRealAt - firstRealAt) / 3_600_000
        : null,
    totalDowntimeMs: downtimes.reduce((a, b) => a + b, 0),
    meanMs: downtimes.length > 0 ? Math.round(downtimes.reduce((a, b) => a + b, 0) / downtimes.length) : null,
    medianMs:
      sortedDt.length > 0
        ? sortedDt.length % 2 === 1
          ? sortedDt[Math.floor(sortedDt.length / 2)] ?? null
          : Math.round(((sortedDt[sortedDt.length / 2 - 1] ?? 0) + (sortedDt[sortedDt.length / 2] ?? 0)) / 2)
        : null,
    longestMs: typeof longestRow?.downtimeMs === 'number' ? (longestRow.downtimeMs as number) : null,
    longestAt: typeof longestRow?.at === 'string' ? (longestRow.at as string) : null,
    slowLandings: downtimes.filter((d) => d > 45_000).length,
    byReason,
    witnessRows: realRows.filter((r) => {
      const ev = r.evidence as { lines?: unknown[] } | null | undefined;
      return Array.isArray(ev?.lines) && ev.lines.length > 0;
    }).length,
    // R92 — the reliability ledger (see the block comment above)
    mtbfMin: meanInterval != null ? meanInterval / 60_000 : null,
    availabilityPct:
      spanMs > 0 && downtimes.length > 0
        ? Math.max(0, Math.min(100, 100 * (1 - totalDowntime / spanMs)))
        : null,
    longestCalmMin: longestCalmIdx >= 0 ? (intervals[longestCalmIdx] as number) / 60_000 : null,
    longestCalmFrom:
      longestCalmIdx >= 0 && Number.isFinite(realAts[longestCalmIdx])
        ? new Date(realAts[longestCalmIdx] as number).toISOString()
        : null,
    longestCalmTo:
      longestCalmIdx >= 0 && Number.isFinite(realAts[longestCalmIdx + 1])
        ? new Date(realAts[longestCalmIdx + 1] as number).toISOString()
        : null,
    stormMin: intervals.length > 0 ? Math.min(...intervals) / 60_000 : null,
    currentCalmMin: Number.isFinite(lastRealAt) ? (Date.now() - lastRealAt) / 60_000 : null,
    // R96 — the calm streak's percentile among ALL intervals on record: the
    // share of historical save-gaps strictly shorter than the live calm. A
    // high percentile says "streaks this old usually ended by now" without
    // pretending to predict the next save — one number, the journal's own
    // distribution. Null with fewer than one interval (nothing to compare).
    calmPercentile:
      Number.isFinite(lastRealAt) && intervals.length > 0
        ? Math.round(
            (intervals.filter((i) => i < (Date.now() - lastRealAt)).length / intervals.length) * 100,
          )
        : null,
    cadence,
    // R94 — the interval tail: the cadence verdict's own numbers (≤40
    // consecutive-save intervals, oldest→newest), from the SAME realAts
    // already computed — zero extra I/O. The UI draws the strip; the chip
    // keeps the word; the two can never disagree (one engine).
    intervalSeries: buildIntervalSeries(realAts),
    downtimeSeries: realRows
      .map((r) => ({
        at: String(r.at ?? ''),
        ms: typeof r.downtimeMs === 'number' && Number.isFinite(r.downtimeMs) ? (r.downtimeMs as number) : null,
        reason: String(r.reason ?? 'unknown'),
      }))
      .filter((p): p is { at: string; ms: number; reason: string } => typeof p.ms === 'number')
      .slice(-40),
  };

  // R96 — THE OPERATOR PROJECTION: the calibration menu's standing ask,
  // answered from the journal's own numbers. The witnessed kills (port rows
  // carrying an R94 memWitness) are read against a grid of proposed rails:
  // which level catches which kill, with what margin, and what the day-rates
  // become if those kills were reclassified as controlled landings. The
  // loop-guard references come from the guardian's own live reads (the R69
  // plateau and the status memSeries' observed minimum avail) — a rail that
  // fires on the warm state is marked WOULD LOOP before its catch count is
  // quoted. Computed in the SAME journal read; zero extra I/O.
  const plateauData = computePlateau(status.guardMb ?? null);
  const observedMinAvailKb = (status.memSeries ?? [])
    .map((s) => s?.availKb)
    .filter((v): v is number => typeof v === 'number' && Number.isFinite(v))
    .reduce<number | null>((min, v) => (min == null || v < min ? v : min), null);
  const railProjection = buildRailProjection(allRows as Parameters<typeof buildRailProjection>[0], {
    currentGuardMb: typeof status.guardMb === 'number' ? status.guardMb : null,
    currentFloorMb: typeof status.availFloorMb === 'number' ? status.availFloorMb : null,
    baselineMb: plateauData?.baselineMb ?? null,
    observedMinAvailMb: observedMinAvailKb != null ? Math.round(observedMinAvailKb / 1024) : null,
  });

  return NextResponse.json(
    {
      present: true,
      guardianAlive,
      stale,
      guardian: { ...status, guardianFilePid, guardianAlive },
      bounces,
      journalRowsTotal,
      drills,
      resilience,
      railProjection,
      plateau: plateauData,
    },
    { headers: { 'Cache-Control': 'no-store' } },
  );
}
