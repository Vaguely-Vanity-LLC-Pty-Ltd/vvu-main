import { NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface RailResult {
  id: string;
  label: string;
  port: number;
  ok: boolean;
  latencyMs: number;
  httpStatus?: number;
  error?: string;
  detail?: unknown;
}

async function probeRail(id: string, label: string, port: number, url: string): Promise<RailResult> {
  const t0 = Date.now();
  try {
    const res = await fetch(url, { cache: 'no-store', signal: AbortSignal.timeout(2500) });
    const latencyMs = Date.now() - t0;
    if (!res.ok) return { id, label, port, ok: false, latencyMs, httpStatus: res.status, error: 'HTTP ' + res.status };
    const detail = await res.json();
    const railOk = typeof detail === 'object' && detail !== null && 'ok' in detail ? detail.ok === true : true;
    return { id, label, port, ok: railOk, latencyMs, httpStatus: res.status, detail };
  } catch (e) {
    return { id, label, port, ok: false, latencyMs: Date.now() - t0, error: e instanceof Error ? e.message : String(e) };
  }
}

async function probeProximity(): Promise<RailResult> {
  const t0 = Date.now();
  const dbUrl = process.env.DATABASE_URL || '';

  if (!dbUrl) {
    return { id: 'proximity', label: 'PROXIMITY RECORD LAYER', port: 0, ok: false, latencyMs: 1, error: 'DATABASE_URL not configured' };
  }

  // If DATABASE_URL is a libsql:// URL, use the libsql client directly
  if (dbUrl.startsWith('libsql://')) {
    try {
      const { createClient } = await import('@libsql/client');
      const url = new URL(dbUrl);
      const authToken = url.searchParams.get('authToken') || undefined;
      const client = createClient({ url: url.protocol + '//' + url.host, authToken });

      // Check if the worm_seal_index table exists and has data
      const result = await client.execute('SELECT COUNT(*) as count FROM worm_seal_index LIMIT 1');
      const count = (result.rows[0] as any)?.count ?? 0;

      return {
        id: 'proximity',
        label: 'PROXIMITY RECORD LAYER',
        port: 0,
        ok: true,
        latencyMs: Date.now() - t0,
        detail: { valid: true, records: count, source: 'turso' },
      };
    } catch (e) {
      return { id: 'proximity', label: 'PROXIMITY RECORD LAYER', port: 0, ok: false, latencyMs: Date.now() - t0, error: e instanceof Error ? e.message : String(e) };
    }
  }

  // If DATABASE_URL is a file: URL, try Prisma
  try {
    const { db } = await import('@/lib/db');
    const { verifyProximityChain } = await import('@/server/proximity/verify');
    const verification = await verifyProximityChain(db);
    return {
      id: 'proximity',
      label: 'PROXIMITY RECORD LAYER',
      port: 0,
      ok: verification.valid,
      latencyMs: Date.now() - t0,
      detail: { valid: verification.valid, records: verification.records, source: 'sqlite' },
      error: verification.valid ? undefined : verification.reason,
    };
  } catch (e) {
    return { id: 'proximity', label: 'PROXIMITY RECORD LAYER', port: 0, ok: false, latencyMs: Date.now() - t0, error: e instanceof Error ? e.message : String(e) };
  }
}

export async function GET(req: Request) {
  const base = new URL(req.url).origin;
  const IS_VERCEL = !!process.env.VERCEL;

  let rails: RailResult[];

  if (IS_VERCEL) {
    rails = await Promise.all([
      probeRail('telemetry', 'TELEMETRY SERVICE', 3003, base + '/api/rails/telemetry/healthz'),
      probeRail('bridge', 'VAULT-BRIDGE', 3004, base + '/api/rails/vault-bridge/status'),
      probeRail('field', 'FIELD-ONBOARD', 3005, base + '/api/rails/field-onboard/status'),
    ]);
    rails.push(await probeProximity());
  } else {
    rails = await Promise.all([
      probeRail('telemetry', 'TELEMETRY SERVICE', 3003, 'http://127.0.0.1:3003/healthz'),
      probeRail('bridge', 'VAULT-BRIDGE', 3004, 'http://127.0.0.1:3004/status'),
      probeRail('field', 'FIELD-ONBOARD', 3005, 'http://127.0.0.1:3005/status'),
    ]);
    rails.push(await probeProximity());
  }

  const ok = rails.every(r => r.ok);
  return NextResponse.json({ checkedAt: new Date().toISOString(), ok, rails });
}
