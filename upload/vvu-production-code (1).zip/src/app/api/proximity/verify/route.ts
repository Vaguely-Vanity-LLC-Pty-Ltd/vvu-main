import { NextResponse } from 'next/server';
import { turso, isTurso } from '@/lib/turso';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    if (isTurso) {
      const count = await turso.execute('SELECT COUNT(*) as count FROM WormEvent');
      return NextResponse.json({ valid: true, records: (count.rows[0] as any)?.count ?? 0 });
    } else {
      const { verifyProximityChain } = await import('@/server/proximity/verify');
      const { db } = await import('@/lib/db');
      const verification = await verifyProximityChain(db);
      return NextResponse.json({ valid: verification.valid, records: verification.records });
    }
  } catch (e) {
    return NextResponse.json({ valid: false, error: String(e instanceof Error ? e.message : e) }, { status: 500 });
  }
}
