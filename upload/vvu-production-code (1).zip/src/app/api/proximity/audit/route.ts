import { NextResponse } from 'next/server';
import { turso, isTurso } from '@/lib/turso';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  const url = new URL(req.url);
  const limit = parseInt(url.searchParams.get('limit') || '50');
  try {
    if (isTurso) {
      const rows = await turso.execute({ sql: 'SELECT * FROM AuditLog ORDER BY createdAt DESC LIMIT ?', args: [limit] });
      return NextResponse.json({ audits: rows.rows, total: rows.rows.length });
    } else {
      const { db } = await import('@/lib/db');
      const audits = await db.auditLog.findMany({ take: limit, orderBy: { createdAt: 'desc' } });
      return NextResponse.json({ audits, total: audits.length });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e instanceof Error ? e.message : e) }, { status: 500 });
  }
}
