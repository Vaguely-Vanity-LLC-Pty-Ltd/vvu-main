import { NextResponse } from "next/server";
import { turso, isTurso } from "@/lib/turso";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    if (isTurso) {
      const rows = await turso.execute("SELECT * FROM WormEvent ORDER BY createdAt DESC LIMIT 50");
      return NextResponse.json({ records: rows.rows, count: rows.rows.length });
    } else {
      const records = await db.wormEvent.findMany({ take: 50, orderBy: { createdAt: "desc" } });
      return NextResponse.json({ records, count: records.length });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
