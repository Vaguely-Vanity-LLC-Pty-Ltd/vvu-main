import { NextResponse } from "next/server";
import { turso, isTurso } from "@/lib/turso";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    if (isTurso) {
      const countResult = await turso.execute("SELECT COUNT(*) as count FROM WormEvent");
      const headResult = await turso.execute("SELECT * FROM WormEvent ORDER BY createdAt DESC LIMIT 1");
      return NextResponse.json({
        valid: true,
        records: (countResult.rows[0] as any)?.count ?? 0,
        head: headResult.rows[0] ?? null,
      });
    } else {
      const count = await db.wormEvent.count();
      const head = await db.wormEvent.findFirst({ orderBy: { createdAt: "desc" } });
      return NextResponse.json({ valid: true, records: count, head });
    }
  } catch (e) {
    return NextResponse.json({ valid: false, error: String(e) }, { status: 500 });
  }
}
