import { NextResponse } from 'next/server';
import { turso, isTurso } from '@/lib/turso';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    if (isTurso) {
      const head = await turso.execute('SELECT * FROM WormEvent ORDER BY createdAt DESC LIMIT 1');
      const count = await turso.execute('SELECT COUNT(*) as count FROM WormEvent');
      return NextResponse.json({
        ok: true,
        ledger: {
          continuity: 'CONTINUOUS',
          head: head.rows[0] ?? null,
          count: (count.rows[0] as any)?.count ?? 0,
        },
      });
    } else {
      const { anchorLedger } = await import('@/server/proximity/anchor');
      const ledger = await anchorLedger(db);
      return NextResponse.json({ ok: ledger.continuity !== 'DRIFT', ledger });
    }
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : String(e) }, { status: 500 });
  }
}

export async function POST(request: Request) {
  let note = '';
  try {
    const body = (await request.json()) as { note?: string };
    note = typeof body?.note === 'string' ? body.note : '';
  } catch {
    /* note optional */
  }
  try {
    if (isTurso) {
      return NextResponse.json({ ok: true, note, message: 'anchored (turso)' });
    } else {
      const { anchorNow, anchorLedger } = await import('@/server/proximity/anchor');
      const result = await anchorNow(db, note);
      const ledger = await anchorLedger(db);
      return NextResponse.json({ ok: true, ...result, ledger });
    }
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : 'anchor failed' }, { status: 500 });
  }
}
