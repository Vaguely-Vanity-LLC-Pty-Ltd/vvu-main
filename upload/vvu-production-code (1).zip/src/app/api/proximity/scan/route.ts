import { NextResponse } from 'next/server';
import { turso, isTurso } from '@/lib/turso';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    if (isTurso) {
      const rows = await turso.execute('SELECT * FROM WormEvent ORDER BY createdAt DESC LIMIT 20');
      return NextResponse.json({ scan: rows.rows, count: rows.rows.length });
    } else {
      const { db } = await import('@/lib/db');
      const records = await db.wormEvent.findMany({ take: 20, orderBy: { createdAt: 'desc' } });
      return NextResponse.json({ scan: records, count: records.length });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e instanceof Error ? e.message : e) }, { status: 500 });
  }
}
