import { NextResponse } from 'next/server';
import { turso, isTurso } from '@/lib/turso';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    if (isTurso) {
      const rows = await turso.execute('SELECT * FROM WatchboardSnapshot ORDER BY createdAt DESC LIMIT 1');
      return NextResponse.json({ snapshot: rows.rows[0] ?? null, ok: true, watches: [] });
    } else {
      return NextResponse.json({ snapshot: null, ok: true, watches: [] });
    }
  } catch (e) {
    return NextResponse.json({ ok: false, watches: [], error: String(e instanceof Error ? e.message : e) });
  }
}
