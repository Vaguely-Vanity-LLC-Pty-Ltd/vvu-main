import { NextResponse } from "next/server";
import { turso, isTurso } from "@/lib/turso";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    if (isTurso) {
      const events = await turso.execute("SELECT * FROM AuditLog ORDER BY createdAt DESC LIMIT 50");
      return NextResponse.json({ events: events.rows, total: events.rows.length });
    } else {
      const events = await db.auditLog.findMany({ take: 50, orderBy: { createdAt: "desc" } });
      return NextResponse.json({ events, total: events.length });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
