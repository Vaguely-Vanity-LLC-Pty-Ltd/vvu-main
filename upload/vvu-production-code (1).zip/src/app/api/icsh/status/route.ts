import { NextResponse } from "next/server";
import { turso, isTurso } from "@/lib/turso";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    if (isTurso) {
      const nodes = await turso.execute("SELECT COUNT(*) as count FROM IcshNode");
      const peers = await turso.execute("SELECT COUNT(*) as count FROM IcshPeer");
      const cycles = await turso.execute("SELECT COUNT(*) as count FROM IcshCycle");
      return NextResponse.json({
        ok: true,
        status: "STEADY_STATE_LOCKED",
        nodes: (nodes.rows[0] as any)?.count ?? 0,
        peers: (peers.rows[0] as any)?.count ?? 0,
        cycles: (cycles.rows[0] as any)?.count ?? 0,
      });
    } else {
      const nodes = await db.icshNode.count();
      const peers = await db.icshPeer.count();
      const cycles = await db.icshCycle.count();
      return NextResponse.json({ ok: true, status: "STEADY_STATE_LOCKED", nodes, peers, cycles });
    }
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
