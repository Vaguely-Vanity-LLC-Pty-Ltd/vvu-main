import { NextResponse } from 'next/server';
import { turso, isTurso } from '@/lib/turso';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    if (isTurso) {
      const rows = await turso.execute('SELECT * FROM IcshSession ORDER BY createdAt DESC LIMIT 10');
      return NextResponse.json({ sessions: rows.rows, count: rows.rows.length });
    } else {
      return NextResponse.json({ sessions: [], count: 0 });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e instanceof Error ? e.message : e) }, { status: 500 });
  }
}
