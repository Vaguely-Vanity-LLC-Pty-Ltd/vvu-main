import { NextResponse } from 'next/server';
import { turso, isTurso } from '@/lib/turso';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    if (isTurso) {
      const nodes = await turso.execute('SELECT COUNT(*) as count FROM IcshNode');
      const peers = await turso.execute('SELECT COUNT(*) as count FROM IcshPeer');
      const cycles = await turso.execute('SELECT COUNT(*) as count FROM IcshCycle');
      const sessions = await turso.execute('SELECT COUNT(*) as count FROM IcshSession');
      return NextResponse.json({
        nodes: (nodes.rows[0] as any)?.count ?? 0,
        peers: (peers.rows[0] as any)?.count ?? 0,
        cycles: (cycles.rows[0] as any)?.count ?? 0,
        sessions: (sessions.rows[0] as any)?.count ?? 0,
      });
    } else {
      const { listNodes, listPeers } = await import('@/lib/icsh/engine');
      const nodes = await listNodes();
      const peers = await listPeers();
      return NextResponse.json({ nodes: nodes.length, peers: peers.length });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e instanceof Error ? e.message : e) }, { status: 500 });
  }
}
