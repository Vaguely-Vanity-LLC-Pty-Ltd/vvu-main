import { NextResponse } from 'next/server';
import { turso, isTurso } from '@/lib/turso';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  const url = new URL(req.url);
  const mode = url.searchParams.get('mode') || 'cycles';
  const limit = parseInt(url.searchParams.get('limit') || '50');
  const source = url.searchParams.get('source');

  try {
    if (isTurso) {
      let sql = 'SELECT * FROM IcshCycle';
      const args = [];
      if (source) { sql += ' WHERE source = ?'; args.push(source); }
      sql += ' ORDER BY createdAt DESC LIMIT ?';
      args.push(limit);
      const rows = await turso.execute({ sql, args });
      const countResult = await turso.execute('SELECT COUNT(*) as count FROM IcshCycle');
      return NextResponse.json({ cycles: rows.rows, total: (countResult.rows[0] as any)?.count ?? 0 });
    } else {
      const { listCycles } = await import('@/lib/icsh/engine');
      const cycles = await listCycles({ mode, limit, source });
      return NextResponse.json({ cycles, total: cycles.length });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e instanceof Error ? e.message : e) }, { status: 500 });
  }
}
