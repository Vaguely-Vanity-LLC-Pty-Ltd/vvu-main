import { NextResponse } from 'next/server';
import { turso, isTurso } from '@/lib/turso';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    if (isTurso) {
      const rows = await turso.execute('SELECT * FROM IcshRunStat ORDER BY createdAt DESC LIMIT 20');
      return NextResponse.json({ runs: rows.rows, count: rows.rows.length });
    } else {
      return NextResponse.json({ runs: [], count: 0 });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e instanceof Error ? e.message : e) }, { status: 500 });
  }
}
