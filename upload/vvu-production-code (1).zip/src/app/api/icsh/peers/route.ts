import { NextResponse } from 'next/server';
import { turso, isTurso } from '@/lib/turso';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    if (isTurso) {
      const rows = await turso.execute('SELECT * FROM IcshPeer LIMIT 50');
      return NextResponse.json({ peers: rows.rows, count: rows.rows.length });
    } else {
      const { listPeers } = await import('@/lib/icsh/engine');
      const peers = await listPeers();
      return NextResponse.json({ peers, count: peers.length });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e instanceof Error ? e.message : e) }, { status: 500 });
  }
}
