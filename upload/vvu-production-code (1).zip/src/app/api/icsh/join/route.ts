import { NextResponse } from 'next/server';
import { turso, isTurso } from '@/lib/turso';
import { randomUUID } from 'node:crypto';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const nodeId = body.nodeId || `node-${randomUUID().slice(0, 8)}`;
    
    if (isTurso) {
      await turso.execute({
        sql: 'INSERT INTO IcshNode (id, nodeId, status, createdAt) VALUES (?, ?, ?, ?)',
        args: [randomUUID(), nodeId, 'ACTIVE', new Date().toISOString()]
      });
      return NextResponse.json({ ok: true, nodeId, status: 'ACTIVE' });
    } else {
      return NextResponse.json({ ok: true, nodeId, status: 'ACTIVE' });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e instanceof Error ? e.message : e) }, { status: 500 });
  }
}
