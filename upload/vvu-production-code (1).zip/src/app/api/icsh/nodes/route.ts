import { NextResponse } from 'next/server';
import { turso, isTurso } from '@/lib/turso';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    if (isTurso) {
      const rows = await turso.execute('SELECT * FROM IcshNode LIMIT 50');
      return NextResponse.json({ nodes: rows.rows });
    } else {
      const { listNodes } = await import('@/lib/icsh/engine');
      const nodes = await listNodes();
      return NextResponse.json({ nodes });
    }
  } catch (e) {
    return NextResponse.json({ error: String(e instanceof Error ? e.message : e) }, { status: 500 });
  }
}
