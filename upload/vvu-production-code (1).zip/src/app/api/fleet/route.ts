import { NextResponse } from 'next/server';
import { FLEET_REGISTRY } from '@/server/fleet/registry';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface FleetRow {
  port: number;
  name: string;
  service: string;
  role: string;
  kind: string;
  expectedRootStatus: number;
  httpStatus: number | null;
  latencyMs: number;
  verdict: 'OK' | 'DOWN' | 'ODD';
  error: string | null;
  note: string | null;
}

const RAIL_ROUTES: Record<number, string> = {
  3003: '/api/rails/telemetry/healthz',
  3004: '/api/rails/vault-bridge/status',
  3005: '/api/rails/field-onboard/status',
  3006: '/api/rails/wildfire-mesh/status',
  3007: '/api/rails/mesh-demo/status',
  3008: '/api/rails/safegrid/status',
};

const IS_VERCEL = !!process.env.VERCEL;

async function probeFleetRow(row: (typeof FLEET_REGISTRY)[number], base: string): Promise<FleetRow> {
  const t0 = Date.now();

  // On Vercel, :3000 is the surface itself — if this API is responding, it's UP
  if (IS_VERCEL && row.port === 3000) {
    return { ...row, httpStatus: 200, latencyMs: 1, verdict: 'OK', error: null, note: 'self (serverless)' };
  }

  if (IS_VERCEL && row.port !== 3000) {
    const route = RAIL_ROUTES[row.port];
    if (!route) {
      return { ...row, httpStatus: null, latencyMs: Date.now() - t0, verdict: 'DOWN', error: 'no serverless route mapped', note: null };
    }
    try {
      const res = await fetch(base + route, {
        cache: 'no-store',
        signal: AbortSignal.timeout(2500),
        redirect: 'manual',
      });
      const latencyMs = Date.now() - t0;
      const verdict: FleetRow['verdict'] = res.ok ? 'OK' : 'ODD';
      return { ...row, httpStatus: res.status, latencyMs, verdict, error: null, note: 'serverless' };
    } catch (e) {
      return { ...row, httpStatus: null, latencyMs: Date.now() - t0, verdict: 'DOWN', error: e instanceof Error ? e.message : String(e), note: null };
    }
  }

  // On VPS/Railway: probe localhost ports
  try {
    const res = await fetch('http://127.0.0.1:' + row.port + '/', {
      cache: 'no-store',
      signal: AbortSignal.timeout(1500),
      redirect: 'manual',
    });
    const latencyMs = Date.now() - t0;
    const verdict: FleetRow['verdict'] = res.status === row.expectedRootStatus ? 'OK' : 'ODD';
    return { ...row, httpStatus: res.status, latencyMs, verdict, error: null, note: null };
  } catch (e) {
    const latencyMs = Date.now() - t0;
    return { ...row, httpStatus: null, latencyMs, verdict: 'DOWN', error: e instanceof Error ? e.message : String(e), note: null };
  }
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const base = url.origin;
  const rows = await Promise.all(FLEET_REGISTRY.map(r => probeFleetRow(r, base)));
  const summary = {
    total: rows.length,
    ok: rows.filter(r => r.verdict === 'OK').length,
    odd: rows.filter(r => r.verdict === 'ODD').length,
    down: rows.filter(r => r.verdict === 'DOWN').length,
  };

  return NextResponse.json({
    probedAtUtc: new Date().toISOString(),
    summary,
    rows,
  });
}
