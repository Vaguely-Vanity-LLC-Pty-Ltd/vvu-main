use proofbridge_kernel::zk::{Proof, StubVerifier, VerificationKey, ZkVerifier};

#[test]
fn stub_verifier_refuses() {
    let v = StubVerifier;
    let vk = VerificationKey { bytes: vec![] };
    let p  = Proof { bytes: vec![] };
    assert!(v.verify(&vk, &p, &[]).is_err());
}
