use ed25519_dalek::SigningKey;
use proofbridge_kernel::{
    kernel::Kernel,
    ledger::InMemoryCommitment,
    receipt::Receipt,
};
use rand_core::OsRng;

fn sample() -> Receipt {
    Receipt {
        version: 1,
        amount_minor: 500_00,
        currency: "ZAR".into(),
        recipient: "Stokvel-Example".into(),
        issued_at: "2026-09-29T12:00:00Z".into(),
        transaction_id: "txn-0001".into(),
    }
}

fn kernel() -> Kernel {
    let sk = SigningKey::generate(&mut OsRng);
    Kernel::new(sk, Box::new(InMemoryCommitment([0u8; 32])))
}

#[test]
fn issue_then_verify() {
    let mut k = kernel();
    let s = k.issue(&sample()).unwrap();
    assert!(k.verify(&s).is_ok());
}

#[test]
fn mmr_grows_on_issue() {
    let mut k = kernel();
    assert_eq!(k.mmr_len(), 0);
    k.issue(&sample()).unwrap();
    assert_eq!(k.mmr_len(), 1);
}

#[test]
fn sealed_kernel_refuses_issue() {
    let mut k = kernel();
    k.seal();
    assert!(k.issue(&sample()).is_err());
}

#[test]
fn unseal_restores_issuance() {
    let mut k = kernel();
    k.seal();
    k.unseal();
    assert!(k.issue(&sample()).is_ok());
}

#[test]
fn non_zar_currency_refused() {
    let mut k = kernel();
    let mut r = sample();
    r.currency = "USD".into();
    assert!(k.issue(&r).is_err());
}

#[test]
fn wrong_version_refused() {
    let mut k = kernel();
    let mut r = sample();
    r.version = 2;
    assert!(k.issue(&r).is_err());
}
