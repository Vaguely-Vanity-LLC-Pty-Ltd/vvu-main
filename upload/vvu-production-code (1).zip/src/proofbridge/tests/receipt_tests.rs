use ed25519_dalek::SigningKey;
use proofbridge_kernel::receipt::Receipt;
use rand_core::OsRng;

fn sample() -> Receipt {
    Receipt {
        version: 1,
        amount_minor: 1234,
        currency: "ZAR".into(),
        recipient: "Stokvel-A".into(),
        issued_at: "2026-09-29T12:00:00Z".into(),
        transaction_id: "txn-A".into(),
    }
}

#[test]
fn sign_then_verify_roundtrip() {
    let sk = SigningKey::generate(&mut OsRng);
    let r = sample();
    let s = r.sign(&sk);
    assert!(r.verify(&s).is_ok());
}

#[test]
fn tampered_amount_fails() {
    let sk = SigningKey::generate(&mut OsRng);
    let r = sample();
    let mut s = r.sign(&sk);
    s.receipt.amount_minor += 1;
    assert!(r.verify(&s).is_err());
}

#[test]
fn tampered_recipient_fails() {
    let sk = SigningKey::generate(&mut OsRng);
    let r = sample();
    let mut s = r.sign(&sk);
    s.receipt.recipient = "Attacker".into();
    assert!(r.verify(&s).is_err());
}
