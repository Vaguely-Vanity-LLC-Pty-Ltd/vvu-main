use proofbridge_kernel::mmr::Mmr;

#[test]
fn root_changes_on_append() {
    let mut m = Mmr::new();
    let r0 = m.root();
    m.append([1u8; 32]);
    let r1 = m.root();
    assert_ne!(r0, r1);
}

#[test]
fn append_only_property_holds() {
    let mut m = Mmr::new();
    m.append([1u8; 32]);
    m.append([2u8; 32]);
    let snapshot = vec![[1u8; 32], [2u8; 32]];
    assert!(m.verify_append_only(&snapshot).is_ok());
}

#[test]
fn tampered_leaf_is_caught() {
    let mut m = Mmr::new();
    m.append([1u8; 32]);
    m.append([2u8; 32]);
    let tampered = vec![[1u8; 32], [9u8; 32]];
    assert!(m.verify_append_only(&tampered).is_err());
}

#[test]
fn truncated_snapshot_is_caught() {
    let mut m = Mmr::new();
    m.append([1u8; 32]);
    m.append([2u8; 32]);
    let short = vec![[1u8; 32]];
    assert!(m.verify_append_only(&short).is_ok()); // shorter than high-water is fine
    // but a longer snapshot is refused
    let long = vec![[1u8; 32], [2u8; 32], [3u8; 32]];
    assert!(m.verify_append_only(&long).is_err());
}
