//! Ledger consistency: the MMR root MUST match the on-chain commitment on
//! startup and at configurable intervals.
//! VRES Vol XIX §21.4 (c).

use crate::errors::PbError;
use crate::mmr::Mmr;

pub trait OnChainCommitment {
    fn current_root(&self) -> [u8; 32];
}

pub struct InMemoryCommitment(pub [u8; 32]);

impl OnChainCommitment for InMemoryCommitment {
    fn current_root(&self) -> [u8; 32] { self.0 }
}

pub fn verify_consistency(mmr: &Mmr, chain: &dyn OnChainCommitment) -> Result<(), PbError> {
    let local = mmr.root();
    let remote = chain.current_root();
    if local != remote {
        return Err(PbError::MmrRootMismatch {
            expected: hex::encode(remote),
            actual:   hex::encode(local),
        });
    }
    Ok(())
}
