//! Ed25519-signed receipts.
//! VRES Vol XIX §21.4: "every receipt MUST be Ed25519-signed and anchored in the MMR".

use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use serde::{Deserialize, Serialize};

use crate::errors::PbError;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Receipt {
    pub version: u8,                 // must be 1
    pub amount_minor: u64,           // in cents, to avoid float
    pub currency: String,            // "ZAR"
    pub recipient: String,
    pub issued_at: String,           // ISO-8601 UTC
    pub transaction_id: String,
}

impl Receipt {
    /// Canonical bytes for signing: serde_json with sorted keys and no whitespace.
    /// Determinism is enforced by the shape of this struct and by serialising
    /// via `serde_json::to_vec` (which preserves struct field order).
    pub fn canonical_bytes(&self) -> Vec<u8> {
        serde_json::to_vec(self).expect("receipt is serialisable")
    }

    pub fn sign(&self, sk: &SigningKey) -> SignedReceipt {
        let sig: Signature = sk.sign(&self.canonical_bytes());
        SignedReceipt {
            receipt: self.clone(),
            signature: hex::encode(sig.to_bytes()),
            public_key: hex::encode(sk.verifying_key().to_bytes()),
        }
    }

    pub fn verify(&self, signed: &SignedReceipt) -> Result<(), PbError> {
        let vk = VerifyingKey::from_bytes(
            &hex::decode(&signed.public_key)
                .map_err(|e| PbError::SignatureInvalid(format!("pubkey hex: {e}")))?
                .try_into()
                .map_err(|_| PbError::SignatureInvalid("pubkey length".into()))?,
        )
        .map_err(|e| PbError::SignatureInvalid(format!("pubkey: {e}")))?;

        let sig_bytes: [u8; 64] = hex::decode(&signed.signature)
            .map_err(|e| PbError::SignatureInvalid(format!("sig hex: {e}")))?
            .try_into()
            .map_err(|_| PbError::SignatureInvalid("sig length".into()))?;
        let sig = Signature::from_bytes(&sig_bytes);

        vk.verify(&self.canonical_bytes(), &sig)
            .map_err(|e| PbError::SignatureInvalid(e.to_string()))
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SignedReceipt {
    pub receipt: Receipt,
    pub signature: String,     // hex
    pub public_key: String,    // hex
}
