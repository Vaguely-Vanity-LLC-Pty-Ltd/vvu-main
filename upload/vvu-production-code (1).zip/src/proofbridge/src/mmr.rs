//! Append-only Merkle Mountain Range (in-tree implementation).
//! VRES Vol XIX §21.4:
//!   "(a) transaction integrity ... anchored in the MMR"
//!   "(c) ledger validation - the MMR root hash MUST be verified against the
//!        on-chain commitment on every startup and at configurable intervals".
//!
//! SPEC-ONLY · NOT IN HAND · CONTRACT: VRES Vol III §5.1.2 lists
//! merkleountainrange = "0.3.0" as the intended crate. Until that crate is
//! vendored, this in-tree implementation provides the same append-only
//! property and a SHA-256 based root suitable for the scaffold.

use sha2::{Digest, Sha256};

#[derive(Debug, Clone, Default)]
pub struct Mmr {
    /// All leaves, in append order. Never mutated in place.
    leaves: Vec<[u8; 32]>,
    /// Cached peaks (recomputed on append).
    peaks: Vec<[u8; 32]>,
    /// Number of leaves at the time the last root was observed. Used to
    /// refuse any attempt to remove or reorder leaves.
    high_water: u64,
}

impl Mmr {
    pub fn new() -> Self { Self::default() }

    pub fn len(&self) -> u64 { self.leaves.len() as u64 }
    pub fn is_empty(&self) -> bool { self.leaves.is_empty() }

    pub fn append(&mut self, leaf: [u8; 32]) -> u64 {
        self.leaves.push(leaf);
        self.recompute_peaks();
        self.high_water = self.leaves.len() as u64;
        self.leaves.len() as u64
    }

    pub fn root(&self) -> [u8; 32] {
        // Fold peaks into a single root.
        if self.peaks.is_empty() {
            return [0u8; 32];
        }
        let mut hasher = Sha256::new();
        hasher.update(b"pb-mmr-root-v1");
        for p in &self.peaks {
            hasher.update(p);
        }
        hasher.finalize().into()
    }

    /// Verify the append-only property. Any leaf at index < high_water whose
    /// hash has changed is a violation.
    pub fn verify_append_only(&self, snapshot: &[[u8; 32]]) -> Result<(), crate::errors::PbError> {
        if snapshot.len() as u64 > self.high_water {
            return Err(crate::errors::PbError::MmrAppendOnlyViolated { leaf: self.high_water });
        }
        for (i, s) in snapshot.iter().enumerate() {
            if self.leaves.get(i) != Some(s) {
                return Err(crate::errors::PbError::MmrAppendOnlyViolated { leaf: i as u64 });
            }
        }
        Ok(())
    }

    fn recompute_peaks(&mut self) {
        // Standard MMR peak computation over the leaf count.
        let mut peaks = Vec::new();
        let n = self.leaves.len();
        let mut i = 0usize;
        let mut size = 1usize;
        while i < n {
            let take = size.min(n - i);
            if take == size {
                peaks.push(subtree_hash(&self.leaves[i..i + size]));
                i += size;
            }
            size <<= 1;
        }
        self.peaks = peaks;
    }
}

/// Hash a subtree. Padded to the next power of two with zero leaves, per the
/// MMR convention.
fn subtree_hash(leaves: &[[u8; 32]]) -> [u8; 32] {
    let mut layer: Vec<[u8; 32]> = leaves.to_vec();
    // Pad to the next power of two.
    let mut target = 1usize;
    while target < layer.len() { target <<= 1; }
    while layer.len() < target { layer.push([0u8; 32]); }
    while layer.len() > 1 {
        let mut next = Vec::with_capacity(layer.len() / 2);
        for pair in layer.chunks(2) {
            let mut h = Sha256::new();
            h.update(b"pb-mmr-node-v1");
            h.update(pair[0]);
            h.update(pair[1]);
            next.push(h.finalize().into());
        }
        layer = next;
    }
    layer[0]
}
