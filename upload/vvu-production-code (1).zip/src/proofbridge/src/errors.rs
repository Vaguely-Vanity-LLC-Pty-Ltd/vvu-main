use thiserror::Error;

#[derive(Debug, Error)]
pub enum PbError {
    #[error("receipt signature invalid: {0}")]
    SignatureInvalid(String),

    #[error("receipt content does not match claimed transaction: {field}")]
    ContentMismatch { field: String },

    #[error("MMR append-only property violated at leaf {leaf}")]
    MmrAppendOnlyViolated { leaf: u64 },

    #[error("MMR root mismatch: expected {expected}, got {actual}")]
    MmrRootMismatch { expected: String, actual: String },

    #[error("ZK-proof failed verification against the circuit verification key")]
    ZkProofInvalid,

    #[error("kernel refused: {0}")]
    KernelRefused(String),

    #[error("safety kernel is not the only entry point; {0}")]
    BypassAttempted(String),

    #[error("MISSING - REQUIRES DECISION: {0}")]
    MissingRequiresDecision(String),
}
