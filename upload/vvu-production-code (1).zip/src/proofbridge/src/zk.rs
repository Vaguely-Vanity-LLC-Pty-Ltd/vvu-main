//! ZK-proof correctness.
//! VRES Vol XIX §21.4: "generated ZK proofs MUST verify against the circuit
//! verification key".
//!
//! SPEC-ONLY · NOT IN HAND · CONTRACT: the Groth16 / BN254 circuit and its
//! verification key are not in hand. This module defines the interface; the
//! real circuit drops in when the proving system is chosen.

use crate::errors::PbError;

#[derive(Debug, Clone)]
pub struct VerificationKey {
    /// Serialized VK; opaque to this scaffold.
    pub bytes: Vec<u8>,
}

#[derive(Debug, Clone)]
pub struct Proof {
    pub bytes: Vec<u8>,
}

pub trait ZkVerifier {
    fn verify(&self, vk: &VerificationKey, proof: &Proof, public_inputs: &[u8]) -> Result<(), PbError>;
}

/// Placeholder verifier that refuses until a real circuit is wired.
pub struct StubVerifier;

impl ZkVerifier for StubVerifier {
    fn verify(&self, _vk: &VerificationKey, _proof: &Proof, _pi: &[u8]) -> Result<(), PbError> {
        Err(PbError::MissingRequiresDecision(
            "ZK circuit + verification key not in hand; StubVerifier refuses".into()
        ))
    }
}
