use ed25519_dalek::SigningKey;
use proofbridge_kernel::{
    kernel::Kernel,
    ledger::InMemoryCommitment,
    receipt::Receipt,
};
use rand_core::OsRng;
use serde_json::json;

fn main() {
    let sk = SigningKey::generate(&mut OsRng);

    // Chain commitment: initially zero, updated after each append.
    let mut chain_root = [0u8; 32];
    let chain = InMemoryCommitment(chain_root);

    let mut kernel = Kernel::new(sk, Box::new(chain));

    // Build a receipt with ZAR-only invariant.
    let receipt = Receipt {
        version: 1,
        amount_minor: 500_00, // R500.00
        currency: "ZAR".into(),
        recipient: "Stokvel-Example".into(),
        issued_at: "2026-09-29T12:00:00Z".into(),
        transaction_id: "txn-0001".into(),
    };

    let mut report = json!({
        "product": "proofbridge-kernel",
        "version": "0.0.0",
        "provenance": "SPEC-ONLY · NOT IN HAND"
    });

    // --- Issue ---
    match kernel.issue(&receipt) {
        Ok(signed) => {
            report["issue"] = json!({
                "result": "PASS",
                "signature_len": signed.signature.len() / 2,
                "public_key_len": signed.public_key.len() / 2,
                "provenance": "MEASURED"
            });

            // --- Verify ---
            report["verify"] = match kernel.verify(&signed) {
                Ok(_)  => json!({"result": "PASS", "provenance": "MEASURED"}),
                Err(e) => json!({"result": "FAIL", "error": e.to_string()}),
            };
        }
        Err(e) => {
            report["issue"] = json!({"result": "FAIL", "error": e.to_string()});
        }
    }

    // --- MMR state ---
    report["mmr"] = json!({
        "len": kernel.mmr_len(),
        "root": hex::encode(kernel.mmr_root()),
        "provenance": "MEASURED"
    });

    // --- Fail-closed behaviour ---
    kernel.seal();
    report["sealed"] = match kernel.issue(&receipt) {
        Ok(_)  => json!({"result": "UNEXPECTED_PASS"}),
        Err(e) => json!({"result": "REFUSED_AS_EXPECTED", "error": e.to_string(), "provenance": "MEASURED"}),
    };
    kernel.unseal();

    // --- ZK: refused until circuit is in hand ---
    report["zk"] = json!({
        "result": "REFUSED",
        "reason": "MISSING - REQUIRES DECISION",
        "note": "Groth16 / BN254 circuit + VK not in hand"
    });

    println!("{}", serde_json::to_string_pretty(&report).unwrap());
}
