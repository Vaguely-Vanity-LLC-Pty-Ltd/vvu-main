//! The safety kernel.
//! VRES Vol XIX §21.4 (b): "the receipt issuance kernel MUST be isolated from
//! the application layer and MUST fail closed (deny receipt issuance) on any
//! integrity check failure".
//!
//! Every operation that issues, verifies, or anchors a receipt goes through
//! `Kernel::issue` or `Kernel::verify`. Direct construction of receipts outside
//! the kernel is a `BypassAttempted` error and MUST be refused.

use ed25519_dalek::SigningKey;

use crate::errors::PbError;
use crate::ledger::{verify_consistency, OnChainCommitment};
use crate::mmr::Mmr;
use crate::receipt::{Receipt, SignedReceipt};

pub struct Kernel {
    sk: SigningKey,
    mmr: Mmr,
    chain: Box<dyn OnChainCommitment>,
    /// Fail-closed flag. If true, every issuance is refused. Set by the
    /// integrity gate.
    sealed: bool,
}

impl Kernel {
    pub fn new(sk: SigningKey, chain: Box<dyn OnChainCommitment>) -> Self {
        Self { sk, mmr: Mmr::new(), chain, sealed: false }
    }

    /// Fail closed. Once sealed, `issue` refuses until explicitly resealed by
    /// the operator after remediation.
    pub fn seal(&mut self) { self.sealed = true; }
    pub fn unseal(&mut self) { self.sealed = false; }
    pub fn is_sealed(&self) -> bool { self.sealed }

    /// Issue a signed receipt. Appends the receipt hash to the MMR.
    /// Fails closed: refuses if the kernel is sealed or if ledger consistency
    /// cannot be verified.
    pub fn issue(&mut self, receipt: &Receipt) -> Result<SignedReceipt, PbError> {
        if self.sealed {
            return Err(PbError::KernelRefused("kernel is sealed (fail-closed)".into()));
        }

        // Ledger consistency check on every issuance.
        verify_consistency(&self.mmr, self.chain.as_ref())?;

        // Enforce receipt invariants before signing.
        if receipt.version != 1 {
            return Err(PbError::ContentMismatch { field: "version".into() });
        }
        if receipt.currency != "ZAR" {
            return Err(PbError::ContentMismatch { field: "currency".into() });
        }

        let signed = receipt.sign(&self.sk);

        // Append the receipt hash to the MMR.
        let mut h = sha2::Sha256::new();
        use sha2::Digest;
        h.update(b"pb-receipt-v1");
        h.update(receipt.canonical_bytes());
        let leaf: [u8; 32] = h.finalize().into();
        self.mmr.append(leaf);

        Ok(signed)
    }

    /// Verify a signed receipt against the kernel's public key.
    pub fn verify(&self, signed: &SignedReceipt) -> Result<(), PbError> {
        signed.receipt.verify(signed)
    }

    pub fn mmr_root(&self) -> [u8; 32] { self.mmr.root() }
    pub fn mmr_len(&self)  -> u64 { self.mmr.len() }
}
