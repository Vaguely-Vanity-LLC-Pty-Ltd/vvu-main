# ProofBridge — Safety Kernel

Rust. Ed25519 receipts anchored in an append-only Merkle Mountain Range.

## What is implemented

- Ed25519 signing and verification of receipts (ed25519-dalek 2.1.1)
- Canonical receipt encoding
- In-tree append-only MMR with SHA-256 subtrees
- Append-only property verifier
- Fail-closed safety kernel: `seal()` refuses every issuance until `unseal()`
- ZAR-only invariant
- Ledger consistency check on every issuance

## What is NOT implemented (SPEC-ONLY · NOT IN HAND)

- The third-party `merkleountainrange = "0.3.0"` crate (in-tree MMR used instead)
- The Groth16 / BN254 ZK circuit and verification key
  (`zk::StubVerifier` refuses every proof until the circuit is wired)
- On-chain commitment client (in-memory commitment used for the scaffold)
- The full 72-test suite referenced by the estate report
  (this scaffold ships 22 tests; the remaining 50 are SPEC-ONLY)

## Build

    cargo build --release
    cargo test
    cargo clippy --all-targets -- -D warnings
    cargo fmt --check
    cargo run --release    # prints a health JSON

## Safety properties

1. **Fail-closed.** `Kernel::seal()` makes every subsequent `issue()` refuse.
2. **Append-only.** Leaves can be added, never removed or reordered.
   `verify_append_only` names the exact leaf that was tampered with.
3. **ZAR-only.** Non-ZAR receipts are refused at the kernel.
4. **Isolation.** All issuance goes through the kernel; the crate exposes no
   public constructor for `SignedReceipt`.
5. **Consistency.** Every issuance re-verifies the MMR root against the
   on-chain commitment.
