import { createClient, type Client } from "@libsql/client"

const globalForTurso = globalThis as unknown as { turso: Client | undefined }

function getTursoClient(): Client {
  const url = process.env.DATABASE_URL || ""
  if (url.startsWith("libsql://")) {
    const parsed = new URL(url)
    const authToken = parsed.searchParams.get("authToken") || undefined
    return createClient({ url: parsed.protocol + "//" + parsed.host, authToken })
  }
  // Fallback to local SQLite file
  return createClient({ url: url.startsWith("file:") ? url : "file:./db/custom.db" })
}

export const turso: Client = globalForTurso.turso ?? getTursoClient()
if (process.env.NODE_ENV !== "production") globalForTurso.turso = turso

/** Execute a SQL query and return rows as plain objects. */
export async function query(sql: string, args: Record<string, unknown> = {}) {
  const result = await turso.execute({ sql, args: args as any })
  return result.rows
}

/** Execute a SQL statement (INSERT/UPDATE/DELETE) and return metadata. */
export async function execute(sql: string, args: Record<string, unknown> = {}) {
  return turso.execute({ sql, args: args as any })
}

/** Check if we are connected to Turso (libsql://) or local SQLite. */
export const isTurso = (process.env.DATABASE_URL || "").startsWith("libsql://")
