/**
 * VVU · STUDIO — virtual file system (the explorer tree + file metadata).
 */
import type { ViewKey } from "./types";

export interface FsNode {
  name: string;
  /** folder children, if any */
  children?: FsNode[];
  /** file view key, if a file */
  view?: ViewKey;
  open?: boolean;
  ext?: "md" | "py" | "json";
}

export const FILE_SYSTEM: FsNode = {
  name: "VVU-STUDIO",
  open: true,
  children: [
    {
      name: "the loop",
      open: true,
      children: [
        { name: "stakeholder.md", view: "stakeholder", ext: "md" },
        { name: "loop.py", view: "loop", ext: "py" },
        { name: "rules.py", view: "rules", ext: "py" },
        { name: "receipts.json", view: "receipts", ext: "json" },
        { name: "items.py", view: "items", ext: "py" },
        { name: "commit.py", view: "commit", ext: "py" },
        { name: "verify.py", view: "verify", ext: "py" },
        { name: "board.py", view: "board", ext: "py" },
        { name: "tree.py", view: "tree", ext: "py" },
        { name: "stats.py", view: "stats", ext: "py" },
      ],
    },
    {
      name: ".vvu",
      open: false,
      children: [
        { name: "doctrine.md", view: "doctrine", ext: "md" },
        { name: "gates.py", view: "gates", ext: "py" },
        { name: "config.json", view: "config", ext: "json" },
      ],
    },
    {
      name: "lessons",
      open: false,
      children: [
        { name: "00-numbers-are-places.md", view: "lesson0", ext: "md" },
        { name: "01-eis-evidence.md", view: "lesson1", ext: "md" },
        { name: "02-credential-engine.md", view: "lesson2", ext: "md" },
        { name: "03-depot-protocol.md", view: "lesson3", ext: "md" },
      ],
    },
    {
      name: "labs",
      open: false,
      children: [
        { name: "lab0_plane.py", view: "lab0", ext: "py" },
        { name: "lab1_lucky.py", view: "lab1", ext: "py" },
        { name: "lab2_credential.py", view: "lab2", ext: "py" },
      ],
    },
    {
      name: "ive",
      open: false,
      children: [
        { name: "pipeline.py", view: "ive", ext: "py" },
        { name: "hash_builder.py", view: "hash", ext: "py" },
      ],
    },
    {
      name: "depot",
      open: false,
      children: [{ name: "gate_eval.py", view: "depot", ext: "py" }],
    },
    {
      name: "receipts",
      open: false,
      children: [{ name: "ledger.json", view: "ledger", ext: "json" }],
    },
    { name: "README.md", view: "readme", ext: "md" },
  ],
};

export interface TabMeta {
  label: string;
  ext: "md" | "py" | "json";
}

export const TAB_META: Record<ViewKey, TabMeta> = {
  loop: { label: "loop.py", ext: "py" },
  rules: { label: "rules.py", ext: "py" },
  receipts: { label: "receipts.json", ext: "json" },
  items: { label: "items.py", ext: "py" },
  commit: { label: "commit.py", ext: "py" },
  verify: { label: "verify.py", ext: "py" },
  board: { label: "board.py", ext: "py" },
  tree: { label: "tree.py", ext: "py" },
  stats: { label: "stats.py", ext: "py" },
  stakeholder: { label: "stakeholder.md", ext: "md" },
  readme: { label: "README.md", ext: "md" },
  doctrine: { label: "doctrine.md", ext: "md" },
  gates: { label: "gates.py", ext: "py" },
  config: { label: "config.json", ext: "json" },
  lesson0: { label: "00-numbers-are-places.md", ext: "md" },
  lesson1: { label: "01-eis-evidence.md", ext: "md" },
  lesson2: { label: "02-credential-engine.md", ext: "md" },
  lesson3: { label: "03-depot-protocol.md", ext: "md" },
  lab0: { label: "lab0_plane.py", ext: "py" },
  lab1: { label: "lab1_lucky.py", ext: "py" },
  lab2: { label: "lab2_credential.py", ext: "py" },
  ive: { label: "pipeline.py", ext: "py" },
  hash: { label: "hash_builder.py", ext: "py" },
  depot: { label: "gate_eval.py", ext: "py" },
  ledger: { label: "ledger.json", ext: "json" },
};

/** Mobile tab label: strip leading `NN-` and extension. */
export function mobileLabel(view: ViewKey): string {
  return TAB_META[view].label.replace(/^\d+-/, "").replace(/\.(md|py|json)$/, "");
}

/** Breadcrumb group for a view key. */
export function groupOf(view: ViewKey): string {
  if (view.startsWith("lesson")) return "lessons";
  if (view.startsWith("lab")) return "labs";
  if (view === "ledger") return "receipts";
  if (view === "doctrine" || view === "gates" || view === "config") return ".vvu";
  if (view === "depot") return "depot";
  if (view === "ive" || view === "hash") return "ive";
  return "VVU-STUDIO";
}

/** All file nodes flattened (for terminal `ls` / `open` resolution). */
export function allFiles(): { name: string; view: ViewKey }[] {
  const out: { name: string; view: ViewKey }[] = [];
  const walk = (n: FsNode) => {
    if (n.children) n.children.forEach(walk);
    else if (n.view) out.push({ name: n.name, view: n.view });
  };
  walk(FILE_SYSTEM);
  return out;
}

/** Resolve a loose terminal arg to a view key. */
export function resolveView(arg: string): ViewKey | null {
  if (!arg) return null;
  const raw = arg.trim();
  const lo = raw.toLowerCase();
  if (lo in TAB_META) return lo as ViewKey;
  for (const [k, meta] of Object.entries(TAB_META)) {
    if (meta.label.toLowerCase() === lo) return k as ViewKey;
  }
  const stripped = lo.replace(/^(vvu-studio\/)?/, "").replace(/\.(md|py|json)$/, "");
  if (stripped in TAB_META) return stripped as ViewKey;
  for (const [k, meta] of Object.entries(TAB_META)) {
    const ml = meta.label.toLowerCase().replace(/^\d+-/, "").replace(/\.(md|py|json)$/, "");
    if (ml === stripped || ml.startsWith(stripped) || stripped.startsWith(ml)) return k as ViewKey;
  }
  return null;
}
