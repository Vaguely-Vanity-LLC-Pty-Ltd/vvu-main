/**
 * VVU · STUDIO — type system.
 * Client-side only. The browser is the validator.
 */

export type ViewKey =
  | "loop"
  | "rules"
  | "receipts"
  | "items"
  | "commit"
  | "verify"
  | "board"
  | "tree"
  | "stats"
  | "stakeholder"
  | "readme"
  | "doctrine"
  | "gates"
  | "config"
  | "lesson0"
  | "lesson1"
  | "lesson2"
  | "lesson3"
  | "lab0"
  | "lab1"
  | "lab2"
  | "ive"
  | "hash"
  | "depot"
  | "ledger";

export type DrawerName = "explorer" | "agent" | "terminal" | "watch";

export type TermKind = "" | "in" | "err" | "ok" | "warn" | "dim";

export interface TermLine {
  t: TermKind;
  v: string;
}

export interface ChatMsg {
  role: "user" | "agent";
  text: string;
  meta: string;
}

export interface Lab0State {
  x: number;
  y: number;
}

export interface Lab1Result {
  numbers: number[];
  seedUsed: string | null;
  error?: string;
}

export interface Lab1State {
  name: string;
  count: number;
  start: number;
  end: number;
  seed: string | null;
  last: Lab1Result | null;
}

export interface IveRunContext {
  conf: number;
  bounds: number;
  author: string;
  diffEdits: number;
  deliberation: number;
  presence: boolean;
}

export interface IveState {
  lastRun: IveRunContext | null;
  lastPayload: Record<string, string | number> | null;
}

export type GateStatus = "PASS" | "FAIL" | "CANNOT_COMPUTE";

export interface GateResult {
  id: string;
  name: string;
  status: GateStatus;
  detail: string;
  stub: boolean;
  w: number;
}

export interface LedgerEntry {
  seq: number;
  ts: string;
  payload: Record<string, string | number>;
  canonical: string;
  contentHash: string;
  compoundHash: string;
  prevHash: string;
  receiptHash: string;
  sig: string;
  sigStub: true;
  gatesPass: number;
  gatesTotal: number;
  gatesStub: number;
  gates: { id: string; name: string; status: GateStatus }[];
  conf: number;
  bounds: number;
}

export interface ToastState {
  msg: string;
  kind: "" | "ok" | "err";
  id: number;
}

export interface StudioState {
  openTabs: ViewKey[];
  activeTab: ViewKey | null;
  ledger: LedgerEntry[];
  receipts: number;
  chat: ChatMsg[];
  term: TermLine[];
  lab1: Lab1State;
  lab0: Lab0State;
  ive: IveState;
  watchCollapsed: boolean;
  drawer: DrawerName | null;
  toast: ToastState | null;
  /** transient pipeline run UI flag (which stage is animating) */
  iveRunning: boolean;
}

/** The 11 canonical EIS fields, in order. */
export const CANON_FIELDS = [
  "sensor_id",
  "firmware",
  "calib_epoch",
  "utc_ts",
  "geo",
  "proc_type",
  "evidence_status",
  "channel",
  "merchantId",
  "hour",
  "gapDraw",
] as const;

export type CanonField = (typeof CANON_FIELDS)[number];
