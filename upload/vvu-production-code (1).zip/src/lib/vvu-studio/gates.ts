/**
 * VVU · STUDIO — the 13 gates (L1–L13).
 * 11 are computed (PASS/FAIL by `computeGates`); 2 are honestly stubbed
 * (L7 video_checkpoint, L13 ed25519_verify) and always return CANNOT_COMPUTE.
 * A stubbed gate never blocks a commit — only a FAIL does.
 */
import type { GateResult, GateStatus, IveRunContext, LedgerEntry } from "./types";
import { CANON_FIELDS } from "./types";

export interface GateDef {
  id: string;
  name: string;
  w: number;
  stub: boolean;
}

export const GATES: GateDef[] = [
  { id: "L1", name: "schema_11_field", w: 1, stub: false },
  { id: "L2", name: "author_check", w: 3, stub: false },
  { id: "L3", name: "calibration_window", w: 8, stub: false },
  { id: "L4", name: "confidence_bounds", w: 3, stub: false },
  { id: "L5", name: "presence_proof", w: 3, stub: false },
  { id: "L6", name: "diff_not_queue", w: 8, stub: false },
  { id: "L7", name: "video_checkpoint", w: 8, stub: true },
  { id: "L8", name: "deliberation_15m", w: 3, stub: false },
  { id: "L9", name: "duplicate_hash", w: 1, stub: false },
  { id: "L10", name: "rate_limit", w: 1, stub: false },
  { id: "L11", name: "seat_geo_bind", w: 3, stub: false },
  { id: "L12", name: "version_lock", w: 3, stub: false },
  { id: "L13", name: "ed25519_verify", w: 8, stub: true },
];

export const COMPUTED_GATES = GATES.filter((g) => !g.stub);
export const STUBBED_GATES = GATES.filter((g) => g.stub);

export interface ComputeCtx extends IveRunContext {
  contentHash: string;
}

/**
 * Compute all 13 gates against a payload + context. A FAIL anywhere blocks
 * the commit; stubbed gates never fail (they report CANNOT_COMPUTE).
 */
export function computeGates(
  p: Record<string, string | number>,
  ctx: ComputeCtx,
  ledger: LedgerEntry[],
  nowMs: number,
): GateResult[] {
  const get = (k: string) => String(p[k] ?? "").trim();

  const results: GateResult[] = GATES.map((g) => {
    switch (g.id) {
      case "L1": {
        const missing = CANON_FIELDS.filter((f) => !get(f));
        return {
          ...g,
          status: missing.length === 0 ? "PASS" : "FAIL",
          detail: missing.length ? `missing: ${missing.join(",")}` : "all 11 present",
        };
      }
      case "L2":
        return { ...g, status: ctx.author.length > 3 ? "PASS" : "FAIL", detail: "author" };
      case "L3":
        return { ...g, status: ctx.conf >= 0.1 && ctx.conf <= 0.99 ? "PASS" : "FAIL", detail: "confidence" };
      case "L4":
        return { ...g, status: ctx.bounds > 0 && ctx.bounds <= 0.5 ? "PASS" : "FAIL", detail: "bounds" };
      case "L5":
        return { ...g, status: ctx.presence ? "PASS" : "FAIL", detail: "presence" };
      case "L6":
        return { ...g, status: ctx.diffEdits >= 12 ? "PASS" : "FAIL", detail: "diff" };
      case "L7":
        return { ...g, status: "CANNOT_COMPUTE", detail: "stubbed" };
      case "L8":
        return { ...g, status: ctx.deliberation >= 15 ? "PASS" : "FAIL", detail: "deliberation" };
      case "L9": {
        const dup = ledger.some((e) => e.contentHash === ctx.contentHash);
        return { ...g, status: dup ? "FAIL" : "PASS", detail: "duplicate" };
      }
      case "L10": {
        const recent = ledger.filter((e) => Math.abs(nowMs - Date.parse(e.ts.replace("Z", "Z"))) < 60_000).length;
        return { ...g, status: recent < 5 ? "PASS" : "FAIL", detail: "rate" };
      }
      case "L11":
        return { ...g, status: get("geo").length > 0 ? "PASS" : "FAIL", detail: "geo" };
      case "L12":
        return { ...g, status: get("firmware") === "studio_v1.2.1" ? "PASS" : "FAIL", detail: "version" };
      case "L13":
        return { ...g, status: "CANNOT_COMPUTE", detail: "stubbed" };
      default:
        return { ...g, status: "CANNOT_COMPUTE", detail: "unknown" };
    }
  });

  return results;
}

export function summariseGates(results: GateResult[]) {
  const pass = results.filter((r) => r.status === "PASS").length;
  const fail = results.filter((r) => r.status === "FAIL").length;
  const stub = results.filter((r) => r.status === "CANNOT_COMPUTE").length;
  return { pass, fail, stub, total: results.length };
}

export const GATE_STATUS_LABEL: Record<GateStatus, string> = {
  PASS: "PASS",
  FAIL: "FAIL",
  CANNOT_COMPUTE: "STUB",
};
