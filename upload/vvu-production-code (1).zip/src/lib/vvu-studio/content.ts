/**
 * VVU · STUDIO — static document content for the prose views.
 * Block-based so DocView can render richly without a markdown parser.
 */
import type { ViewKey } from "./types";

export type DocBlock =
  | { type: "kicker"; text: string }
  | { type: "h1"; text: string }
  | { type: "h2"; text: string }
  | { type: "h3"; text: string }
  | { type: "p"; text: string } // may contain **bold** and `code`
  | { type: "lede"; text: string }
  | { type: "pre"; text: string }
  | { type: "callout"; tone?: "warn" | "ok"; text: string }
  | { type: "table"; head: string[]; rows: string[][] }
  | { type: "hr" };

export interface DocContent {
  view: ViewKey;
  group: string;
  blocks: DocBlock[];
}

export const CONFIG_JSON = {
  version: "1.0.0",
  doctrine: "paranoia-first",
  gates: { computed: 11, stubbed: 2, total: 13 },
  ledger: { worm: true, storage: "localStorage" },
  depot: { threshold: 20000, tier_min: "T2", kit: "Mk 0.5", price_zar: 1671 },
  canonical_fields: [
    "sensor_id",
    "firmware",
    "calib_epoch",
    "utc_ts",
    "geo",
    "proc_type",
    "evidence_status",
    "channel",
    "merchantId",
    "hour",
    "gapDraw",
  ],
};

export const DOCS: Record<string, DocContent> = {
  readme: {
    view: "readme",
    group: "VVU-STUDIO",
    blocks: [
      { type: "kicker", text: "VVU · STUDIO" },
      { type: "h1", text: "Six things. One loop. The number goes up." },
      {
        type: "lede",
        text: "The system does six things. Any order. Any time. On demand. Not 13 gates. Not roles. Not states. Not an org chart. Six capabilities and one loop — the number going up is the point.",
      },
      { type: "h2", text: "The six capabilities" },
      { type: "p", text: "**1. Take in an observation.** Record what, where, when, who, how much. Store it. The system does not judge. Does not smooth. Does not fill gaps." },
      { type: "p", text: "**2. Run rules that are written down.** Whatever rules — yours, mine, anyone's. The system runs them and returns `PASS`, `FAIL`, or `CAN'T-DECIDE`. Same input, same rules, same result — for anyone. The count is irrelevant." },
      { type: "p", text: "**3. Produce a receipt.** Hash of the record. Signature over the hash. Timestamp. A stranger verifies it without trusting you." },
      { type: "p", text: "**4. Say the current number.** One line. `RECEIPTS: N`. Updated when it changes." },
      { type: "p", text: "**5. Close an open item by producing the artifact.** You have the file? Submit it. It closes. You don't? It stays open, reason specific: `no artifact`. Not `missing Role 3`. Not `State 4 required`." },
      { type: "p", text: "**6. Fail visibly.** Corrupt file. Mismatched hash. Rule that can't decide. Loud, at the point of failure. No silent fallback. No `close enough`." },
      { type: "h2", text: "The loop" },
      { type: "pre", text: "record → run rules → receipt → number → repeat\n\nPASS, FAIL, or CAN'T-DECIDE —\na receipt is issued in all three cases.\nThe number goes up.\nThe number going up is the point." },
      { type: "h2", text: "The test" },
      { type: "p", text: "Can a stranger, using only what's public, do the six things? Record format is published. Rules are written down. Hash + signature are on the receipt. The number is one line. The receipt says which rule failed first. The failure is loud." },
      { type: "callout", tone: "warn", text: "What I got wrong before: I said \"13 gates\" like 13 mattered. It doesn't. I invented roles and states and called an org chart a spec. That's the disease. The system cares that rules are written down and deterministic — not how many there are." },
      { type: "h2", text: "Where to start" },
      { type: "p", text: "Open `the loop/loop.py`. One observation is already run through (the genesis receipt). The number is 1, not 0. Run the loop again — your own observation — and watch the number go up." },
    ],
  },
  doctrine: {
    view: "doctrine",
    group: ".vvu",
    blocks: [
      { type: "kicker", text: ".vvu/doctrine.md" },
      { type: "h1", text: "The Doctrine" },
      { type: "lede", text: "One executive mandate: absolute enforcement of epistemic integrity." },
      { type: "h2", text: "01 · Computed Gates" },
      { type: "p", text: "Every logic transition and data state must be verified as actively computed by a known logic path. A number with no computation path behind it is not a result — it is a claim." },
      { type: "h2", text: "02 · Stubbed Gates Flagged" },
      { type: "p", text: "Any simulated gate must be explicitly and visually distinct. The system flags its own stubs — honesty about what is not yet real is a feature." },
      { type: "h2", text: "03 · Strong = Suspicious" },
      { type: "p", text: "Any signal presenting as perfect, without a verifiable path, must be treated as a potential compromise. Perfection is evidence of spoofing, not of quality." },
      { type: "h2", text: "Zero Fabrication Rule" },
      { type: "p", text: "Missing data is `[UNDEFINED]`. Uncorroborated data is `[UNVERIFIED]`. Estimates are delivered with bounds: `0.72 ± 0.05` — never a bare `1.0`." },
      { type: "table", head: ["Tier", "Name", "Meaning"], rows: [
        ["T1", "Computed", "Hashes, signatures, code you can run"],
        ["T2", "Documented", "Receipts, invoices, published prices"],
        ["T3", "Claimed", "Stated but not documented"],
        ["T4", "Hearsay", "Second-hand, uncorroborated"],
      ] },
    ],
  },
  lesson0: {
    view: "lesson0",
    group: "lessons",
    blocks: [
      { type: "kicker", text: "Lessons · 00" },
      { type: "h1", text: "Numbers Are Places" },
      { type: "lede", text: "A number is not a squiggle on paper — it is a place. Two numbers together are an address on the plane." },
      { type: "p", text: "Drag the point to the address `(3, 4)`: three steps east of centre, four steps north. That is all a coordinate ever was — a place where something lives." },
      { type: "callout", text: "Open `labs/lab0_plane.py` to work the plane interactively." },
      { type: "h2", text: "The Grammar of the Plane" },
      { type: "p", text: "North is up, south is down, west is left, east is right. A move along one axis never disturbs the other — that independence is the grammar of the plane." },
      { type: "pre", text: "(3, 1) + (1, 2) = (4, 3)\n\n# addition is walking" },
    ],
  },
  lesson1: {
    view: "lesson1",
    group: "lessons",
    blocks: [
      { type: "kicker", text: "Lessons · 01" },
      { type: "h1", text: "EIS Evidence · Independence" },
      { type: "lede", text: "Independence is measured as distance in sensor space. Two readings close together share a failure mode." },
      { type: "h2", text: "Distance Is the Test" },
      { type: "pre", text: "d(A,B) = √[(x₂−x₁)² + (y₂−y₁)²]\nthreshold: d > 2.0" },
      { type: "callout", text: "Open `lab1_lucky.py` to see the same distance formula applied to a random draw." },
    ],
  },
  lesson2: {
    view: "lesson2",
    group: "lessons",
    blocks: [
      { type: "kicker", text: "Lessons · 02" },
      { type: "h1", text: "Credential Engine · Soulbound Tokens" },
      { type: "lede", text: "Credentials verify skills and cannot be transferred away from the earner. ERC-5192 / SBT pattern." },
      { type: "pre", text: "submission → signed receipt\n         → Merkle leaf\n         → cohort Merkle root\n         → SBT (ERC-5192)\n         → Arweave pin\n         → employer verifies by recomputing" },
      { type: "callout", text: "Verification, not declaration. The difference is whether the arithmetic closes." },
    ],
  },
  lesson3: {
    view: "lesson3",
    group: "lessons",
    blocks: [
      { type: "kicker", text: "Lessons · 03" },
      { type: "h1", text: "Day-One Depot · ONE INSTRUMENT" },
      { type: "lede", text: "One visit, one instrument, three questions, one recording line." },
      { type: "h2", text: "The Three Questions" },
      { type: "p", text: "**Q1 · Financial:** audit/verification cost > R20,000/month?" },
      { type: "p", text: "**Q2 · Structural:** visible inefficiency from untrusted telemetry?" },
      { type: "p", text: "**Q3 · Capability:** read-only tap without breaking the write-path?" },
      { type: "pre", text: "PASS = cost > R20,000/mo AND tier ∈ {T1, T2}\nPASS → Mk 0.5 · R1,671" },
      { type: "callout", tone: "warn", text: "A PASS authorises exactly one thing: Build Kit #1." },
    ],
  },
};

/** The default 11-field payload (used by IVE + hash builder samples). */
export const DEFAULT_PAYLOAD: Record<string, string | number> = {
  sensor_id: "stu_9f3a",
  firmware: "studio_v1.2.1",
  calib_epoch: "lesson_v0.4.2",
  utc_ts: "",
  geo: "seat B12/room 301",
  proc_type: "EXERCISE",
  evidence_status: "COMPUTED",
  channel: "STUDENT_SUBMISSION",
  merchantId: "course_cs201",
  hour: "",
  gapDraw: "0.72",
};

export const DEFAULT_AUTHOR = "external_curriculum_author_0x3f";
