/**
 * VVU · STUDIO — the Zustand store. 100% client-side; persisted to
 * localStorage under `vvu_studio_v1`. The browser is the validator.
 */
import { create } from "zustand";
import type {
  ChatMsg,
  DrawerName,
  Lab0State,
  Lab1Result,
  LedgerEntry,
  TermLine,
  ViewKey,
} from "./types";
import { canon, sha256, ZERO_HASH, nowISO, nowHour } from "./crypto";
import { GATES, computeGates, summariseGates, type ComputeCtx } from "./gates";
import { DEFAULT_PAYLOAD, DEFAULT_AUTHOR } from "./content";
import { CANON_FIELDS } from "./types";
import { agentReply, SEED_CHAT } from "./agent";
import { drawLucky, evalDepot, clampLab0, type DepotInput } from "./labs";
import { runCommand } from "./terminal";
import {
  type Observation,
  type Receipt,
  type OpenItem,
  type FailureReport,
  type StrangerVerifyInput,
  type StrangerVerifyResult,
  type MerkleProofStep,
  blankObservation,
  genesisObservation,
  buildCloseObservation,
  runRules,
  produceReceipt,
  signReceipt,
  isEd25519Available,
  currentPubKeyHex,
  currentKeyOrigin,
  merkleRoot as merkleRootFn,
  merkleTree as merkleTreeFn,
  merkleProof as merkleProofFn,
  verifyMerkleProof as verifyMerkleProofFn,
  strangerVerifySig,
  readNumber,
  closeItem as closeItemFn,
  defaultOpenItems,
  defaultEnabledRules,
  verifyChain as verifyLoopChainFn,
  tamperReceipt as tamperReceiptFn,
  recomputeReceiptHash,
  strangerVerify as strangerVerifyFn,
  RULE_DEFS,
} from "./loop";
import { buildReceiptVerifyHTML, buildChainVerifyHTML } from "./verify-html";

const LS_KEY = "vvu_studio_v1";

interface IveStage {
  state: "idle" | "active" | "done" | "fail";
}

export interface StudioStore {
  /* persisted */
  openTabs: ViewKey[];
  activeTab: ViewKey | null;
  ledger: LedgerEntry[];
  receipts: number;
  chat: ChatMsg[];
  term: TermLine[];
  lab1: {
    name: string;
    count: number;
    start: number;
    end: number;
    seed: string | null;
    last: Lab1Result | null;
  };
  lab0: Lab0State;
  ive: { lastRun: ComputeCtx | null; lastPayload: Record<string, string | number> | null };
  watchCollapsed: boolean;
  drawer: DrawerName | null;

  /* transient (not persisted) */
  toast: { msg: string; kind: "" | "ok" | "err"; id: number } | null;
  iveRunning: boolean;
  iveStages: IveStage[];
  iveOut: TermLine[];
  iveGates: ReturnType<typeof computeGates> | null;
  iveBadge: "committed" | "locked" | null;
  depotResult: ReturnType<typeof evalDepot> | null;
  hashOut: { canonical: string; hash: string; bytes: number } | null;
  chainVerify: { lines: TermLine[]; intact: boolean } | null;

  /* actions */
  openFile: (view: ViewKey) => void;
  closeTab: (view: ViewKey) => void;
  setActive: (view: ViewKey) => void;
  toggleFolder: (path: string) => void;
  folders: Record<string, boolean>;

  toggleDrawer: (name: DrawerName) => void;
  openDrawer: (name: DrawerName) => void;
  closeDrawer: (name: DrawerName) => void;
  closeAllDrawers: () => void;

  sendAgent: (text: string) => void;
  clearChat: () => void;

  runTerminal: (raw: string) => void;
  clearTerm: () => void;

  lab0Move: (dx: number, dy: number) => void;
  lab0Set: (x: number, y: number) => void;
  lab0Reset: () => void;

  lab1Run: () => void;
  lab1Reproduce: () => void;
  lab1Reset: () => void;

  iveRun: () => Promise<void>;
  iveReset: () => void;

  doHash: (input: string) => void;
  loadHashSample: () => string;

  evalDepot: (input: DepotInput) => void;
  verifyChain: () => void;
  clearLedger: () => void;

  toggleWatch: () => void;
  showToast: (msg: string, kind?: "" | "ok" | "err") => void;

  /* ---- the six-capability loop ---- */
  observation: Observation;
  setObservation: (patch: Partial<Observation>) => void;
  resetObservation: () => void;
  /** the receipts produced by the loop (capability 3/4) */
  loopReceipts: Receipt[];
  /** open items (capability 5) */
  openItems: OpenItem[];
  /** chain verification result (capability 6) */
  loopVerify: { intact: boolean; failures: FailureReport[] } | null;
  /** which rules are enabled (capability 2: "whatever rules") */
  enabledRules: Record<string, boolean>;
  /** stranger-verify result (capability 3 test) */
  strangerResult: StrangerVerifyResult | null;
  /** run the loop: record → run rules → receipt → number. ALWAYS appends + increments. */
  runLoop: () => void;
  closeOpenItem: (id: string, artifact: string | null) => void;
  verifyLoopChain: () => void;
  resetLoop: () => void;
  toggleRule: (id: string) => void;
  /** capability 6 demo: corrupt a receipt's hash → next verify screams */
  tamperReceipt: (seq: number) => void;
  /** restore a tampered receipt's receiptHash to the correct value */
  restoreReceipt: (seq: number) => void;
  /** capability 3 test: verify a pasted receipt independently */
  runStrangerVerify: (input: StrangerVerifyInput) => void;
  clearStrangerResult: () => void;
  /** export receipts as JSON (capability 3: stranger re-verifies) */
  exportReceipts: () => string;
  /** one line: RECEIPTS: N */
  numberLine: () => string;
  /** one-click tamper→BROKEN→restore→INTACT walkthrough (capability 6 demo) */
  walkthrough: () => Promise<void>;
  /** walkthrough step state (transient) */
  walkthroughStep: number;
  /** sign any pending (unsigned) receipts with real Ed25519 (or honest stub) */
  signAllPending: () => Promise<void>;
  /** publish the genesis receipt hash to /download (capability 3: out-of-band) */
  publishGenesis: () => void;
  /** the merkle root of all receipts (single commitment) */
  merkleRootLine: () => string;
  /** whether Ed25519 is available in this browser */
  ed25519Available: boolean | null;
  /** the current Ed25519 pubKey hex (null if not yet generated) */
  pubKeyHex: string | null;
  /** where the keypair came from: "indexeddb" (persisted) | "fresh" (this session) | null */
  keyOrigin: "indexeddb" | "fresh" | null;
  /** refresh the key status (pubKey + origin) from the loop module */
  refreshKeyStatus: () => void;
  /** full stranger-verify: sig + hashes + merkle path for a receipt by seq */
  verifyReceiptFull: (seq: number) => Promise<void>;
  /** full stranger-verify result (transient) */
  fullVerifyResult: {
    seq: number;
    sigCheck: { ok: boolean; detail: string } | null;
    hashChecks: { name: string; pass: boolean; expected: string; actual: string }[];
    merklePath: { steps: MerkleProofStep[]; recomputedRoot: string; expectedRoot: string; pass: boolean } | null;
    overallOk: boolean;
  } | null;
  /** export a single receipt + its merkle proof (a stranger verifies inclusion without the whole chain) */
  exportReceiptWithProof: (seq: number) => void;
  /** export the full public board (pubKey + merkle root + genesis + chain summary) */
  exportBoard: () => void;
  /** export a self-verifying HTML page for a receipt (a stranger opens it in a browser, it re-computes everything) */
  exportVerifyHTML: (seq: number) => void;
  /** export a self-verifying HTML page for the FULL CHAIN (all receipts + merkle root) */
  exportChainHTML: () => void;
}

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

function defaultState() {
  return {
    openTabs: ["stakeholder"] as ViewKey[],
    activeTab: "stakeholder" as ViewKey | null,
    ledger: [] as LedgerEntry[],
    receipts: 0,
    chat: [...SEED_CHAT] as ChatMsg[],
    term: [
      { t: "dim" as const, v: "# VVU · STUDIO — shell ready" },
      { t: "dim" as const, v: "# the loop: record → run rules → receipt → number" },
      { t: "" as const, v: "" },
    ],
    lab1: { name: "Adael", count: 5, start: 1, end: 50, seed: null, last: null },
    lab0: { x: -2, y: -1.5 },
    ive: { lastRun: null, lastPayload: null },
    watchCollapsed: true,
    drawer: null as DrawerName | null,
    folders: {
      ".vvu": false,
      lessons: false,
      labs: false,
      ive: false,
      depot: false,
      receipts: false,
    } as Record<string, boolean>,
  };
}

/**
 * Seed ONE real genesis receipt on first load so the number is 1, not 0.
 * The user's spec: "Next action: one observation, run it, produce one
 * receipt, update the number. The number goes 0 → 1."
 *
 * This is that one observation, run through the loop, once.
 * The signature is filled in async by `signGenesis()` after first load.
 */
function seedLoopReceipts(): Receipt[] {
  const obs = genesisObservation();
  const results = runRules(obs);
  const receipt = produceReceipt(obs, results, 1, ZERO_HASH);
  return [receipt];
}

/** Async: sign the genesis receipt with real Ed25519 (or honest stub). */
async function signGenesis(receipts: Receipt[]): Promise<Receipt[]> {
  if (receipts.length === 0) return receipts;
  if (receipts[0].sigAlg !== "pending") return receipts; // already signed
  const signed = await signReceipt(receipts[0]);
  return [signed, ...receipts.slice(1)];
}

function seedLoopState() {
  return {
    observation: blankObservation() as Observation,
    loopReceipts: seedLoopReceipts() as Receipt[],
    openItems: defaultOpenItems() as OpenItem[],
    loopVerify: null as { intact: boolean; failures: FailureReport[] } | null,
    enabledRules: defaultEnabledRules() as Record<string, boolean>,
    strangerResult: null as StrangerVerifyResult | null,
  };
}

function loadPersisted(): ReturnType<typeof defaultState> {
  if (typeof window === "undefined") {
    return { ...defaultState(), ...seedLoopState() };
  }
  try {
    const raw = window.localStorage.getItem(LS_KEY);
    if (!raw) {
      // first load: seed the genesis receipt so the number is 1, not 0
      return { ...defaultState(), ...seedLoopState() };
    }
    const parsed = JSON.parse(raw);
    const base = defaultState();
    const loop = seedLoopState();
    return {
      ...base,
      ...parsed,
      lab1: { ...base.lab1, ...(parsed.lab1 || {}) },
      lab0: { ...base.lab0, ...(parsed.lab0 || {}) },
      ive: { ...base.ive, ...(parsed.ive || {}) },
      folders: { ...base.folders, ...(parsed.folders || {}) },
      // loop slice: keep persisted receipts/openItems, but backfill defaults
      observation: parsed.observation ?? loop.observation,
      loopReceipts: Array.isArray(parsed.loopReceipts) && parsed.loopReceipts.length > 0 ? parsed.loopReceipts : loop.loopReceipts,
      openItems: Array.isArray(parsed.openItems) && parsed.openItems.length > 0 ? parsed.openItems : loop.openItems,
      enabledRules: parsed.enabledRules ?? loop.enabledRules,
      loopVerify: null,
      strangerResult: null,
      // never persist transient
      drawer: parsed.drawer ?? null,
    };
  } catch {
    return { ...defaultState(), ...seedLoopState() };
  }
}

function persist(s: StudioStore) {
  if (typeof window === "undefined") return;
  try {
    const payload = {
      openTabs: s.openTabs,
      activeTab: s.activeTab,
      ledger: s.ledger,
      receipts: s.receipts,
      chat: s.chat,
      term: s.term.slice(-300),
      lab1: s.lab1,
      lab0: s.lab0,
      ive: s.ive,
      watchCollapsed: s.watchCollapsed,
      drawer: s.drawer,
      folders: s.folders,
      observation: s.observation,
      loopReceipts: s.loopReceipts,
      openItems: s.openItems,
      enabledRules: s.enabledRules,
    };
    window.localStorage.setItem(LS_KEY, JSON.stringify(payload));
  } catch {
    /* quota / private mode — ignore */
  }
}

const FRESH_PAYLOAD = () => {
  const p: Record<string, string | number> = { ...DEFAULT_PAYLOAD };
  p.utc_ts = nowISO();
  p.hour = nowHour();
  return p;
};

export const useStudio = create<StudioStore>((set, get) => {
  const initial = loadPersisted();

  const update = (partial: Partial<StudioStore>) => {
    set(partial);
    persist(get());
  };

  return {
    ...initial,
    toast: null,
    iveRunning: false,
    iveStages: Array.from({ length: 6 }, () => ({ state: "idle" as const })),
    iveOut: [],
    iveGates: null,
    iveBadge: null,
    depotResult: null,
    hashOut: null,
    chainVerify: null,
    loopVerify: null,
    walkthroughStep: 0,
    ed25519Available: null,
    pubKeyHex: null,
    keyOrigin: null,
    fullVerifyResult: null,

    /* ---- the six-capability loop ---- */
    setObservation: (patch) => {
      const s = get();
      update({ observation: { ...s.observation, ...patch } });
    },
    resetObservation: () => update({ observation: blankObservation() }),
    runLoop: () => {
      const s = get();
      const obs = { ...s.observation };
      // normalise blank when/hour → now (the receipt records what was actually stored)
      if (!obs.when.trim()) obs.when = nowISO();
      if (!obs.hour.trim()) obs.hour = String(new Date().getUTCHours()).padStart(2, "0");
      const results = runRules(obs, s.enabledRules);
      const prevHash = s.loopReceipts.length ? s.loopReceipts[s.loopReceipts.length - 1].receiptHash : ZERO_HASH;
      const seq = s.loopReceipts.length + 1;
      const receipt = produceReceipt(obs, results, seq, prevHash);
      const loopReceipts = [...s.loopReceipts, receipt];
      update({ loopReceipts, loopVerify: null, observation: obs });

      // terminal side-effect: the loop ran
      const term = [...get().term];
      term.push({ t: "in", v: "loop" });
      const v = receipt.verdict;
      term.push({
        t: v === "PASS" ? "ok" : v === "FAIL" ? "err" : "warn",
        v: `  #${seq} ${v} · ${receipt.recordHash.slice(0, 16)}…${receipt.firstFail ? " · first fail: " + receipt.firstFail.id + " " + receipt.firstFail.name : ""}`,
      });
      term.push({ t: "dim", v: `  RECEIPTS: ${loopReceipts.length}` });
      update({ term: term.length > 300 ? term.slice(-300) : term });

      get().showToast(
        `#${seq} ${v}${receipt.firstFail ? " · " + receipt.firstFail.id : ""}`,
        v === "PASS" ? "ok" : v === "FAIL" ? "err" : "",
      );

      // async: sign the receipt with real Ed25519 (or honest stub)
      void signReceipt(receipt).then((signed) => {
        const cur = get();
        const updated = cur.loopReceipts.map((r) => r.seq === signed.seq ? signed : r);
        update({ loopReceipts: updated });
      });
    },
    closeOpenItem: (id, artifact) => {
      const s = get();
      const item = s.openItems.find((i) => i.id === id);
      if (!item) return;
      // No artifact → stays open, reason specific: "no artifact"
      if (!artifact || artifact.trim() === "") {
        const openItems = s.openItems.map((it) => it.id === id ? { ...it, artifactProduced: null, artifactHash: null, closedBySeq: null, closedAt: null } : it);
        update({ openItems });
        get().showToast(`${id} stays open · no artifact`, "err");
        return;
      }
      // Artifact produced → build a close observation, run the loop (append a receipt),
      // then close the item against THAT receipt. The artifact hash is embedded in
      // the observation → part of the canonical → part of the recordHash → verifiable.
      const closeObs = buildCloseObservation(item, artifact);
      const results = runRules(closeObs, s.enabledRules);
      const prevHash = s.loopReceipts.length ? s.loopReceipts[s.loopReceipts.length - 1].receiptHash : ZERO_HASH;
      const seq = s.loopReceipts.length + 1;
      const receipt = produceReceipt(closeObs, results, seq, prevHash);
      const loopReceipts = [...s.loopReceipts, receipt];
      const openItems = s.openItems.map((it) => it.id === id ? closeItemFn(it, artifact, seq) : it);
      update({ loopReceipts, openItems, loopVerify: null });

      const term = [...get().term];
      term.push({ t: "in", v: `close ${id}` });
      term.push({ t: "ok", v: `  ${id} closed · receipt #${seq} · artifact hash ${receipt.recordHash.slice(0, 16)}…` });
      term.push({ t: "dim", v: `  RECEIPTS: ${loopReceipts.length}` });
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast(`${id} closed · receipt #${seq}`, "ok");

      // async: sign the close receipt
      void signReceipt(receipt).then((signed) => {
        const cur = get();
        const updated = cur.loopReceipts.map((r) => r.seq === signed.seq ? signed : r);
        update({ loopReceipts: updated });
      });
    },
    verifyLoopChain: () => {
      const s = get();
      const res = verifyLoopChainFn(s.loopReceipts);
      update({ loopVerify: res });
      const term = [...get().term];
      term.push({ t: "in", v: "verify-chain" });
      if (res.intact) {
        term.push({ t: "ok", v: `  CHAIN INTACT · ${s.loopReceipts.length} receipts` });
      } else {
        for (const f of res.failures) term.push({ t: "err", v: `  ${f.kind}: ${f.message}` });
        term.push({ t: "err", v: `  CHAIN BROKEN · ${res.failures.length} failure(s)` });
      }
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast(res.intact ? "CHAIN INTACT" : "CHAIN BROKEN", res.intact ? "ok" : "err");
    },
    resetLoop: () => {
      if (typeof window !== "undefined" && !window.confirm("Reset the loop? All receipts will be cleared and one fresh genesis receipt re-seeded.")) return;
      update({
        loopReceipts: seedLoopReceipts(),
        loopVerify: null,
        openItems: defaultOpenItems(),
        observation: blankObservation(),
        enabledRules: defaultEnabledRules(),
        strangerResult: null,
      });
      get().showToast("loop reset · 1 genesis receipt", "ok");
    },
    toggleRule: (id) => {
      const s = get();
      const enabledRules = { ...s.enabledRules, [id]: !s.enabledRules[id] };
      update({ enabledRules });
      get().showToast(`${id} ${enabledRules[id] ? "enabled" : "disabled"}`, enabledRules[id] ? "ok" : "");
    },
    tamperReceipt: (seq) => {
      const s = get();
      const loopReceipts = s.loopReceipts.map((r) => r.seq === seq ? tamperReceiptFn(r) : r);
      update({ loopReceipts, loopVerify: null });
      const term = [...get().term];
      term.push({ t: "warn", v: `⚠ tampered #${seq} · recordHash byte flipped` });
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast(`#${seq} tampered — run verify`, "err");
    },
    restoreReceipt: (seq) => {
      const s = get();
      const loopReceipts = s.loopReceipts.map((r) => {
        if (r.seq !== seq) return r;
        // fully restore: recompute recordHash from the (intact) canonical,
        // then recompute receiptHash from prev ‖ recordHash ‖ ts.
        const correctRecordHash = sha256(r.canonical);
        const correctReceiptHash = sha256(r.prevHash + "|" + correctRecordHash + "|" + r.ts);
        return { ...r, recordHash: correctRecordHash, receiptHash: correctReceiptHash };
      });
      update({ loopReceipts, loopVerify: null });
      const term = [...get().term];
      term.push({ t: "ok", v: `restored #${seq} · recordHash + receiptHash recomputed` });
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast(`#${seq} restored`, "ok");
    },
    runStrangerVerify: (input) => {
      const res = strangerVerifyFn(input);
      update({ strangerResult: res });
      const term = [...get().term];
      term.push({ t: "in", v: "stranger-verify" });
      if (res.ok) {
        term.push({ t: "ok", v: `  ✓ receipt #${input.seq} re-verifies independently` });
      } else {
        for (const f of res.failures) term.push({ t: "err", v: `  ${f.kind}: ${f.message}` });
        term.push({ t: "err", v: `  ✗ receipt #${input.seq} FAILS independent re-verify` });
      }
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast(res.ok ? "stranger-verify: OK" : "stranger-verify: FAIL", res.ok ? "ok" : "err");
    },
    clearStrangerResult: () => update({ strangerResult: null }),
    exportReceipts: () => {
      const s = get();
      const root = merkleRootFn(s.loopReceipts);
      const exported = {
        format: "vvu-studio-receipts-v1",
        exportedAt: nowISO(),
        count: s.loopReceipts.length,
        genesisPrevHash: ZERO_HASH,
        hashAlgorithm: "SHA-256",
        merkleRoot: root,
        signatureNote: s.ed25519Available ? "sig is real Ed25519 (Web Crypto)" : "sig is HMAC-SHA256 stand-in (Ed25519 unavailable) — honestly stubbed",
        chainRule: "receiptHash_i = SHA-256(prevHash_i ‖ recordHash_i ‖ ts_i)",
        merkleRule: "merkle root = pairwise SHA-256 of receiptHashes (duplicate-last on odd counts)",
        receipts: s.loopReceipts.map((r) => ({
          seq: r.seq,
          ts: r.ts,
          canonical: r.canonical,
          recordHash: r.recordHash,
          receiptHash: r.receiptHash,
          prevHash: r.prevHash,
          sig: r.sig,
          sigAlg: r.sigAlg,
          sigStub: r.sigStub,
          sigPubKey: r.sigPubKey,
          verdict: r.verdict,
          firstFail: r.firstFail,
        })),
      };
      return JSON.stringify(exported, null, 2);
    },
    numberLine: () => readNumber(get().loopReceipts),
    merkleRootLine: () => {
      const root = merkleRootFn(get().loopReceipts);
      return `MERKLE ROOT: ${root}`;
    },
    signAllPending: async () => {
      const s = get();
      const pending = s.loopReceipts.filter((r) => r.sigAlg === "pending");
      const available = await isEd25519Available();
      if (pending.length === 0) {
        update({ ed25519Available: available, pubKeyHex: currentPubKeyHex(), keyOrigin: currentKeyOrigin() });
        return;
      }
      const signed = await Promise.all(pending.map((r) => signReceipt(r)));
      const bySeq = new Map(signed.map((r) => [r.seq, r]));
      const loopReceipts = s.loopReceipts.map((r) => bySeq.get(r.seq) ?? r);
      update({ loopReceipts, ed25519Available: available, pubKeyHex: currentPubKeyHex(), keyOrigin: currentKeyOrigin() });
      const term = [...get().term];
      const alg = available ? "Ed25519" : "HMAC-SHA256";
      const origin = currentKeyOrigin();
      term.push({ t: "dim", v: `# signed ${pending.length} receipt(s) · ${alg}${available ? "" : " (stub fallback)"}${origin ? " · key: " + origin : ""}` });
      update({ term: term.length > 300 ? term.slice(-300) : term });
    },
    refreshKeyStatus: () => {
      update({ pubKeyHex: currentPubKeyHex(), keyOrigin: currentKeyOrigin() });
    },
    verifyReceiptFull: async (seq) => {
      const s = get();
      const receipt = s.loopReceipts.find((r) => r.seq === seq);
      if (!receipt) {
        get().showToast(`receipt #${seq} not found`, "err");
        return;
      }
      // 1. signature check
      const sigCheck = await strangerVerifySig(receipt);
      // 2. hash checks (recordHash + receiptHash)
      const hashChecks = [
        {
          name: "recordHash = SHA-256(canonical)",
          expected: sha256(receipt.canonical),
          actual: receipt.recordHash,
          pass: sha256(receipt.canonical) === receipt.recordHash,
        },
        {
          name: "receiptHash = SHA-256(prev ‖ record ‖ ts)",
          expected: sha256(receipt.prevHash + "|" + receipt.recordHash + "|" + receipt.ts),
          actual: receipt.receiptHash,
          pass: sha256(receipt.prevHash + "|" + receipt.recordHash + "|" + receipt.ts) === receipt.receiptHash,
        },
      ];
      // 3. merkle inclusion proof
      const idx = s.loopReceipts.findIndex((r) => r.seq === seq);
      const steps = merkleProofFn(s.loopReceipts, idx);
      const recomputedRoot = verifyMerkleProofFn(receipt.receiptHash, steps);
      const expectedRoot = merkleRootFn(s.loopReceipts);
      const merklePath = {
        steps,
        recomputedRoot,
        expectedRoot,
        pass: recomputedRoot === expectedRoot,
      };
      const overallOk = sigCheck.ok && hashChecks.every((c) => c.pass) && merklePath.pass;
      update({ fullVerifyResult: { seq, sigCheck, hashChecks, merklePath, overallOk } });
      const term = [...get().term];
      term.push({ t: "in", v: `verify-receipt ${seq}` });
      term.push({ t: overallOk ? "ok" : "err", v: `  ${overallOk ? "✓ all checks pass" : "✗ verification FAILED"} · sig ${sigCheck.ok ? "ok" : "FAIL"} · hashes ${hashChecks.every((c) => c.pass) ? "ok" : "FAIL"} · merkle ${merklePath.pass ? "ok" : "FAIL"}` });
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast(overallOk ? `#${seq} fully verified` : `#${seq} verification FAILED`, overallOk ? "ok" : "err");
    },
    publishGenesis: () => {
      const s = get();
      const genesis = s.loopReceipts[0];
      if (!genesis) {
        get().showToast("no genesis receipt", "err");
        return;
      }
      const board = {
        format: "vvu-studio-genesis-board-v1",
        publishedAt: nowISO(),
        genesisSeq: genesis.seq,
        genesisTs: genesis.ts,
        recordHash: genesis.recordHash,
        receiptHash: genesis.receiptHash,
        sigAlg: genesis.sigAlg,
        sigPubKey: genesis.sigPubKey,
        sig: genesis.sig,
        note: "A stranger compares this recordHash against the genesis receipt to verify the chain's root. Publish this out-of-band.",
      };
      const json = JSON.stringify(board, null, 2);
      try {
        const blob = new Blob([json], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `vvu-studio-genesis-board-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch {
        // Blob unavailable — ignore
      }
      const term = [...get().term];
      term.push({ t: "in", v: "publish-genesis" });
      term.push({ t: "ok", v: `  genesis recordHash: ${genesis.recordHash.slice(0, 32)}…` });
      term.push({ t: "ok", v: `  genesis sigAlg: ${genesis.sigAlg}${genesis.sigPubKey ? " · pubKey " + genesis.sigPubKey.slice(0, 16) + "…" : ""}` });
      term.push({ t: "dim", v: "  board exported to /download — publish out-of-band" });
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast("genesis board exported", "ok");
    },
    exportReceiptWithProof: (seq) => {
      const s = get();
      const idx = s.loopReceipts.findIndex((r) => r.seq === seq);
      const receipt = s.loopReceipts[idx];
      if (!receipt) {
        get().showToast(`receipt #${seq} not found`, "err");
        return;
      }
      const proof = merkleProofFn(s.loopReceipts, idx);
      const root = merkleRootFn(s.loopReceipts);
      const exported = {
        format: "vvu-studio-receipt-with-proof-v1",
        exportedAt: nowISO(),
        receipt: {
          seq: receipt.seq,
          ts: receipt.ts,
          canonical: receipt.canonical,
          recordHash: receipt.recordHash,
          receiptHash: receipt.receiptHash,
          prevHash: receipt.prevHash,
          sig: receipt.sig,
          sigAlg: receipt.sigAlg,
          sigStub: receipt.sigStub,
          sigPubKey: receipt.sigPubKey,
          verdict: receipt.verdict,
          firstFail: receipt.firstFail,
        },
        merkleProof: proof,
        publishedMerkleRoot: root,
        verificationInstructions: "1. recompute recordHash = SHA-256(canonical). 2. recompute receiptHash = SHA-256(prevHash | recordHash | ts). 3. verify the Ed25519 signature over recordHash using sigPubKey. 4. recompute the merkle root from receiptHash + merkleProof steps (left sibling prepended, right sibling appended). 5. compare to publishedMerkleRoot.",
      };
      const json = JSON.stringify(exported, null, 2);
      try {
        const blob = new Blob([json], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `vvu-studio-receipt-${seq}-with-proof-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch {
        // ignore
      }
      const term = [...get().term];
      term.push({ t: "in", v: `export-proof ${seq}` });
      term.push({ t: "ok", v: `  receipt #${seq} + ${proof.length}-step merkle proof exported` });
      term.push({ t: "dim", v: `  a stranger verifies inclusion without the whole chain` });
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast(`#${seq} + proof exported`, "ok");
    },
    exportBoard: () => {
      const s = get();
      const genesis = s.loopReceipts[0];
      if (!genesis) {
        get().showToast("no receipts", "err");
        return;
      }
      const root = merkleRootFn(s.loopReceipts);
      const board = {
        format: "vvu-studio-public-board-v1",
        publishedAt: nowISO(),
        chainSummary: {
          receiptCount: s.loopReceipts.length,
          genesisSeq: genesis.seq,
          genesisTs: genesis.ts,
          merkleRoot: root,
          chainIntact: verifyLoopChainFn(s.loopReceipts).intact,
        },
        signingKey: {
          algorithm: genesis.sigAlg,
          publicKey: genesis.sigPubKey,
          sigStub: genesis.sigStub,
        },
        genesisReceipt: {
          seq: genesis.seq,
          ts: genesis.ts,
          recordHash: genesis.recordHash,
          receiptHash: genesis.receiptHash,
          prevHash: genesis.prevHash,
          sig: genesis.sig,
        },
        lastReceipt: s.loopReceipts.length > 1 ? {
          seq: s.loopReceipts[s.loopReceipts.length - 1].seq,
          recordHash: s.loopReceipts[s.loopReceipts.length - 1].recordHash,
          receiptHash: s.loopReceipts[s.loopReceipts.length - 1].receiptHash,
        } : null,
        rules: "receiptHash_i = SHA-256(prevHash_i | recordHash_i | ts_i); merkleRoot = pairwise SHA-256 of receiptHashes (duplicate-last on odd); sig = Ed25519 over recordHash",
        note: "A stranger gets everything needed to verify the chain: the pubKey (sig verification), the merkle root (whole-chain commitment), the genesis receipt (root authenticity). Publish this out-of-band.",
      };
      const json = JSON.stringify(board, null, 2);
      try {
        const blob = new Blob([json], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `vvu-studio-public-board-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch {
        // ignore
      }
      const term = [...get().term];
      term.push({ t: "in", v: "export-board" });
      term.push({ t: "ok", v: `  public board exported · ${s.loopReceipts.length} receipts · merkle root ${root.slice(0, 16)}…` });
      term.push({ t: "ok", v: `  pubKey: ${genesis.sigPubKey ? genesis.sigPubKey.slice(0, 24) + "…" : "none"}` });
      term.push({ t: "dim", v: "  publish out-of-band — a stranger verifies the whole chain from this" });
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast("public board exported", "ok");
    },
    exportVerifyHTML: (seq) => {
      const s = get();
      const idx = s.loopReceipts.findIndex((r) => r.seq === seq);
      const receipt = s.loopReceipts[idx];
      if (!receipt) {
        get().showToast(`receipt #${seq} not found`, "err");
        return;
      }
      const proof = merkleProofFn(s.loopReceipts, idx);
      const root = merkleRootFn(s.loopReceipts);
      const html = buildReceiptVerifyHTML(receipt, proof, root);
      try {
        const blob = new Blob([html], { type: "text/html" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `vvu-studio-verify-receipt-${seq}.html`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch {
        // ignore
      }
      const term = [...get().term];
      term.push({ t: "in", v: `verify-html ${seq}` });
      term.push({ t: "ok", v: `  self-verifying HTML for receipt #${seq} exported` });
      term.push({ t: "dim", v: "  a stranger opens it in any browser — it re-computes sig + hashes + merkle" });
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast(`#${seq} verify-HTML exported`, "ok");
    },
    exportChainHTML: () => {
      const s = get();
      if (s.loopReceipts.length === 0) {
        get().showToast("no receipts", "err");
        return;
      }
      const root = merkleRootFn(s.loopReceipts);
      const html = buildChainVerifyHTML(s.loopReceipts, root);
      try {
        const blob = new Blob([html], { type: "text/html" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `vvu-studio-verify-chain-${new Date().toISOString().replace(/[:.]/g, "-")}.html`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch {
        // ignore
      }
      const term = [...get().term];
      term.push({ t: "in", v: "verify-chain-html" });
      term.push({ t: "ok", v: `  self-verifying chain HTML exported · ${s.loopReceipts.length} receipts · merkle root ${root.slice(0, 16)}…` });
      term.push({ t: "dim", v: "  a stranger opens it — it re-verifies every sig + every chain link + the merkle root" });
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast("chain verify-HTML exported", "ok");
    },
    walkthrough: async () => {
      // capability 6 demo: tamper → BROKEN → restore → INTACT, step by step
      const s = get();
      if (s.loopReceipts.length === 0) {
        get().showToast("run the loop first", "err");
        return;
      }
      const seq = s.loopReceipts[s.loopReceipts.length - 1].seq;
      const term = [...get().term];
      term.push({ t: "in", v: "walkthrough" });
      term.push({ t: "dim", v: "# capability 6 — fail visible, loudly" });
      update({ term: term.length > 300 ? term.slice(-300) : term, walkthroughStep: 1 });
      get().showToast("walkthrough: step 1 — tamper", "");
      await sleep(1200);

      // step 1: tamper
      get().tamperReceipt(seq);
      update({ walkthroughStep: 2 });
      get().showToast("walkthrough: step 2 — verify", "");
      await sleep(1200);

      // step 2: verify → BROKEN
      get().verifyLoopChain();
      update({ walkthroughStep: 3 });
      get().showToast("walkthrough: step 3 — restore", "");
      await sleep(1500);

      // step 3: restore
      get().restoreReceipt(seq);
      update({ walkthroughStep: 4 });
      get().showToast("walkthrough: step 4 — verify again", "");
      await sleep(1200);

      // step 4: verify → INTACT
      get().verifyLoopChain();
      update({ walkthroughStep: 5 });
      const finalTerm = [...get().term];
      finalTerm.push({ t: "ok", v: "# walkthrough complete · tamper → broken → restore → intact" });
      update({ term: finalTerm.length > 300 ? finalTerm.slice(-300) : finalTerm });
      get().showToast("walkthrough complete", "ok");
      await sleep(2000);
      update({ walkthroughStep: 0 });
    },

    /* ---- file / tab ---- */
    openFile: (view) => {
      const s = get();
      const openTabs = s.openTabs.includes(view) ? s.openTabs : [...s.openTabs, view];
      update({ openTabs, activeTab: view, drawer: s.drawer && typeof window !== "undefined" && window.matchMedia("(max-width:899px)").matches ? null : s.drawer });
    },
    closeTab: (view) => {
      const s = get();
      const idx = s.openTabs.indexOf(view);
      const openTabs = s.openTabs.filter((t) => t !== view);
      let activeTab = s.activeTab;
      if (s.activeTab === view) {
        activeTab = openTabs[idx] ?? openTabs[idx - 1] ?? openTabs[0] ?? null;
      }
      update({ openTabs, activeTab });
    },
    setActive: (view) => update({ activeTab: view }),
    toggleFolder: (path) => {
      const s = get();
      update({ folders: { ...s.folders, [path]: !s.folders[path] } });
    },

    /* ---- drawers ---- */
    toggleDrawer: (name) => {
      const s = get();
      update({ drawer: s.drawer === name ? null : name });
    },
    openDrawer: (name) => update({ drawer: name }),
    closeDrawer: (name) => {
      const s = get();
      if (s.drawer === name) update({ drawer: null });
    },
    closeAllDrawers: () => update({ drawer: null }),

    /* ---- agent ---- */
    sendAgent: (text) => {
      const t = text.trim();
      if (!t) return;
      const s = get();
      const userMsg: ChatMsg = { role: "user", text: t, meta: "you · just now" };
      update({ chat: [...s.chat, userMsg] });
      const reply = agentReply(t);
      setTimeout(() => {
        const cur = get();
        update({
          chat: [
            ...cur.chat,
            { role: "agent", text: reply.text, meta: `vvu-agent · ${reply.tag}` },
          ],
        });
      }, 280);
    },
    clearChat: () => {
      update({ chat: [{ role: "agent", text: "Chat cleared.", meta: "vvu-agent · just now" }] });
    },

    /* ---- terminal ---- */
    runTerminal: (raw) => {
      const s = get();
      const res = runCommand(raw, {
        ledgerLen: s.ledger.length,
        receipts: s.receipts,
        loopCount: s.loopReceipts.length,
        lab1: { count: s.lab1.count, start: s.lab1.start, end: s.lab1.end },
      });
      if (res.clear) {
        get().clearTerm();
        return;
      }
      const term = [...s.term, ...res.lines];
      const trimmed = term.length > 300 ? term.slice(-300) : term;
      update({ term: trimmed });

      if (res.open) {
        get().openFile(res.open);
        if (typeof window !== "undefined" && window.matchMedia("(max-width:899px)").matches) {
          get().closeAllDrawers();
        }
      }
      if (res.lucky) {
        const r = drawLucky(res.lucky);
        update({ lab1: { ...get().lab1, ...res.lucky, last: r } });
        get().showToast(
          r.error ? r.error : res.lucky.seed ? `drew ${r.numbers.length} · seed=${res.lucky.seed}` : `drew ${r.numbers.length} · no seed`,
          r.error ? "err" : "ok",
        );
      }
      if (res.verify) {
        get().verifyChain();
      }
      if (res.loop) {
        get().runLoop();
      }
      if (res.verifyLoop) {
        get().verifyLoopChain();
      }
      if (res.walkthrough) {
        void get().walkthrough();
      }
      if (res.sign) {
        void get().signAllPending();
      }
      if (res.genesis) {
        get().publishGenesis();
      }
      if (res.merkle) {
        const root = get().merkleRootLine();
        const term = [...get().term];
        term.push({ t: "ok", v: `  ${root}` });
        update({ term: term.length > 300 ? term.slice(-300) : term });
      }
      if (res.verifyReceipt) {
        void get().verifyReceiptFull(res.verifyReceipt);
      }
      if (res.exportProof) {
        get().exportReceiptWithProof(res.exportProof);
      }
      if (res.exportBoard) {
        get().exportBoard();
      }
      if (res.verifyHTML) {
        get().exportVerifyHTML(res.verifyHTML);
      }
      if (res.chainHTML) {
        get().exportChainHTML();
      }
    },
    clearTerm: () => {
      update({ term: [{ t: "dim", v: "# cleared" }] });
    },

    /* ---- lab 0 ---- */
    lab0Move: (dx, dy) => {
      const s = get();
      const c = clampLab0(s.lab0.x + dx, s.lab0.y + dy);
      update({ lab0: c });
    },
    lab0Set: (x, y) => {
      const c = clampLab0(x, y);
      update({ lab0: c });
    },
    lab0Reset: () => update({ lab0: { x: -2, y: -1.5 } }),

    /* ---- lab 1 ---- */
    lab1Run: () => {
      const s = get();
      const opts = { count: s.lab1.count, start: s.lab1.start, end: s.lab1.end, seed: s.lab1.seed };
      if (!(opts.end > opts.start)) {
        get().showToast("end must be > start", "err");
        return;
      }
      const r = drawLucky(opts);
      update({ lab1: { ...s.lab1, ...opts, last: r } });
      // terminal side-effect
      const term = [...get().term];
      term.push({ t: "in", v: `lucky --count ${opts.count} --start ${opts.start} --end ${opts.end}${opts.seed ? ` --seed ${opts.seed}` : ""}` });
      if (r.error) {
        term.push({ t: "err", v: r.error });
      } else {
        term.push({ t: "", v: `Hello, ${s.lab1.name}! Your lucky numbers:` });
        for (const n of r.numbers) term.push({ t: "", v: ` - ${n}` });
        term.push({ t: "dim", v: opts.seed ? `# seed: ${opts.seed}` : "# seed: none" });
      }
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast(opts.seed ? `drew ${r.numbers.length} · seed=${opts.seed}` : `drew ${r.numbers.length} · no seed`, r.error ? "err" : "ok");
    },
    lab1Reproduce: () => {
      const s = get();
      if (!s.lab1.seed) {
        get().showToast("no seed to reproduce", "err");
        return;
      }
      const opts = { count: s.lab1.count, start: s.lab1.start, end: s.lab1.end, seed: s.lab1.seed };
      const r = drawLucky(opts);
      update({ lab1: { ...s.lab1, last: r } });
      get().showToast(`reproduced with seed=${s.lab1.seed}`, "ok");
    },
    lab1Reset: () => update({ lab1: { name: "Adael", count: 5, start: 1, end: 50, seed: null, last: null } }),

    /* ---- IVE pipeline ---- */
    iveRun: async () => {
      if (get().iveRunning) return;
      const s = get();
      const stages: IveStage[] = Array.from({ length: 6 }, () => ({ state: "idle" }));
      update({ iveRunning: true, iveStages: stages, iveOut: [{ t: "dim", v: "# run started" }], iveGates: null, iveBadge: null });

      // fresh payload + context (read from DOM is complex; reuse defaults with fresh ts/hour)
      const p: Record<string, string | number> = FRESH_PAYLOAD();
      const ctx: ComputeCtx = {
        conf: 0.72,
        bounds: 0.05,
        author: DEFAULT_AUTHOR,
        diffEdits: 14,
        deliberation: 18,
        presence: true,
        contentHash: "",
      };

      const log = (l: TermLine) => update({ iveOut: [...get().iveOut, l] });
      const setStage = (i: number, state: IveStage["state"]) => {
        const next = get().iveStages.slice();
        next[i] = { state };
        update({ iveStages: next });
      };

      // Stage 1: payload
      setStage(0, "active");
      await sleep(80);
      const canonical = canon(p);
      log({ t: "", v: `payload · ${canonical.length} bytes` });
      setStage(0, "done");
      await sleep(220);

      // Stage 2: contentHash
      setStage(1, "active");
      await sleep(80);
      const contentHash = sha256(canonical);
      ctx.contentHash = contentHash;
      log({ t: "", v: `contentHash = ${contentHash.slice(0, 24)}…` });
      setStage(1, "done");
      await sleep(260);

      // Stage 3: compoundHash
      setStage(2, "active");
      await sleep(80);
      const prevHash = s.ledger.length ? s.ledger[s.ledger.length - 1].receiptHash : ZERO_HASH;
      const compoundHash = sha256(contentHash + "|" + p.utc_ts);
      log({ t: "", v: `compoundHash = ${compoundHash.slice(0, 24)}…` });
      setStage(2, "done");
      await sleep(260);

      // Stage 4: receipt (STUBBED sig)
      setStage(3, "active");
      await sleep(80);
      const sig = sha256(compoundHash + "|mk0-sw");
      log({ t: "warn", v: "receipt · Ed25519 STUBBED" });
      setStage(3, "done");
      await sleep(260);

      // Stage 5: gates
      setStage(4, "active");
      await sleep(80);
      const results = computeGates(p, ctx, s.ledger, Date.now());
      const summary = summariseGates(results);
      log({ t: "", v: `gates · ${summary.pass} pass · ${summary.fail} fail · ${summary.stub} stubbed` });
      setStage(4, "done");
      await sleep(260);

      // Stage 6: WORM append or lock
      setStage(5, "active");
      await sleep(80);
      if (summary.fail === 0) {
        const receiptHash = sha256(prevHash + "|" + contentHash + "|" + p.utc_ts);
        const entry: LedgerEntry = {
          seq: s.ledger.length + 1,
          ts: String(p.utc_ts),
          payload: p,
          canonical,
          contentHash,
          compoundHash,
          prevHash,
          receiptHash,
          sig,
          sigStub: true,
          gatesPass: summary.pass,
          gatesTotal: 13,
          gatesStub: summary.stub,
          gates: results.map((r) => ({ id: r.id, name: r.name, status: r.status })),
          conf: ctx.conf,
          bounds: ctx.bounds,
        };
        const ledger = [...s.ledger, entry];
        update({
          ledger,
          receipts: get().receipts + 1,
          ive: { lastRun: ctx, lastPayload: p },
          iveGates: results,
          iveBadge: "committed",
        });
        log({ t: "ok", v: `ledger · appended #${entry.seq} · ${receiptHash.slice(0, 24)}…` });
        setStage(5, "done");

        const term = [...get().term];
        term.push({ t: "in", v: "run pipeline" });
        term.push({ t: "ok", v: `  appended #${entry.seq} · ${summary.pass} pass · ${summary.stub} stubbed` });
        update({ term: term.length > 300 ? term.slice(-300) : term });
        get().showToast("receipt signed", "ok");
      } else {
        log({ t: "err", v: `COMMIT LOCKED · ${summary.fail} failing` });
        setStage(5, "fail");
        update({ iveGates: results, iveBadge: "locked" });
        const term = [...get().term];
        term.push({ t: "in", v: "run pipeline" });
        term.push({ t: "err", v: `  COMMIT LOCKED · ${summary.fail} failing gate(s)` });
        update({ term: term.length > 300 ? term.slice(-300) : term });
        get().showToast("COMMIT LOCKED", "err");
      }
      update({ iveRunning: false });
    },
    iveReset: () => {
      update({
        ive: { lastRun: null, lastPayload: null },
        iveStages: Array.from({ length: 6 }, () => ({ state: "idle" })),
        iveOut: [],
        iveGates: null,
        iveBadge: null,
      });
      get().showToast("IVE reset");
    },

    /* ---- hash builder ---- */
    doHash: (input) => {
      const raw = input.trim();
      if (!raw) {
        get().showToast("empty input", "err");
        return;
      }
      let parsed: unknown;
      try {
        parsed = JSON.parse(raw);
      } catch (e) {
        const msg = e instanceof Error ? e.message : "parse error";
        update({ hashOut: { canonical: `parse error: ${msg}`, hash: "", bytes: 0 } });
        const term = [...get().term];
        term.push({ t: "in", v: "hash" });
        term.push({ t: "err", v: `  parse error: ${msg}` });
        update({ term: term.length > 300 ? term.slice(-300) : term });
        return;
      }
      const c = canon(parsed);
      const h = sha256(c);
      update({ hashOut: { canonical: c, hash: h, bytes: c.length } });
      const term = [...get().term];
      term.push({ t: "in", v: "hash" });
      term.push({ t: "ok", v: `  ${h}` });
      update({ term: term.length > 300 ? term.slice(-300) : term });
    },
    loadHashSample: () => {
      const p = FRESH_PAYLOAD();
      return JSON.stringify(p, null, 2);
    },

    /* ---- depot ---- */
    evalDepot: (input) => {
      const result = evalDepot(input);
      update({ depotResult: result });
      const term = [...get().term];
      term.push({ t: "in", v: "depot gate" });
      const label = result.pass ? "PASS" : "FAIL";
      term.push({ t: result.pass ? "ok" : "err", v: `  ${label} · cost=R${input.cost} [${input.tier}]` });
      update({ term: term.length > 300 ? term.slice(-300) : term });
    },

    /* ---- ledger ---- */
    verifyChain: () => {
      const s = get();
      if (s.ledger.length === 0) {
        get().showToast("ledger empty");
        return;
      }
      const lines: TermLine[] = [];
      let prev = ZERO_HASH;
      let intact = true;
      for (const e of s.ledger) {
        const expect = sha256(prev + "|" + e.contentHash + "|" + e.ts);
        const good = expect === e.receiptHash && e.prevHash === prev;
        lines.push({
          t: good ? "ok" : "err",
          v: `#${String(e.seq).padStart(3, "0")} ${good ? "OK" : "BROKEN"} ${e.receiptHash.slice(0, 20)}…`,
        });
        if (!good) intact = false;
        prev = e.receiptHash;
      }
      lines.push({ t: intact ? "ok" : "err", v: `# result: ${intact ? "CHAIN INTACT" : "CHAIN BROKEN"}` });
      update({ chainVerify: { lines, intact } });

      const term = [...get().term];
      term.push({ t: "in", v: "verify-chain" });
      term.push({ t: intact ? "ok" : "err", v: `  ${intact ? "CHAIN INTACT" : "CHAIN BROKEN"}` });
      update({ term: term.length > 300 ? term.slice(-300) : term });
      get().showToast(intact ? "CHAIN INTACT" : "CHAIN BROKEN", intact ? "ok" : "err");
    },
    clearLedger: () => {
      if (typeof window !== "undefined" && !window.confirm("Reset the local ledger?")) return;
      update({ ledger: [], receipts: 0, chainVerify: null });
      get().showToast("ledger reset");
    },

    /* ---- watch ---- */
    toggleWatch: () => update({ watchCollapsed: !get().watchCollapsed }),

    /* ---- toast ---- */
    showToast: (msg, kind = "") => {
      const id = Date.now();
      update({ toast: { msg, kind, id } });
      setTimeout(() => {
        if (get().toast?.id === id) update({ toast: null });
      }, 2400);
    },
  };
});

export { GATES, CANON_FIELDS };
