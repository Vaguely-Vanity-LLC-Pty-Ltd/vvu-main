/**
 * VVU · STUDIO — terminal command parser.
 * Returns output lines + optional side-effect descriptors; the caller
 * (Terminal component) dispatches side-effects to the store so the
 * parser stays pure and testable.
 */
import type { TermLine, ViewKey } from "./types";
import { canon, sha256 } from "./crypto";
import { resolveView, allFiles, TAB_META } from "./fs";
import { GATES } from "./gates";
import { drawLucky } from "./labs";

export interface TermResult {
  lines: TermLine[];
  /** open this view in the editor */
  open?: ViewKey;
  /** run a lucky draw */
  lucky?: { count: number; start: number; end: number; seed: string | null };
  /** verify the ledger chain */
  verify?: boolean;
  /** clear the terminal */
  clear?: boolean;
  /** run the loop (capability 1→4) */
  loop?: boolean;
  /** verify the loop receipt chain (capability 6) */
  verifyLoop?: boolean;
  /** run the tamper→broken→restore→intact walkthrough */
  walkthrough?: boolean;
  /** sign all pending receipts with Ed25519 (or honest stub) */
  sign?: boolean;
  /** publish the genesis receipt hash out-of-band */
  genesis?: boolean;
  /** print the merkle root */
  merkle?: boolean;
  /** verify a receipt fully (sig + hashes + merkle proof) */
  verifyReceipt?: number;
  /** export a receipt + its merkle proof */
  exportProof?: number;
  /** export the full public board */
  exportBoard?: boolean;
  /** export a self-verifying HTML page for a receipt */
  verifyHTML?: number;
  /** export a self-verifying HTML page for the full chain */
  chainHTML?: boolean;
}

const HELP_LINES: TermLine[] = [
  { t: "dim", v: "# VVU · STUDIO" },
  { t: "", v: "  help        show commands" },
  { t: "", v: "  loop        run the loop (record → rules → receipt → number)" },
  { t: "", v: "  number      say the current number" },
  { t: "", v: "  verify      verify the receipt chain" },
  { t: "", v: "  merkle      print the merkle root (single commitment)" },
  { t: "", v: "  verify-receipt <seq>  full stranger-verify (sig + hashes + merkle)" },
  { t: "", v: "  export-proof <seq>    export a receipt + its merkle proof" },
  { t: "", v: "  export-board          export the full public board" },
  { t: "", v: "  verify-html <seq>     export a self-verifying HTML page" },
  { t: "", v: "  verify-chain-html     export self-verifying HTML for the WHOLE chain" },
  { t: "", v: "  sign        sign all pending receipts (Ed25519 or stub)" },
  { t: "", v: "  genesis     publish the genesis receipt hash out-of-band" },
  { t: "", v: "  walkthrough tamper → broken → restore → intact demo" },
  { t: "", v: "  open <file> open a file" },
  { t: "", v: "  ls          list files" },
  { t: "", v: "  hash <json> canonicalise + SHA-256" },
  { t: "", v: "  lucky       run lucky numbers" },
  { t: "", v: "  rules       list the rules" },
  { t: "", v: "  depot       depot arithmetic" },
  { t: "", v: "  ledger      ledger summary" },
  { t: "", v: "  clear       clear terminal" },
];

function lsLines(): TermLine[] {
  return [
    { t: "dim", v: "# VVU-STUDIO/" },
    { t: "", v: "  .vvu/  lessons/  labs/  ive/  depot/  receipts/  README.md" },
  ];
}

function gatesLines(): TermLine[] {
  const lines: TermLine[] = [{ t: "dim", v: "# the rules (written down; count irrelevant)" }];
  for (const g of GATES) {
    const status = g.stub ? "STUB" : "OK";
    lines.push({
      t: g.stub ? "warn" : "ok",
      v: `  ${g.id.padEnd(4)} ${status.padEnd(5)} ${g.name}`,
    });
  }
  return lines;
}

function rulesLines(): TermLine[] {
  return gatesLines();
}

function depotLines(): TermLine[] {
  return [
    { t: "dim", v: "# depot gate" },
    { t: "", v: "  PASS = cost > R20,000 AND tier ∈ {T1,T2}" },
    { t: "ok", v: "  PASS → Mk 0.5 · R1,671" },
  ];
}

function ledgerLines(entries: number, receipts: number): TermLine[] {
  return [
    { t: "dim", v: "# ledger" },
    { t: "", v: `  entries: ${entries}` },
    { t: "", v: `  receipts: ${receipts}` },
  ];
}

function hashLines(arg: string): TermLine[] {
  if (!arg) return [{ t: "err", v: "usage: hash '{\"a\":1}'" }];
  let parsed: unknown;
  try {
    parsed = JSON.parse(arg);
  } catch {
    return [{ t: "err", v: "parse error" }];
  }
  const c = canon(parsed);
  const h = sha256(c);
  return [{ t: "ok", v: h }];
}

function luckyLines(opts: { count: number; start: number; end: number; seed: string | null }): {
  lines: TermLine[];
  res: ReturnType<typeof drawLucky>;
} {
  const res = drawLucky(opts);
  const lines: TermLine[] = [];
  if (opts.seed) lines.push({ t: "dim", v: `# lucky --count ${opts.count} --seed ${opts.seed}` });
  if (res.error) {
    lines.push({ t: "err", v: res.error });
  } else {
    lines.push({ t: "", v: "Hello, Adael! Your lucky numbers:" });
    for (const n of res.numbers) lines.push({ t: "", v: ` - ${n}` });
    lines.push({ t: "dim", v: opts.seed ? `# seed: ${opts.seed}` : "# seed: none" });
  }
  return { lines, res };
}

/** Parse a single command string into output + side effects. */
export function runCommand(
  raw: string,
  ctx: { ledgerLen: number; receipts: number; loopCount: number; lab1: { count: number; start: number; end: number } },
): TermResult {
  const cmd = raw.trim();
  if (!cmd) return { lines: [] };
  const parts = cmd.split(/\s+/);
  const base = parts[0].toLowerCase();
  const inLine: TermLine = { t: "in", v: cmd };

  switch (base) {
    case "help":
      return { lines: [inLine, ...HELP_LINES] };

    case "clear":
      return { lines: [], clear: true };

    case "ls":
      return { lines: [inLine, ...lsLines()] };

    case "gates":
      return { lines: [inLine, ...gatesLines()] };

    case "depot":
      return { lines: [inLine, ...depotLines()] };

    case "ledger":
      return { lines: [inLine, ...ledgerLines(ctx.ledgerLen, ctx.receipts)] };

    case "verify":
      return { lines: [inLine], verifyLoop: true };

    case "walkthrough":
      return {
        lines: [inLine, { t: "dim", v: "# capability 6 demo — fail visible, loudly" }],
        walkthrough: true,
      };

    case "loop":
      return {
        lines: [inLine, { t: "dim", v: "# record → run rules → receipt → number" }],
        loop: true,
      };

    case "number":
      return {
        lines: [inLine, { t: "ok", v: `RECEIPTS: ${ctx.loopCount}` }],
      };

    case "merkle":
      return {
        lines: [inLine, { t: "dim", v: "# single commitment over all receipt hashes" }],
        merkle: true,
      };

    case "verify-receipt": {
      const seqArg = parseInt(parts[1] || "", 10);
      if (!seqArg || seqArg < 1) {
        return { lines: [inLine, { t: "err", v: "usage: verify-receipt <seq>" }] };
      }
      return {
        lines: [inLine, { t: "dim", v: `# full stranger-verify of receipt #${seqArg}` }],
        verifyReceipt: seqArg,
      };
    }

    case "export-proof": {
      const seqArg = parseInt(parts[1] || "", 10);
      if (!seqArg || seqArg < 1) {
        return { lines: [inLine, { t: "err", v: "usage: export-proof <seq>" }] };
      }
      return {
        lines: [inLine, { t: "dim", v: `# export receipt #${seqArg} + merkle proof` }],
        exportProof: seqArg,
      };
    }

    case "export-board":
      return {
        lines: [inLine, { t: "dim", v: "# export the full public board (pubKey + merkle root + genesis)" }],
        exportBoard: true,
      };

    case "verify-html": {
      const seqArg = parseInt(parts[1] || "", 10);
      if (!seqArg || seqArg < 1) {
        return { lines: [inLine, { t: "err", v: "usage: verify-html <seq>" }] };
      }
      return {
        lines: [inLine, { t: "dim", v: `# export self-verifying HTML for receipt #${seqArg}` }],
        verifyHTML: seqArg,
      };
    }

    case "verify-chain-html":
      return {
        lines: [inLine, { t: "dim", v: "# export self-verifying HTML for the WHOLE chain" }],
        chainHTML: true,
      };

    case "sign":
      return {
        lines: [inLine, { t: "dim", v: "# sign all pending receipts (Ed25519 or honest stub)" }],
        sign: true,
      };

    case "genesis":
      return {
        lines: [inLine, { t: "dim", v: "# publish the genesis receipt hash out-of-band" }],
        genesis: true,
      };

    case "rules":
      return { lines: [inLine, ...rulesLines()] };

    case "open": {
      if (!parts[1]) return { lines: [inLine, { t: "err", v: "usage: open <file>" }] };
      const view = resolveView(parts.slice(1).join(" "));
      if (!view) return { lines: [inLine, { t: "err", v: `no such file: ${parts.slice(1).join(" ")}` }] };
      return { lines: [inLine, { t: "ok", v: `opened ${TAB_META[view].label}` }], open: view };
    }

    case "hash": {
      const arg = cmd.slice(4).trim();
      const hashOut = hashLines(arg);
      return { lines: [inLine, ...hashOut] };
    }

    case "lucky": {
      const opts = { count: ctx.lab1.count, start: ctx.lab1.start, end: ctx.lab1.end, seed: null as string | null };
      for (let i = 1; i < parts.length; i++) {
        const p = parts[i];
        if (p === "--count" && parts[i + 1]) {
          opts.count = Math.max(1, Math.min(50, parseInt(parts[++i + 0], 10) || opts.count));
        } else if (p === "--seed" && parts[i + 1]) {
          opts.seed = parts[++i];
        } else if (p === "--start" && parts[i + 1]) {
          opts.start = parseInt(parts[++i], 10) || opts.start;
        } else if (p === "--end" && parts[i + 1]) {
          opts.end = parseInt(parts[++i], 10) || opts.end;
        }
      }
      const { lines, res } = luckyLines(opts);
      void res;
      return { lines, lucky: opts };
    }

    default:
      return {
        lines: [
          inLine,
          { t: "err", v: `command not found: ${base}` },
          { t: "dim", v: 'type "help"' },
        ],
      };
  }
}

/** Files for the `ls` summary (unused by parser but kept for completeness). */
export const FILE_LIST = allFiles();
