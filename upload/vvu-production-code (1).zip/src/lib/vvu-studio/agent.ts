/**
 * VVU · STUDIO — the workspace agent.
 * Pattern-matched canned replies (the agent is honest about being canned:
 * it is a guide, not an oracle). Same spirit as the reference.
 */
import type { ChatMsg } from "./types";

export interface AgentReply {
  text: string;
  tag: string;
}

export const SUGGESTIONS = [
  "What are the 13 gates?",
  "How does the depot gate work?",
  "Explain canonical hashing",
  "What is the doctrine?",
  "Why a seed matters",
  "Tier ladder T1–T4",
];

export const SEED_CHAT: ChatMsg[] = [
  { role: "agent", text: "Welcome to **VVU · STUDIO**. I am your workspace agent.", meta: "system · just now" },
  { role: "agent", text: "Ask me about `gates`, `depot`, `hashing`, `doctrine`, or `tiers`.", meta: "system · just now" },
];

interface Rule {
  test: RegExp;
  tag: string;
  text: string;
}

const RULES: Rule[] = [
  {
    test: /gate|l1[0-3]|l[1-9]\b/,
    tag: "gates",
    text:
      "13 gates. Eleven computed; two stubbed and flagged:\n\n" +
      "**Computed:** L1 schema_11_field · L2 author_check · L3 calibration_window · L4 confidence_bounds · " +
      "L5 presence_proof · L6 diff_not_queue · L8 deliberation_15m · L9 duplicate_hash · L10 rate_limit · " +
      "L11 seat_geo_bind · L12 version_lock\n\n" +
      "**Stubbed:** L7 video_checkpoint · L13 ed25519_verify\n\n" +
      "Stubbed gates are visibly distinct — the **Stubbed Gates Flagged** invariant at work.",
  },
  {
    test: /depot|r20|r1,?671|one instrument/,
    tag: "depot",
    text:
      "**ONE INSTRUMENT** — one visit, one instrument, three questions.\n\n" +
      "**Q1** audit/verification cost > R20,000/mo?\n**Q2** visible inefficiency from untrusted telemetry?\n**Q3** read-only tap supported?\n\n" +
      "```\nPASS = cost > R20,000 AND tier ∈ {T1,T2}\nPASS → Mk 0.5 · R1,671\n```\n\n" +
      "A PASS authorises exactly one thing: the build kit.",
  },
  {
    test: /hash|sha|canonical|sorted|receipt/,
    tag: "hashing",
    text:
      "```\n11-field payload → sorted-key JSON → SHA-256\n  → contentHash → receiptHash → WORM append\n```\n\n" +
      "**Why sorted keys?** Two records differing only in key order must produce byte-identical input. " +
      "Otherwise verification becomes a coin flip.",
  },
  {
    test: /doctrine|strong|spoof|perfection/,
    tag: "doctrine",
    text:
      "1. **Computed Gates** — verified by a known path.\n" +
      "2. **Stubbed Gates Flagged** — simulated gates are visually distinct.\n" +
      "3. **Strong = Suspicious** — perfection without a path is a spoofing signature.\n\n" +
      "If it looks perfect, it's spoofed.",
  },
  {
    test: /tier|t1|t2|t3|t4|unverified|undefined/,
    tag: "tiers",
    text:
      "**T1 Computed** — hashes, signatures, code you can run\n" +
      "**T2 Documented** — receipts, invoices, published prices\n" +
      "**T3 Claimed** — stated, not documented · `[UNVERIFIED]`\n" +
      "**T4 Hearsay** — second-hand, uncorroborated\n\n" +
      "Only T1/T2 may **open a gate** or **anchor a claim**.",
  },
  {
    test: /lucky|random|seed|reproduc/,
    tag: "lab1",
    text:
      "A draw without a seed is **T4 hearsay** — nobody can reproduce it. The same draw *with* a seed becomes **T1 computed**.\n\n" +
      "Open `lab1_lucky.py`, set a seed, draw, then press Reproduce — the numbers must match.",
  },
  {
    test: /plane|lab0|coordinate/,
    tag: "lab0",
    text: "`lab0_plane.py` teaches that **numbers are places**. Drag the point to (3, 4).",
  },
  {
    test: /credential|sbt|soulbound|5192/,
    tag: "credential",
    text:
      "ERC-5192 / SBT — bound to the soul, not the wallet.\n\n" +
      "```\nsubmission → signed receipt → Merkle leaf\n  → cohort Merkle root → SBT → Arweave pin\n  → employer verifies by recomputing\n```",
  },
  {
    test: /ledger|worm|append/,
    tag: "ledger",
    text: "The **WORM ledger** is write-once, read-many. Open `ledger.json` and press Verify.",
  },
  {
    test: /help|what can|how do/,
    tag: "help",
    text: "I can help with **gates**, **depot**, **hashing**, **doctrine**, **tiers**, and the **labs**.\n\nOr open a file from the explorer.",
  },
];

const FALLBACK: AgentReply = {
  tag: "default",
  text: "Try asking about **gates**, **depot**, **hashing**, **doctrine**, or **tiers** — or open a file from the explorer.",
};

export function agentReply(q: string): AgentReply {
  const lo = q.toLowerCase();
  for (const r of RULES) {
    if (r.test.test(lo)) return { tag: r.tag, text: r.text };
  }
  return FALLBACK;
}
