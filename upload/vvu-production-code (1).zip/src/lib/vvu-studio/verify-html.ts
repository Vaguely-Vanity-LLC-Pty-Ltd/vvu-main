/**
 * VVU · STUDIO — self-verifying HTML generator.
 *
 * Generates a STANDALONE HTML file a stranger opens in any browser.
 * On load, it re-computes:
 *   1. recordHash = SHA-256(canonical)
 *   2. receiptHash = SHA-256(prev ‖ record ‖ ts)
 *   3. Ed25519 signature verification over recordHash
 *   4. merkle root from receiptHash + proof steps
 * …and shows ✓/✗ for each check. No trust required. No server. No imports.
 */
import type { Receipt, MerkleProofStep } from "./loop";

function hexToBytes(hex: string): number[] {
  const out: number[] = [];
  for (let i = 0; i < hex.length; i += 2) {
    out.push(parseInt(hex.slice(i, i + 2), 16));
  }
  return out;
}

/**
 * Build a self-verifying HTML page for a receipt + its merkle proof.
 * The page embeds the receipt data + proof + published root as JSON,
 * then runs the verification on load using Web Crypto.
 */
export function buildReceiptVerifyHTML(
  receipt: Receipt,
  proof: MerkleProofStep[],
  publishedRoot: string,
): string {
  const data = {
    seq: receipt.seq,
    ts: receipt.ts,
    canonical: receipt.canonical,
    recordHash: receipt.recordHash,
    receiptHash: receipt.receiptHash,
    prevHash: receipt.prevHash,
    sig: receipt.sig,
    sigAlg: receipt.sigAlg,
    sigStub: receipt.sigStub,
    sigPubKey: receipt.sigPubKey,
    verdict: receipt.verdict,
    firstFail: receipt.firstFail,
    merkleProof: proof,
    publishedMerkleRoot: publishedRoot,
  };

  const dataJson = JSON.stringify(data, null, 2);

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>VVU · STUDIO — Self-Verifying Receipt #${receipt.seq}</title>
<style>
  :root {
    --bg: #0b0b0d; --bg2: #101014; --bg3: #141419;
    --border: #1e1e24; --border2: #2a2a32;
    --text: #d4d4d8; --dim: #71717a; --dimmer: #52525b;
    --accent: #34d399; --amber: #fbbf24; --red: #f87171;
    --mono: ui-monospace, SFMono-Regular, Menaco, Monaco, Consolas, monospace;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: Inter, system-ui, sans-serif; font-size: 14px; line-height: 1.5; padding: 24px; }
  .mono { font-family: var(--mono); }
  h1 { font-size: 20px; margin-bottom: 4px; }
  .vk { font-size: 10px; letter-spacing: 0.18em; text-transform: uppercase; color: var(--accent); font-family: var(--mono); }
  .lede { color: var(--text); font-size: 14px; margin: 8px 0 16px; }
  .card { border: 1px solid var(--border); border-radius: 8px; background: var(--bg2); margin-bottom: 16px; }
  .card-head { padding: 8px 12px; border-bottom: 1px solid var(--border); font-family: var(--mono); font-size: 10px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--dim); }
  .card-body { padding: 12px; }
  .row { display: flex; gap: 8px; align-items: center; margin-bottom: 6px; font-size: 12px; }
  .label { font-family: var(--mono); font-size: 10px; text-transform: uppercase; color: var(--dim); min-width: 100px; }
  .val { font-family: var(--mono); font-size: 11px; word-break: break-all; color: var(--text); flex: 1; }
  .check { padding: 8px 12px; border-radius: 6px; margin-bottom: 6px; font-family: var(--mono); font-size: 12px; display: flex; align-items: center; gap: 8px; }
  .check.pass { background: rgba(2,44,34,0.4); border-left: 3px solid var(--accent); color: var(--accent); }
  .check.fail { background: rgba(44,10,10,0.4); border-left: 3px solid var(--red); color: var(--red); }
  .check.pending { background: var(--bg3); border-left: 3px solid var(--dimmer); color: var(--dim); }
  .hash { font-family: var(--mono); font-size: 10px; color: var(--dim); word-break: break-all; margin-left: 24px; margin-top: 2px; }
  .overall { font-size: 16px; font-weight: bold; padding: 12px; border-radius: 8px; text-align: center; margin-bottom: 16px; }
  .overall.pass { background: rgba(2,44,34,0.4); color: var(--accent); border: 1px solid var(--accent); }
  .overall.fail { background: rgba(44,10,10,0.4); color: var(--red); border: 1px solid var(--red); }
  .overall.pending { background: var(--bg3); color: var(--dim); border: 1px solid var(--border2); }
  .badge { font-family: var(--mono); font-size: 9px; text-transform: uppercase; padding: 2px 6px; border-radius: 3px; border: 1px solid var(--border2); }
  .badge.pass { color: var(--accent); border-color: var(--accent); background: rgba(2,44,34,0.3); }
  .badge.fail { color: var(--red); border-color: var(--red); background: rgba(44,10,10,0.3); }
  .badge.stub { color: var(--amber); border-color: var(--amber); background: rgba(44,26,2,0.3); }
  pre { background: var(--bg); border: 1px solid var(--border); border-radius: 6px; padding: 8px; font-family: var(--mono); font-size: 10px; overflow-x: auto; max-height: 200px; overflow-y: auto; color: var(--dim); }
  .spinner { display: inline-block; width: 12px; height: 12px; border: 2px solid var(--dimmer); border-top-color: var(--accent); border-radius: 50%; animation: spin 0.8s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
</style>
</head>
<body>
<div class="vk">VVU · STUDIO — Self-Verifying Receipt</div>
<h1>Receipt #${receipt.seq} · ${receipt.verdict}</h1>
<p class="lede">This page re-computes the signature, hashes, and merkle inclusion proof independently — no trust required. Open it in any browser.</p>

<div id="overall" class="overall pending">
  <span class="spinner"></span> verifying…
</div>

<div class="card">
  <div class="card-head">Receipt Data (embedded)</div>
  <div class="card-body">
    <div class="row"><span class="label">seq</span><span class="val">#${receipt.seq}</span></div>
    <div class="row"><span class="label">timestamp</span><span class="val">${receipt.ts}</span></div>
    <div class="row"><span class="label">verdict</span><span class="val">${receipt.verdict}${receipt.firstFail ? " · first fail: " + receipt.firstFail.id + " " + receipt.firstFail.name + " — " + receipt.firstFail.reason : ""}</span></div>
    <div class="row"><span class="label">sig alg</span><span class="val">${receipt.sigAlg}${receipt.sigStub ? ' <span class="badge stub">stub</span>' : ""}</span></div>
  </div>
</div>

<div class="card">
  <div class="card-head">Verification Checks</div>
  <div class="card-body" id="checks">
    <div class="check pending"><span class="spinner"></span> 1. recordHash = SHA-256(canonical)</div>
    <div class="check pending"><span class="spinner"></span> 2. receiptHash = SHA-256(prev ‖ record ‖ ts)</div>
    <div class="check pending"><span class="spinner"></span> 3. Ed25519 signature over recordHash</div>
    <div class="check pending"><span class="spinner"></span> 4. merkle inclusion proof → root</div>
  </div>
</div>

<div class="card">
  <div class="card-head">Published Merkle Root</div>
  <div class="card-body">
    <div class="val" style="color: var(--accent)">${publishedRoot}</div>
  </div>
</div>

<div class="card">
  <div class="card-head">Canonical Observation</div>
  <div class="card-body">
    <pre>${receipt.canonical.replace(/</g, "&lt;")}</pre>
  </div>
</div>

<div class="card">
  <div class="card-head">Full Receipt JSON</div>
  <div class="card-body">
    <pre>${dataJson.replace(/</g, "&lt;")}</pre>
  </div>
</div>

<script>
const DATA = ${dataJson};
const enc = new TextEncoder();

function hexToBuf(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) bytes[i / 2] = parseInt(hex.slice(i, i + 2), 16);
  return bytes;
}

function bufToHex(buf) {
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}

async function sha256(str) {
  const buf = await crypto.subtle.digest("SHA-256", enc.encode(str));
  return bufToHex(buf);
}

function setCheck(idx, pass, label, expected, actual) {
  const checks = document.getElementById("checks").children;
  const el = checks[idx];
  el.className = "check " + (pass ? "pass" : "fail");
  el.innerHTML = (pass ? "✓" : "✗") + " " + label;
  if (expected !== undefined) {
    const h = document.createElement("div");
    h.className = "hash";
    h.textContent = "expected: " + expected.slice(0, 32) + "…  |  actual: " + (actual || "").slice(0, 32) + "…";
    el.appendChild(h);
  }
}

async function run() {
  let allPass = true;

  // 1. recordHash
  try {
    const recomputedRecord = await sha256(DATA.canonical);
    const pass = recomputedRecord === DATA.recordHash;
    setCheck(0, pass, "1. recordHash = SHA-256(canonical)", recomputedRecord, DATA.recordHash);
    if (!pass) allPass = false;
  } catch (e) {
    setCheck(0, false, "1. recordHash — error: " + e.message);
    allPass = false;
  }

  // 2. receiptHash
  try {
    const recomputedReceipt = await sha256(DATA.prevHash + "|" + DATA.recordHash + "|" + DATA.ts);
    const pass = recomputedReceipt === DATA.receiptHash;
    setCheck(1, pass, "2. receiptHash = SHA-256(prev ‖ record ‖ ts)", recomputedReceipt, DATA.receiptHash);
    if (!pass) allPass = false;
  } catch (e) {
    setCheck(1, false, "2. receiptHash — error: " + e.message);
    allPass = false;
  }

  // 3. Ed25519 signature
  if (DATA.sigAlg === "Ed25519" && DATA.sigPubKey) {
    try {
      const pubKeyBytes = hexToBuf(DATA.sigPubKey);
      const pubKey = await crypto.subtle.importKey("raw", pubKeyBytes, "Ed25519", false, ["verify"]);
      const sigBytes = hexToBuf(DATA.sig);
      const ok = await crypto.subtle.verify("Ed25519", pubKey, sigBytes, enc.encode(DATA.recordHash));
      setCheck(2, ok, "3. Ed25519 signature verifies" + (ok ? "" : " — INVALID"));
      if (!ok) allPass = false;
    } catch (e) {
      setCheck(2, false, "3. Ed25519 verify — error: " + e.message);
      allPass = false;
    }
  } else {
    // stub: recompute HMAC
    const expect = await sha256(DATA.recordHash + "|mk0-sw");
    const pass = expect === DATA.sig;
    setCheck(2, pass, "3. HMAC stub " + (pass ? "matches" : "MISMATCH"), expect, DATA.sig);
    if (!pass) allPass = false;
  }

  // 4. merkle inclusion proof
  if (DATA.merkleProof && DATA.merkleProof.length > 0) {
    try {
      let acc = DATA.receiptHash;
      for (const step of DATA.merkleProof) {
        acc = step.position === "right"
          ? await sha256(acc + step.sibling)
          : await sha256(step.sibling + acc);
      }
      const pass = acc === DATA.publishedMerkleRoot;
      setCheck(3, pass, "4. merkle root from proof " + (pass ? "matches" : "MISMATCH"), acc, DATA.publishedMerkleRoot);
      if (!pass) allPass = false;
    } catch (e) {
      setCheck(3, false, "4. merkle proof — error: " + e.message);
      allPass = false;
    }
  } else {
    // single receipt — leaf IS root
    const pass = DATA.receiptHash === DATA.publishedMerkleRoot;
    setCheck(3, pass, "4. single receipt — receiptHash IS merkle root", DATA.receiptHash, DATA.publishedMerkleRoot);
    if (!pass) allPass = false;
  }

  // overall
  const overall = document.getElementById("overall");
  if (allPass) {
    overall.className = "overall pass";
    overall.textContent = "✓ ALL CHECKS PASS — receipt #" + DATA.seq + " is authentic";
  } else {
    overall.className = "overall fail";
    overall.textContent = "✗ VERIFICATION FAILED — receipt #" + DATA.seq + " is NOT authentic";
  }
}

run();
</script>
</body>
</html>`;
}

/**
 * Build a self-verifying HTML page for the FULL CHAIN — embeds ALL receipts + the
 * merkle tree, then re-verifies every receipt (sig + hashes) + the whole chain
 * (each prevHash links to the previous receiptHash) + the merkle root.
 * A stranger opens ONE file and verifies the entire chain. No trust required.
 */
export function buildChainVerifyHTML(
  receipts: Receipt[],
  merkleRootHash: string,
): string {
  const data = {
    format: "vvu-studio-chain-verify-v1",
    receiptCount: receipts.length,
    receipts: receipts.map((r) => ({
      seq: r.seq,
      ts: r.ts,
      canonical: r.canonical,
      recordHash: r.recordHash,
      receiptHash: r.receiptHash,
      prevHash: r.prevHash,
      sig: r.sig,
      sigAlg: r.sigAlg,
      sigStub: r.sigStub,
      sigPubKey: r.sigPubKey,
      verdict: r.verdict,
      firstFail: r.firstFail,
    })),
    publishedMerkleRoot: merkleRootHash,
  };
  const dataJson = JSON.stringify(data, null, 2);

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>VVU · STUDIO — Self-Verifying Chain (${receipts.length} receipts)</title>
<style>
  :root {
    --bg: #0b0b0d; --bg2: #101014; --bg3: #141419;
    --border: #1e1e24; --border2: #2a2a32;
    --text: #d4d4d8; --dim: #71717a; --dimmer: #52525b;
    --accent: #34d399; --amber: #fbbf24; --red: #f87171; --blue: #569cd6;
    --mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: Inter, system-ui, sans-serif; font-size: 14px; line-height: 1.5; padding: 24px; max-width: 900px; margin: 0 auto; }
  .mono { font-family: var(--mono); }
  h1 { font-size: 20px; margin-bottom: 4px; }
  .vk { font-size: 10px; letter-spacing: 0.18em; text-transform: uppercase; color: var(--accent); font-family: var(--mono); }
  .lede { color: var(--text); font-size: 14px; margin: 8px 0 16px; }
  .card { border: 1px solid var(--border); border-radius: 8px; background: var(--bg2); margin-bottom: 16px; }
  .card-head { padding: 8px 12px; border-bottom: 1px solid var(--border); font-family: var(--mono); font-size: 10px; text-transform: uppercase; letter-spacing: 0.12em; color: var(--dim); display: flex; align-items: center; gap: 8px; }
  .card-body { padding: 12px; }
  .overall { font-size: 16px; font-weight: bold; padding: 14px; border-radius: 8px; text-align: center; margin-bottom: 16px; }
  .overall.pass { background: rgba(2,44,34,0.4); color: var(--accent); border: 1px solid var(--accent); }
  .overall.fail { background: rgba(44,10,10,0.4); color: var(--red); border: 1px solid var(--red); }
  .overall.pending { background: var(--bg3); color: var(--dim); border: 1px solid var(--border2); }
  .receipt-row { display: flex; align-items: center; gap: 8px; padding: 6px 8px; border-bottom: 1px solid var(--border); font-size: 12px; }
  .receipt-row:last-child { border-bottom: none; }
  .receipt-seq { font-family: var(--mono); font-weight: bold; min-width: 36px; color: var(--text); }
  .receipt-verdict { font-family: var(--mono); font-size: 9px; padding: 2px 6px; border-radius: 3px; }
  .receipt-verdict.PASS { color: var(--accent); background: rgba(2,44,34,0.3); }
  .receipt-verdict.FAIL { color: var(--red); background: rgba(44,10,10,0.3); }
  .receipt-verdict.CANT_DECIDE { color: var(--amber); background: rgba(44,26,2,0.3); }
  .receipt-hash { font-family: var(--mono); font-size: 10px; color: var(--accent); flex: 1; word-break: break-all; }
  .receipt-checks { font-family: var(--mono); font-size: 9px; color: var(--dim); display: flex; gap: 6px; }
  .ic { display: inline-block; width: 14px; text-align: center; }
  .ic.pass { color: var(--accent); }
  .ic.fail { color: var(--red); }
  .ic.pending { color: var(--dimmer); }
  .chain-link { font-family: var(--mono); font-size: 10px; padding: 4px 8px; border-radius: 4px; margin-bottom: 4px; display: flex; align-items: center; gap: 8px; }
  .chain-link.pass { background: rgba(2,44,34,0.2); color: var(--accent); }
  .chain-link.fail { background: rgba(44,10,10,0.2); color: var(--red); }
  .badge { font-family: var(--mono); font-size: 9px; text-transform: uppercase; padding: 2px 6px; border-radius: 3px; border: 1px solid var(--border2); }
  .badge.pass { color: var(--accent); border-color: var(--accent); background: rgba(2,44,34,0.3); }
  .badge.fail { color: var(--red); border-color: var(--red); background: rgba(44,10,10,0.3); }
  .badge.stub { color: var(--amber); border-color: var(--amber); background: rgba(44,26,2,0.3); }
  pre { background: var(--bg); border: 1px solid var(--border); border-radius: 6px; padding: 8px; font-family: var(--mono); font-size: 10px; overflow-x: auto; max-height: 200px; overflow-y: auto; color: var(--dim); }
  .spinner { display: inline-block; width: 12px; height: 12px; border: 2px solid var(--dimmer); border-top-color: var(--accent); border-radius: 50%; animation: spin 0.8s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
  .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; margin-bottom: 16px; }
  .stat { text-align: center; padding: 8px; background: var(--bg3); border-radius: 6px; }
  .stat-num { font-family: var(--mono); font-size: 22px; font-weight: bold; color: var(--accent); }
  .stat-lbl { font-family: var(--mono); font-size: 9px; text-transform: uppercase; color: var(--dim); letter-spacing: 0.1em; }
</style>
</head>
<body>
<div class="vk">VVU · STUDIO — Self-Verifying Chain</div>
<h1>Full Chain · ${receipts.length} receipt${receipts.length === 1 ? "" : "s"}</h1>
<p class="lede">This page re-computes every receipt's signature + hashes, verifies each chain link (prevHash → receiptHash), and re-derives the merkle root. Open it in any browser — no trust, no server.</p>

<div id="overall" class="overall pending">
  <span class="spinner"></span> verifying ${receipts.length} receipt${receipts.length === 1 ? "" : "s"}…
</div>

<div class="stats">
  <div class="stat"><div class="stat-num" id="stat-receipts">${receipts.length}</div><div class="stat-lbl">receipts</div></div>
  <div class="stat"><div class="stat-num" id="stat-pass">…</div><div class="stat-lbl">sigs ok</div></div>
  <div class="stat"><div class="stat-num" id="stat-chain">…</div><div class="stat-lbl">chain links</div></div>
  <div class="stat"><div class="stat-num" id="stat-merkle">…</div><div class="stat-lbl">merkle root</div></div>
</div>

<div class="card">
  <div class="card-head">Receipts · each verified independently</div>
  <div class="card-body" id="receipts-list" style="padding: 0;">
    ${receipts.map((r) => `<div class="receipt-row" id="row-${r.seq}">
      <span class="receipt-seq">#${r.seq}</span>
      <span class="receipt-verdict ${r.verdict}">${r.verdict}</span>
      <span class="receipt-hash">${r.recordHash.slice(0, 20)}…</span>
      <span class="receipt-checks">
        <span class="ic pending" id="ic-${r.seq}-rh">…</span><span title="recordHash">rh</span>
        <span class="ic pending" id="ic-${r.seq}-ch">…</span><span title="receiptHash">ch</span>
        <span class="ic pending" id="ic-${r.seq}-sig">…</span><span title="signature">sig</span>
      </span>
    </div>`).join("")}
  </div>
</div>

<div class="card">
  <div class="card-head">Chain Links · each prevHash → previous receiptHash</div>
  <div class="card-body" id="chain-links"></div>
</div>

<div class="card">
  <div class="card-head">Merkle Tree · visual · leaves → root</div>
  <div class="card-body">
    <div id="merkle-tree-container"></div>
    <div style="font-family:var(--mono);font-size:10px;color:var(--dim);margin-top:8px">
      leaves = receiptHashes · internal = SHA-256(left ‖ right) · odd counts duplicate the last · root = single commitment
    </div>
  </div>
</div>

<div class="card">
  <div class="card-head">Merkle Root · re-derived from all receiptHashes</div>
  <div class="card-body" id="merkle-result">…</div>
</div>

<div class="card">
  <div class="card-head">Full Chain JSON (embedded)</div>
  <div class="card-body">
    <pre>${dataJson.replace(/</g, "&lt;")}</pre>
  </div>
</div>

<script>
const DATA = ${dataJson};
const enc = new TextEncoder();

function hexToBuf(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) bytes[i / 2] = parseInt(hex.slice(i, i + 2), 16);
  return bytes;
}

function bufToHex(buf) {
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}

async function sha256(str) {
  const buf = await crypto.subtle.digest("SHA-256", enc.encode(str));
  return bufToHex(buf);
}

function setIc(seq, check, pass) {
  const el = document.getElementById("ic-" + seq + "-" + check);
  if (el) {
    el.className = "ic " + (pass ? "pass" : "fail");
    el.textContent = pass ? "✓" : "✗";
  }
}

async function verifySig(r) {
  if (r.sigAlg === "Ed25519" && r.sigPubKey) {
    try {
      const pubKey = await crypto.subtle.importKey("raw", hexToBuf(r.sigPubKey), "Ed25519", false, ["verify"]);
      return await crypto.subtle.verify("Ed25519", pubKey, hexToBuf(r.sig), enc.encode(r.recordHash));
    } catch (e) {
      return false;
    }
  }
  // stub
  const expect = await sha256(r.recordHash + "|mk0-sw");
  return expect === r.sig;
}

function short(h, n) { return h ? h.slice(0, n) + "…" : "—"; }

function renderMerkleTree(levels, rootOk) {
  const container = document.getElementById("merkle-tree-container");
  if (!container) return;
  const n = levels.length;
  if (n === 0) { container.innerHTML = "empty"; return; }
  const W = 700;
  const H = Math.max(60, 20 + n * 48);
  const nodeR = 7;
  const yFor = (li) => 16 + li * 40;
  const xFor = (li, i) => {
    const count = levels[li].length;
    if (count === 1) return W / 2;
    return (W / (count + 1)) * (i + 1);
  };
  const isRoot = (li) => li === n - 1;
  const isLeaf = (li) => li === 0;
  let svg = '<svg viewBox="0 0 ' + W + " " + H + '" style="width:100%;max-width:700px">';
  // links first (so they're behind nodes)
  for (let li = 0; li < n - 1; li++) {
    for (let i = 0; i < levels[li].length; i++) {
      const x = xFor(li, i), y = yFor(li);
      const parentIdx = Math.floor(i / 2);
      const px = xFor(li + 1, parentIdx), py = yFor(li + 1);
      svg += '<line x1="' + x + '" y1="' + (y + nodeR) + '" x2="' + px + '" y2="' + (py - nodeR) + '" stroke="' + (rootOk ? "var(--accent)" : "var(--red)") + '" stroke-width="1" opacity="0.4"/>';
    }
  }
  // nodes
  for (let li = 0; li < n; li++) {
    for (let i = 0; i < levels[li].length; i++) {
      const x = xFor(li, i), y = yFor(li);
      const root = isRoot(li);
      const leaf = isLeaf(li);
      const fill = root ? "var(--accent)" : leaf ? "var(--bg3)" : "var(--bg2)";
      const stroke = root ? (rootOk ? "var(--accent)" : "var(--red)") : "var(--border2)";
      svg += '<circle cx="' + x + '" cy="' + y + '" r="' + (root ? 9 : nodeR) + '" fill="' + fill + '" stroke="' + stroke + '" stroke-width="' + (root ? 2 : 1.5) + '"/>';
      if (leaf) {
        svg += '<text x="' + x + '" y="' + (y + nodeR + 11) + '" fill="var(--dim)" font-size="8" font-family="monospace" text-anchor="middle">#' + DATA.receipts[i].seq + '</text>';
      } else if (root) {
        svg += '<text x="' + x + '" y="' + (y - 14) + '" fill="' + (rootOk ? "var(--accent)" : "var(--red)") + '" font-size="8" font-family="monospace" text-anchor="middle">root</text>';
        svg += '<text x="' + x + '" y="' + (y + nodeR + 11) + '" fill="' + (rootOk ? "var(--accent)" : "var(--red)") + '" font-size="8" font-family="monospace" text-anchor="middle">' + short(levels[li][i], 12) + '</text>';
      }
    }
  }
  svg += "</svg>";
  container.innerHTML = svg;
}

async function run() {
  let allPass = true;
  let sigsOk = 0;
  let chainLinksOk = 0;

  // verify each receipt
  for (const r of DATA.receipts) {
    // 1. recordHash
    const recomputedRecord = await sha256(r.canonical);
    const rhOk = recomputedRecord === r.recordHash;
    setIc(r.seq, "rh", rhOk);
    if (!rhOk) allPass = false;

    // 2. receiptHash
    const recomputedReceipt = await sha256(r.prevHash + "|" + r.recordHash + "|" + r.ts);
    const chOk = recomputedReceipt === r.receiptHash;
    setIc(r.seq, "ch", chOk);
    if (!chOk) allPass = false;

    // 3. signature
    const sigOk = await verifySig(r);
    setIc(r.seq, "sig", sigOk);
    if (sigOk) sigsOk++;
    else allPass = false;
  }

  // verify chain links (each prevHash === previous receiptHash)
  const linksEl = document.getElementById("chain-links");
  let prev = "0".repeat(64);
  for (let i = 0; i < DATA.receipts.length; i++) {
    const r = DATA.receipts[i];
    const linkOk = r.prevHash === prev;
    const link = document.createElement("div");
    link.className = "chain-link " + (linkOk ? "pass" : "fail");
    link.innerHTML = (linkOk ? "✓" : "✗") + " #" + r.seq + " prevHash " + (linkOk ? "matches" : "MISMATCH") + " → " + r.prevHash.slice(0, 20) + "…";
    linksEl.appendChild(link);
    if (linkOk) chainLinksOk++;
    else allPass = false;
    prev = r.receiptHash;
  }

  // re-derive merkle root (and collect all levels for the tree SVG)
  const treeLevels = [DATA.receipts.map(r => r.receiptHash)];
  let level = DATA.receipts.map(r => r.receiptHash);
  let merkleOk = false;
  let recomputedRoot = level[0] || "0".repeat(64);
  while (level.length > 1) {
    const next = [];
    for (let i = 0; i < level.length; i += 2) {
      const a = level[i];
      const b = i + 1 < level.length ? level[i + 1] : level[i];
      next.push(await sha256(a + b));
    }
    treeLevels.push(next);
    level = next;
  }
  recomputedRoot = level[0] || "0".repeat(64);
  merkleOk = recomputedRoot === DATA.publishedMerkleRoot;
  if (!merkleOk) allPass = false;

  // render the merkle tree SVG
  renderMerkleTree(treeLevels, merkleOk);

  // update stats
  document.getElementById("stat-pass").textContent = sigsOk + "/" + DATA.receipts.length;
  document.getElementById("stat-chain").textContent = chainLinksOk + "/" + DATA.receipts.length;
  document.getElementById("stat-merkle").innerHTML = merkleOk ? '<span style="color:var(--accent)">✓</span>' : '<span style="color:var(--red)">✗</span>';

  // merkle result detail
  document.getElementById("merkle-result").innerHTML =
    '<div style="font-family:var(--mono);font-size:11px;color:var(--dim)">recomputed root:</div>' +
    '<div style="font-family:var(--mono);font-size:11px;word-break:break-all;color:' + (merkleOk ? "var(--accent)" : "var(--red)") + '">' + recomputedRoot + '</div>' +
    '<div style="font-family:var(--mono);font-size:11px;color:var(--dim);margin-top:6px">published root:</div>' +
    '<div style="font-family:var(--mono);font-size:11px;word-break:break-all;color:var(--text)">' + DATA.publishedMerkleRoot + '</div>';

  // overall
  const overall = document.getElementById("overall");
  if (allPass) {
    overall.className = "overall pass";
    overall.textContent = "✓ ALL CHECKS PASS — chain of " + DATA.receipts.length + " receipt" + (DATA.receipts.length === 1 ? "" : "s") + " is authentic";
  } else {
    overall.className = "overall fail";
    overall.textContent = "✗ VERIFICATION FAILED — chain is NOT authentic";
  }
}

run();
</script>
</body>
</html>`;
}

