/**
 * VVU · STUDIO — the six capabilities, as functions.
 *
 * The system does six things. Any order. Any time. On demand.
 *   1. Take in an observation  — recordObservation()
 *   2. Run written-down rules   — runRules()  → PASS / FAIL / CAN'T-DECIDE
 *   3. Produce a receipt        — produceReceipt()  (hash + sig + ts; stranger-verifiable)
 *   4. Say the current number   — readNumber()  (one line: RECEIPTS: N)
 *   5. Close an item by artifact— closeItem()  (no artifact → "no artifact", specific)
 *   6. Fail visibly             — failVisible()  (corrupt/mismatch/can't-decide → loud)
 *
 * The loop: record → run rules → receipt → number → repeat.
 * A receipt is issued in ALL THREE cases. The number goes up.
 * The number going up is the point.
 *
 * The count of rules is irrelevant. What matters: they are written down
 * and deterministic — same input, same rules, same result, for anyone.
 */
import { canon, sha256, ZERO_HASH, nowISO } from "./crypto";
import type { GateResult } from "./types";
import { GATES } from "./gates";

/* ------------------------------------------------------------------ */
/* Capability 1 — Take in an observation                              */
/* ------------------------------------------------------------------ */

/**
 * A plain observation. The fields the user named:
 *   what, where, when, who, how much, source, tier, channel, account, hour, confidence
 * Stored as-is. Not judged. Not smoothed. Not gap-filled.
 */
export interface Observation {
  what: string;
  where: string;
  when: string;
  who: string;
  howMuch: string;
  source: string;
  tier: "T1" | "T2" | "T3" | "T4";
  channel: string;
  account: string;
  hour: string;
  confidence: number; // 0..1
  bounds: number; // ±
}

export const OBSERVATION_FIELDS: { key: keyof Observation; label: string; placeholder: string }[] = [
  { key: "what", label: "what", placeholder: "e.g. high-value transfer to new beneficiary" },
  { key: "where", label: "where", placeholder: "e.g. Sishen Beneficiation / addr 0x…" },
  { key: "when", label: "when", placeholder: "ISO ts; blank = now" },
  { key: "who", label: "who", placeholder: "e.g. A. Mokoena / observer" },
  { key: "howMuch", label: "how much", placeholder: "e.g. R24,000 / 0.42 ETH" },
  { key: "source", label: "source", placeholder: "e.g. on-chain read / field note" },
  { key: "tier", label: "tier", placeholder: "T1 computed · T2 documented · T3 claimed · T4 hearsay" },
  { key: "channel", label: "channel", placeholder: "e.g. STUDENT_SUBMISSION / ALERT" },
  { key: "account", label: "account", placeholder: "e.g. course_cs201 / 0xabc…" },
  { key: "hour", label: "hour", placeholder: "UTC hour 00..23; blank = now" },
  { key: "confidence", label: "confidence", placeholder: "0.0 .. 1.0" },
  { key: "bounds", label: "bounds ±", placeholder: "e.g. 0.05" },
];

export function blankObservation(): Observation {
  return {
    what: "",
    where: "",
    when: "",
    who: "",
    howMuch: "",
    source: "",
    tier: "T3",
    channel: "OBSERVATION",
    account: "",
    hour: "",
    confidence: 0.5,
    bounds: 0.1,
  };
}

/** A concrete, honest default observation (the genesis record). */
export function genesisObservation(): Observation {
  const now = new Date();
  return {
    what: "high-value transfer to a new beneficiary 90s after contact",
    where: "Sishen Beneficiation · seat B12",
    when: now.toISOString().replace(/\.\d{3}Z$/, "Z"),
    who: "observer: A. Mokoena",
    howMuch: "R24,000",
    source: "on-chain read + field note",
    tier: "T2",
    channel: "ALERT",
    account: "0x9f3a…b12e",
    hour: String(now.getUTCHours()).padStart(2, "0"),
    confidence: 0.72,
    bounds: 0.05,
  };
}

/** Canonicalise an observation to a deterministic byte string. */
export function canonicalObservation(o: Observation): string {
  // normalise: blank when/hour → now
  const norm: Observation = {
    ...o,
    when: o.when.trim() || nowISO(),
    hour: o.hour.trim() || String(new Date().getUTCHours()).padStart(2, "0"),
  };
  return canon(norm);
}

/* ------------------------------------------------------------------ */
/* Capability 2 — Run written-down rules                              */
/* ------------------------------------------------------------------ */

export type RuleVerdict = "PASS" | "FAIL" | "CANT_DECIDE";

export interface RuleResult {
  id: string;
  name: string;
  verdict: RuleVerdict;
  /** the first FAILing rule (for the receipt) — null if all PASS */
  reason: string;
  /** whether this rule is a stub (can't-decide by construction) */
  stub: boolean;
}

/**
 * The rules. Written down. Deterministic. Same input → same result.
 * The COUNT is irrelevant (the user's point); what matters is they're
 * published and reproducible by anyone.
 *
 * `enabled` lets a user turn rules off (capability 2: "whatever rules —
 * yours, mine, anyone's"). A disabled rule is skipped entirely — it
 * does not PASS, FAIL, or CAN'T-DECIDE; it's as if it weren't written.
 */
export function runRules(o: Observation, enabled: Record<string, boolean> = {}): RuleResult[] {
  const results: RuleResult[] = [];
  const filled = (s: string) => s.trim().length > 0;
  const isOn = (id: string) => enabled[id] !== false; // default on

  if (isOn("R1")) {
    results.push({
      id: "R1", name: "record_is_complete", stub: false,
      verdict: filled(o.what) && filled(o.where) && filled(o.who) && filled(o.howMuch) ? "PASS" : "FAIL",
      reason: !filled(o.what) ? "no what" : !filled(o.where) ? "no where" : !filled(o.who) ? "no who" : !filled(o.howMuch) ? "no how much" : "complete",
    });
  }

  if (isOn("R2")) {
    results.push({
      id: "R2", name: "source_is_named", stub: false,
      verdict: filled(o.source) ? "PASS" : "FAIL",
      reason: filled(o.source) ? "source named" : "no source",
    });
  }

  if (isOn("R3")) {
    results.push({
      id: "R3", name: "tier_is_evidence_grade", stub: false,
      verdict: o.tier === "T1" || o.tier === "T2" ? "PASS" : "FAIL",
      reason: o.tier === "T1" || o.tier === "T2" ? `tier ${o.tier}` : `tier ${o.tier} — not evidence grade`,
    });
  }

  if (isOn("R4")) {
    results.push({
      id: "R4", name: "confidence_has_bounds", stub: false,
      verdict: o.confidence >= 0.1 && o.confidence <= 0.99 && o.bounds > 0 && o.bounds <= 0.5 ? "PASS" : "FAIL",
      reason: `${o.confidence} ± ${o.bounds}`,
    });
  }

  if (isOn("R5")) {
    results.push({
      id: "R5", name: "timestamp_is_present", stub: false,
      verdict: filled(o.when) ? "PASS" : "FAIL",
      reason: filled(o.when) ? "ts present" : "no timestamp",
    });
  }

  if (isOn("R6")) {
    results.push({
      id: "R6", name: "geo_is_specific", stub: false,
      verdict: filled(o.where) && o.where.length >= 6 ? "PASS" : "FAIL",
      reason: o.where.length >= 6 ? "geo specific" : "geo too vague",
    });
  }

  if (isOn("R7")) {
    results.push({
      id: "R7", name: "video_checkpoint", stub: true,
      verdict: "CANT_DECIDE",
      reason: "stubbed — no video subsystem",
    });
  }

  if (isOn("R8")) {
    results.push({
      id: "R8", name: "deliberation_logged", stub: false,
      verdict: o.hour.trim() !== "" ? "PASS" : "FAIL",
      reason: o.hour.trim() !== "" ? `hour ${o.hour}` : "no hour",
    });
  }

  if (isOn("R9")) {
    results.push({
      id: "R9", name: "signature_verifies", stub: true,
      verdict: "CANT_DECIDE",
      reason: "stubbed — HMAC stand-in for Ed25519",
    });
  }

  return results;
}

/** The canonical list of rule definitions (for the UI / rules view). */
export const RULE_DEFS: { id: string; name: string; stub: boolean; desc: string }[] = [
  { id: "R1", name: "record_is_complete", stub: false, desc: "what / where / who / how much are all present" },
  { id: "R2", name: "source_is_named", stub: false, desc: "the source field is named" },
  { id: "R3", name: "tier_is_evidence_grade", stub: false, desc: "tier is T1 (computed) or T2 (documented)" },
  { id: "R4", name: "confidence_has_bounds", stub: false, desc: "0.1 ≤ confidence ≤ 0.99 · 0 < bounds ≤ 0.5" },
  { id: "R5", name: "timestamp_is_present", stub: false, desc: "the when field is present" },
  { id: "R6", name: "geo_is_specific", stub: false, desc: "where is at least 6 chars" },
  { id: "R7", name: "video_checkpoint", stub: true, desc: "video subsystem — STUBBED, can't decide" },
  { id: "R8", name: "deliberation_logged", stub: false, desc: "the hour field is present" },
  { id: "R9", name: "signature_verifies", stub: true, desc: "Ed25519 signature — STUBBED (HMAC stand-in)" },
];

export function defaultEnabledRules(): Record<string, boolean> {
  const out: Record<string, boolean> = {};
  for (const r of RULE_DEFS) out[r.id] = true;
  return out;
}

/** The first FAILing rule, or null if none. (For the receipt.) */
export function firstFailure(results: RuleResult[]): RuleResult | null {
  return results.find((r) => r.verdict === "FAIL") ?? null;
}

export function summarise(results: RuleResult[]): {
  pass: number; fail: number; cant: number; verdict: "PASS" | "FAIL" | "CANT_DECIDE";
} {
  const pass = results.filter((r) => r.verdict === "PASS").length;
  const fail = results.filter((r) => r.verdict === "FAIL").length;
  const cant = results.filter((r) => r.verdict === "CANT_DECIDE").length;
  // overall verdict: FAIL beats CAN'T_DECIDE beats PASS
  const verdict: "PASS" | "FAIL" | "CANT_DECIDE" = fail > 0 ? "FAIL" : cant > 0 ? "CANT_DECIDE" : "PASS";
  return { pass, fail, cant, verdict };
}

/* ------------------------------------------------------------------ */
/* Capability 3 — Produce a receipt                                   */
/* ------------------------------------------------------------------ */

export interface Receipt {
  seq: number;
  ts: string;
  /** canonical observation bytes */
  canonical: string;
  /** SHA-256 over the canonical observation */
  recordHash: string;
  /** SHA-256(prevHash ‖ recordHash ‖ ts) — the chain link */
  receiptHash: string;
  /** previous receipt hash (genesis = 0×64) */
  prevHash: string;
  /** signature over the recordHash — Ed25519 (real) or HMAC-SHA256 (stub fallback) */
  sig: string;
  /** true if the signature is an HMAC-SHA256 stand-in (Ed25519 unavailable) */
  sigStub: boolean;
  /** the signing algorithm used: "Ed25519" | "HMAC-SHA256" */
  sigAlg: string;
  /** the public key that verifies this signature (hex), if Ed25519 */
  sigPubKey: string | null;
  /** overall verdict for this receipt */
  verdict: "PASS" | "FAIL" | "CANT_DECIDE";
  /** the first failing rule, if any (specific reason on the receipt) */
  firstFail: { id: string; name: string; reason: string } | null;
  /** per-rule verdicts */
  rules: { id: string; name: string; verdict: RuleVerdict; reason: string; stub: boolean }[];
}

/**
 * Build a receipt for an observation + rule results. Always succeeds —
 * a receipt is issued in ALL THREE cases (PASS / FAIL / CAN'T-DECIDE).
 * The number goes up regardless.
 *
 * The signature is filled in later by `signReceipt()` (async, Web Crypto).
 * Until then `sig` is empty + `sigStub: true` as a placeholder.
 */
export function produceReceipt(
  o: Observation,
  results: RuleResult[],
  seq: number,
  prevHash: string,
): Receipt {
  const canonical = canonicalObservation(o);
  const recordHash = sha256(canonical);
  const ts = o.when.trim() || nowISO();
  const receiptHash = sha256(prevHash + "|" + recordHash + "|" + ts);
  const summary = summarise(results);
  const fail = firstFailure(results);
  return {
    seq,
    ts,
    canonical,
    recordHash,
    receiptHash,
    prevHash,
    sig: "",
    sigStub: true, // placeholder until signReceipt() runs
    sigAlg: "pending",
    sigPubKey: null,
    verdict: summary.verdict,
    firstFail: fail ? { id: fail.id, name: fail.name, reason: fail.reason } : null,
    rules: results.map((r) => ({ id: r.id, name: r.name, verdict: r.verdict, reason: r.reason, stub: r.stub })),
  };
}

/* ------------------------------------------------------------------ */
/* Real Ed25519 signature layer (Web Crypto) + IndexedDB persistence  */
/* ------------------------------------------------------------------ */

const enc = new TextEncoder();
const IDB_NAME = "vvu-studio-keys";
const IDB_STORE = "ed25519";
const IDB_KEY = "primary";

/** In-memory cache of the persistent keypair. */
let ed25519KeyPair: { publicKey: CryptoKey; privateKey: CryptoKey } | null = null;
let ed25519PubKeyHex: string | null = null;
let ed25519Available: boolean | null = null;
let keyOrigin: "indexeddb" | "fresh" | null = null;

/** Check whether the browser supports real Ed25519 via Web Crypto. */
export async function isEd25519Available(): Promise<boolean> {
  if (ed25519Available !== null) return ed25519Available;
  try {
    await crypto.subtle.generateKey("Ed25519", false, ["sign", "verify"]);
    ed25519Available = true;
  } catch {
    ed25519Available = false;
  }
  return ed25519Available;
}

/* ---- IndexedDB helpers (CryptoKey objects are structured-cloneable) ---- */

function idbOpen(): Promise<IDBDatabase | null> {
  return new Promise((resolve) => {
    if (typeof indexedDB === "undefined") { resolve(null); return; }
    try {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) db.createObjectStore(IDB_STORE);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function idbGet(db: IDBDatabase, key: string): Promise<unknown> {
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, "readonly");
      const req = tx.objectStore(IDB_STORE).get(key);
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function idbPut(db: IDBDatabase, key: string, value: unknown): Promise<boolean> {
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, "readwrite");
      tx.objectStore(IDB_STORE).put(value, key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

/**
 * Get (or lazily generate + persist) the Ed25519 keypair.
 * The keypair is stored in IndexedDB so it survives reload — a stranger
 * verifying a past receipt sees the same pubKey across sessions.
 */
async function ensureEd25519Key(): Promise<{ publicKey: CryptoKey; privateKey: CryptoKey; pubHex: string; origin: "indexeddb" | "fresh" }> {
  if (ed25519KeyPair && ed25519PubKeyHex && keyOrigin) {
    return { ...ed25519KeyPair, pubHex: ed25519PubKeyHex, origin: keyOrigin };
  }

  // try loading the persisted keypair from IndexedDB
  const db = await idbOpen();
  if (db) {
    const stored = await idbGet(db, IDB_KEY) as { publicKey: CryptoKey; privateKey: CryptoKey } | null;
    if (stored && stored.publicKey && stored.privateKey) {
      try {
        const raw = await crypto.subtle.exportKey("raw", stored.publicKey);
        ed25519KeyPair = stored;
        ed25519PubKeyHex = bufToHex(raw);
        keyOrigin = "indexeddb";
        db.close();
        return { ...stored, pubHex: ed25519PubKeyHex, origin: "indexeddb" };
      } catch {
        // stored key unusable — fall through to generate fresh
      }
    }
  }

  // generate a fresh keypair + persist it
  const pair = await crypto.subtle.generateKey("Ed25519", false, ["sign", "verify"]);
  ed25519KeyPair = pair as { publicKey: CryptoKey; privateKey: CryptoKey };
  const raw = await crypto.subtle.exportKey("raw", ed25519KeyPair.publicKey);
  ed25519PubKeyHex = bufToHex(raw);
  keyOrigin = "fresh";

  if (db) {
    await idbPut(db, IDB_KEY, ed25519KeyPair);
    db.close();
  }
  return { ...ed25519KeyPair, pubHex: ed25519PubKeyHex, origin: "fresh" };
}

/** The current pubKey hex (null if not yet generated). For the UI indicator. */
export function currentPubKeyHex(): string | null {
  return ed25519PubKeyHex;
}

/** The current key origin (null if not yet generated). For the UI indicator. */
export function currentKeyOrigin(): "indexeddb" | "fresh" | null {
  return keyOrigin;
}

function bufToHex(buf: ArrayBuffer): string {
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

/**
 * Sign a receipt's recordHash with real Ed25519 (if available) or fall back
 * to the honest HMAC-SHA256 stub. Updates the receipt in place + returns it.
 */
export async function signReceipt(r: Receipt): Promise<Receipt> {
  const available = await isEd25519Available();
  if (available) {
    try {
      const { privateKey, pubHex } = await ensureEd25519Key();
      const sigBuf = await crypto.subtle.sign("Ed25519", privateKey, enc.encode(r.recordHash));
      return { ...r, sig: bufToHex(sigBuf), sigStub: false, sigAlg: "Ed25519", sigPubKey: pubHex };
    } catch {
      // fall through to stub
    }
  }
  // honest stub fallback: HMAC-SHA256 over the recordHash
  return { ...r, sig: sha256(r.recordHash + "|mk0-sw"), sigStub: true, sigAlg: "HMAC-SHA256", sigPubKey: null };
}

/**
 * Stranger-verify a receipt's signature independently (capability 3).
 * Recomputes the hashes + verifies the signature against the public key.
 */
export async function strangerVerifySig(r: { recordHash: string; sig: string; sigAlg: string; sigPubKey: string | null; sigStub: boolean }): Promise<{ ok: boolean; detail: string }> {
  if (r.sigAlg === "Ed25519" && r.sigPubKey) {
    try {
      const pubKeyBytes = Uint8Array.from((r.sigPubKey.match(/.{2}/g) ?? []).map((h) => parseInt(h, 16)));
      const pubKey = await crypto.subtle.importKey("raw", pubKeyBytes, "Ed25519", false, ["verify"]);
      const sigBytes = Uint8Array.from((r.sig.match(/.{2}/g) ?? []).map((h) => parseInt(h, 16)));
      const ok = await crypto.subtle.verify("Ed25519", pubKey, sigBytes, enc.encode(r.recordHash));
      return { ok, detail: ok ? "Ed25519 signature verifies" : "Ed25519 signature INVALID" };
    } catch (e) {
      return { ok: false, detail: `Ed25519 verify error: ${e instanceof Error ? e.message : "unknown"}` };
    }
  }
  // stub: recompute HMAC
  const expect = sha256(r.recordHash + "|mk0-sw");
  const ok = expect === r.sig;
  return { ok, detail: ok ? "HMAC stub matches" : "HMAC stub MISMATCH" };
}

/* ------------------------------------------------------------------ */
/* Capability 4 — Say the current number                              */
/* ------------------------------------------------------------------ */

export function readNumber(receipts: unknown[]): string {
  return `RECEIPTS: ${receipts.length}`;
}

/* ------------------------------------------------------------------ */
/* Capability 5 — Close an open item by producing the artifact       */
/* ------------------------------------------------------------------ */

export interface OpenItem {
  id: string;
  title: string;
  /** the artifact required to close this item */
  artifactRequired: string;
  /** the artifact produced (closes the item), or null if still open */
  artifactProduced: string | null;
  /** SHA-256 of the artifact content — recorded on the close receipt */
  artifactHash: string | null;
  /** the receipt seq that closed it (if closed) */
  closedBySeq: number | null;
  closedAt: string | null;
}

export function closeItem(
  item: OpenItem,
  artifact: string | null,
  seq: number,
): OpenItem {
  // No artifact → stays open, reason is specific: "no artifact"
  if (!artifact || artifact.trim() === "") {
    return { ...item, artifactProduced: null, artifactHash: null, closedBySeq: null, closedAt: null };
  }
  const content = artifact.trim();
  return {
    ...item,
    artifactProduced: content,
    artifactHash: sha256(content),
    closedBySeq: seq,
    closedAt: nowISO(),
  };
}

/** Default open items (capability 5 demo). Each closes by producing its artifact. */
export function defaultOpenItems(): OpenItem[] {
  return [
    { id: "I1", title: "Discovery report — Sishen pilot", artifactRequired: "discovery_report.md", artifactProduced: null, artifactHash: null, closedBySeq: null, closedAt: null },
    { id: "I2", title: "3-case live demonstration artifacts", artifactRequired: "demo_clean.json + demo_suspicious.json + demo_highrisk.json", artifactProduced: null, artifactHash: null, closedBySeq: null, closedAt: null },
    { id: "I3", title: "Final pilot evidence report", artifactRequired: "evidence_report.pdf", artifactProduced: null, artifactHash: null, closedBySeq: null, closedAt: null },
  ];
}

/**
 * Build an observation for a capability-5 close action. The artifact hash
 * is embedded in the `howMuch` field so it's part of the canonical
 * observation → part of the recordHash → verifiable by a stranger.
 * The close is backed by a real receipt.
 */
export function buildCloseObservation(item: OpenItem, artifactContent: string): Observation {
  const hash = sha256(artifactContent.trim());
  return {
    what: `close item ${item.id} · ${item.title}`,
    where: `item ${item.id}`,
    when: "",
    who: "operator",
    howMuch: `artifact hash: ${hash}`,
    source: `artifact: ${item.artifactRequired}`,
    tier: "T2",
    channel: "ITEM_CLOSE",
    account: item.id,
    hour: "",
    confidence: 0.95,
    bounds: 0.05,
  };
}

/* ------------------------------------------------------------------ */
/* Capability 6 — Fail visibly                                       */
/* ------------------------------------------------------------------ */

export interface FailureReport {
  kind: "CORRUPT_RECORD" | "HASH_MISMATCH" | "RULE_CANT_DECIDE" | "CHAIN_BROKEN" | "NO_ARTIFACT";
  message: string;
  at: string; // where in the loop
  loud: true; // always loud — no silent fallback
}

/** Verify a receipt chain. Any mismatch = CHAIN BROKEN, loudly. */
export function verifyChain(receipts: Receipt[]): { intact: boolean; failures: FailureReport[] } {
  const failures: FailureReport[] = [];
  let prev = ZERO_HASH;
  let intact = true;
  for (const r of receipts) {
    if (r.prevHash !== prev) {
      failures.push({ kind: "CHAIN_BROKEN", message: `receipt #${r.seq} prevHash mismatch`, at: `chain link ${r.seq}`, loud: true });
      intact = false;
    }
    const expect = sha256(prev + "|" + r.recordHash + "|" + r.ts);
    if (expect !== r.receiptHash) {
      failures.push({ kind: "HASH_MISMATCH", message: `receipt #${r.seq} receiptHash mismatch`, at: `chain link ${r.seq}`, loud: true });
      intact = false;
    }
    prev = r.receiptHash;
  }
  return { intact, failures };
}

/**
 * Tamper with a receipt — flip a byte in its recordHash (capability 6 demo).
 * The next verify will scream HASH_MISMATCH loudly. No silent fallback.
 * Returns the tampered receipt (the caller replaces the stored one).
 */
export function tamperReceipt(receipt: Receipt, kind: "recordHash" | "receiptHash" = "recordHash"): Receipt {
  const field = kind;
  const h = receipt[field];
  // flip the first hex char to a different value
  const firstChar = h[0];
  const flipped = firstChar === "0" ? "1" : "0";
  return {
    ...receipt,
    [field]: flipped + h.slice(1),
  };
}

/**
 * Stranger-verify a single receipt INDEPENDENTLY (capability 3 test).
 * Given a receipt + its claimed previous hash, recompute:
 *   recordHash = SHA-256(canonical observation)
 *   receiptHash = SHA-256(prevHash ‖ recordHash ‖ ts)
 * and compare. Returns a loud, specific verdict — no trust required.
 */
export interface StrangerVerifyInput {
  canonical: string;
  ts: string;
  recordHash: string;
  receiptHash: string;
  prevHash: string;
  seq: number;
}

export interface StrangerVerifyResult {
  ok: boolean;
  checks: { name: string; expected: string; actual: string; pass: boolean }[];
  failures: FailureReport[];
}

export function strangerVerify(input: StrangerVerifyInput): StrangerVerifyResult {
  const checks: StrangerVerifyResult["checks"] = [];
  const failures: FailureReport[] = [];

  // recompute recordHash from the canonical bytes
  const recomputedRecord = sha256(input.canonical);
  checks.push({
    name: `recordHash = SHA-256(canonical)`,
    expected: recomputedRecord,
    actual: input.recordHash,
    pass: recomputedRecord === input.recordHash,
  });
  if (recomputedRecord !== input.recordHash) {
    failures.push({ kind: "HASH_MISMATCH", message: `receipt #${input.seq} recordHash does not match the canonical bytes`, at: "stranger-verify", loud: true });
  }

  // recompute receiptHash from prevHash ‖ recordHash ‖ ts
  const recomputedReceipt = sha256(input.prevHash + "|" + input.recordHash + "|" + input.ts);
  checks.push({
    name: `receiptHash = SHA-256(prev ‖ record ‖ ts)`,
    expected: recomputedReceipt,
    actual: input.receiptHash,
    pass: recomputedReceipt === input.receiptHash,
  });
  if (recomputedReceipt !== input.receiptHash) {
    failures.push({ kind: "HASH_MISMATCH", message: `receipt #${input.seq} receiptHash does not match the recomputed chain link`, at: "stranger-verify", loud: true });
  }

  return { ok: failures.length === 0, checks, failures };
}

/** Recompute what a receipt's receiptHash SHOULD be (for restore / re-verify). */
export function recomputeReceiptHash(r: Receipt): string {
  return sha256(r.prevHash + "|" + r.recordHash + "|" + r.ts);
}

/* ------------------------------------------------------------------ */
/* Merkle root — a single commitment over all receipts                */
/* ------------------------------------------------------------------ */

/**
 * Bitcoin-style merkle root over the receipt hashes.
 * Duplicate-last on odd counts. Genesis (empty) = 0×64.
 * This is the single commitment a stranger can compare against out-of-band.
 */
export function merkleRoot(receipts: Receipt[]): string {
  if (receipts.length === 0) return ZERO_HASH;
  let level = receipts.map((r) => r.receiptHash);
  while (level.length > 1) {
    const next: string[] = [];
    for (let i = 0; i < level.length; i += 2) {
      const a = level[i];
      const b = i + 1 < level.length ? level[i + 1] : level[i]; // duplicate last on odd
      next.push(sha256(a + b));
    }
    level = next;
  }
  return level[0];
}

/** Build the merkle tree levels (for visualisation). Each level is an array of hashes. */
export function merkleTree(receipts: Receipt[]): string[][] {
  if (receipts.length === 0) return [[ZERO_HASH]];
  const levels: string[][] = [receipts.map((r) => r.receiptHash)];
  while (levels[levels.length - 1].length > 1) {
    const prev = levels[levels.length - 1];
    const next: string[] = [];
    for (let i = 0; i < prev.length; i += 2) {
      const a = prev[i];
      const b = i + 1 < prev.length ? prev[i + 1] : prev[i];
      next.push(sha256(a + b));
    }
    levels.push(next);
  }
  return levels;
}

/**
 * Merkle inclusion proof for receipt at `index`. Returns the sibling hashes
 * at each level (with left/right position) so a stranger can recompute the
 * root from a single receipt's receiptHash + this proof.
 */
export interface MerkleProofStep {
  sibling: string;
  position: "left" | "right";
}
export function merkleProof(receipts: Receipt[], index: number): MerkleProofStep[] {
  if (receipts.length === 0 || index < 0 || index >= receipts.length) return [];
  const steps: MerkleProofStep[] = [];
  let level = receipts.map((r) => r.receiptHash);
  let idx = index;
  while (level.length > 1) {
    const next: string[] = [];
    let siblingIdx: number;
    if (idx % 2 === 0) {
      // I am left; sibling is right (or duplicate of me if I'm the last odd)
      siblingIdx = idx + 1 < level.length ? idx + 1 : idx;
      steps.push({ sibling: level[siblingIdx], position: "right" });
    } else {
      // I am right; sibling is left
      siblingIdx = idx - 1;
      steps.push({ sibling: level[siblingIdx], position: "left" });
    }
    for (let i = 0; i < level.length; i += 2) {
      const a = level[i];
      const b = i + 1 < level.length ? level[i + 1] : level[i];
      next.push(sha256(a + b));
    }
    level = next;
    idx = Math.floor(idx / 2);
  }
  return steps;
}

/**
 * Verify a merkle inclusion proof: recompute the root from a leaf hash + the proof steps.
 * Returns the recomputed root (compare against the published merkle root).
 */
export function verifyMerkleProof(leafHash: string, steps: MerkleProofStep[]): string {
  let acc = leafHash;
  for (const step of steps) {
    acc = step.position === "right" ? sha256(acc + step.sibling) : sha256(step.sibling + acc);
  }
  return acc;
}

/** Public re-exports for the UI. */
export { GATES };
export type { GateResult };
