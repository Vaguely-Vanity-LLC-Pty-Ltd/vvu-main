/**
 * VVU · STUDIO — lab logic: deterministic lucky draw + depot gate arithmetic.
 */

/* ---------------- Lab 1: lucky numbers ---------------- */

/** LCG-based seeded PRNG so a draw is reproducible (T1, not T4 hearsay). */
export function seededRandom(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

export interface DrawOpts {
  count: number;
  start: number;
  end: number;
  seed: string | null;
}

export interface DrawResult {
  numbers: number[];
  seedUsed: string | null;
  error?: string;
}

/** Fisher-Yates shuffle of [start..end], take first `count`, sort ascending. */
export function drawLucky(opts: DrawOpts): DrawResult {
  const { count, start, end, seed } = opts;
  if (!(end > start)) return { numbers: [], seedUsed: seed ?? null, error: "end must be > start" };
  if (count < 1) return { numbers: [], seedUsed: seed ?? null, error: "count must be >= 1" };

  const pool: number[] = [];
  for (let i = start; i <= end; i++) pool.push(i);

  const rng = seed && seed.trim() !== "" ? seededRandom(Number(seed)) : Math.random;

  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = pool[i];
    pool[i] = pool[j];
    pool[j] = tmp;
  }
  const picked = pool.slice(0, Math.min(count, pool.length)).sort((a, b) => a - b);
  return { numbers: picked, seedUsed: seed && seed.trim() !== "" ? seed : null };
}

/* ---------------- Lab 0: plane move ---------------- */

export const LAB0_TARGET = { x: 3, y: 4 };
export const LAB0_X_MIN = -6.5;
export const LAB0_X_MAX = 6.5;
export const LAB0_Y_MIN = -4;
export const LAB0_Y_MAX = 4.5;

export function clampLab0(x: number, y: number) {
  return {
    x: Math.max(LAB0_X_MIN, Math.min(LAB0_X_MAX, x)),
    y: Math.max(LAB0_Y_MIN, Math.min(LAB0_Y_MAX, y)),
  };
}

export function lab0AtTarget(x: number, y: number) {
  return Math.abs(x - LAB0_TARGET.x) < 0.05 && Math.abs(y - LAB0_TARGET.y) < 0.05;
}

/* ---------------- Depot gate ---------------- */

export interface DepotInput {
  cost: number;
  tier: "T1" | "T2" | "T3" | "T4";
  q2: boolean;
  q3: boolean;
}

export interface DepotResult {
  pass: boolean;
  finOk: boolean;
  tierOk: boolean;
  q2: boolean;
  q3: boolean;
}

export function evalDepot(d: DepotInput): DepotResult {
  const finOk = d.cost > 20000;
  const tierOk = d.tier === "T1" || d.tier === "T2";
  const pass = finOk && tierOk && d.q2 && d.q3;
  return { pass, finOk, tierOk, q2: d.q2, q3: d.q3 };
}

export const DEPOT_DEFAULTS = {
  date: () => new Date().toISOString().slice(0, 10),
  depot: "Sishen Beneficiation",
  role: "observer",
  owner: "A. Mokoena",
  cost: 24000,
  tier: "T2" as const,
  q2: true,
  q3: true,
};
