/**
 * Apinator realtime client — replaces socket.io for Vercel serverless.
 *
 * Client-side usage:
 *   import { initRealtime } from "@/lib/realtime";
 *   const client = initRealtime();
 *   const channel = client.subscribe("telemetry");
 *   channel.bind("telemetry:update", (data) => { ... });
 *
 * Server-side (in API routes):
 *   import { publish } from "@/lib/realtime";
 *   await publish("telemetry", "telemetry:update", { gridLoad: 42.5 });
 */

const APP_ID = "53cd1754-56eb-4711-b006-612e38724875";
const APP_KEY = "app_129060d2a83c30bb63a3d5ca143970a26a5c4936";
const APP_SECRET = process.env.APINATOR_SECRET || "4eca9e26e063b94bdfe6b23142cdaf8422c886ccbab2638560de80d2ff8a005b";
const CLUSTER = "eu";

export const REALTIME_CONFIG = {
  appKey: APP_KEY,
  cluster: CLUSTER,
  authEndpoint: "/api/realtime/auth",
  wsUrl: "wss://ws-eu.apinator.io",
};

// Server-side publish helper
export async function publish(
  channel: string,
  event: string,
  data: unknown
): Promise<boolean> {
  try {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_URL || ""}/api/realtime/trigger`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name: event, channel, data }),
      }
    );
    return res.ok;
  } catch {
    return false;
  }
}

// Client-side initialization
let clientInstance: any = null;

export function initRealtime() {
  if (typeof window === "undefined") return null;
  if (clientInstance) return clientInstance;

  // Dynamically import the client SDK (browser-only)
  import("@apinator/client").then(({ Apinator }) => {
    clientInstance = new Apinator(REALTIME_CONFIG);
    clientInstance.connect();
  });

  return clientInstance;
}
