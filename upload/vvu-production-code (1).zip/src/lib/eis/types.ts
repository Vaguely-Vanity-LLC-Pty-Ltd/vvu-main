// EIS — Epistemic Intelligence Specification
// types.ts — all shared types + constants for the 5-theorem verification substrate.
//
//   Theorem 1: Evidence Bound        Claim ≤ Evidence ≤ Verification ≤ Authorization ≤ Action
//   Theorem 2: N_ind Participation  N_ind = (Σλ_i)² / Σλ_i²
//   Theorem 3: Heat-Kernel Diffusion u_t = −κ L u  (L = D − A)
//   Theorem 4: State-Lattice Closure state(c) = max { state(e) } capped by claimType
//   Theorem 5: Fail-Closed          loss of E → loss of V → loss of A → breaker trips

export type VerificationState =
  | "PROVEN"
  | "VERIFIED"
  | "SUPPORTED"
  | "OBSERVED"
  | "INCONCLUSIVE"
  | "FALSIFIED"
  | "UNVALIDATED"
  | "UNTESTED"
  | "STALE";

export type ClaimType = "mathematical" | "semantic" | "empirical" | "operational";

export type EvidenceSource = "you.com" | "brave" | "firecrawl" | "watchdog";

export type EstateKey = "canonical" | "hbk-mk2" | "skylantern";

export interface AuthorizationConjuncts {
  claimOk: boolean;
  evidenceOk: boolean;
  integrityOk: boolean;
  safetyOk: boolean;
  reviewOk: boolean;
}

export interface AuthorizationResult extends AuthorizationConjuncts {
  authorized: boolean;
  reason: string;
}

export interface ParticipationRatioResult {
  nInd: number;
  numEvidence: number;
  numSources: number;
  gamma: number;
  eigenvalues: number[];
}

export interface HeatKernelStep {
  step: number;
  l2Norm: number;
  highFreqEnergy: number;
  nodeValues: number[];
}

export interface HeatKernelResult {
  steps: HeatKernelStep[];
  finalL2Norm: number;
  finalHighFreqEnergy: number;
  retention: number;
}

export type CircuitBreakerReason =
  | "evidence_lost"
  | "verification_failed"
  | "safety_violation"
  | "stale_evidence"
  | "integrity_breach";

export interface CircuitBreakerEvent {
  triggered: boolean;
  reason: CircuitBreakerReason | "";
  trippedAt: Date;
}

// --- DB-record interfaces (Date fields become ISO strings over the wire) ---

export interface EvidenceItem {
  id: string;
  claimId: string;
  source: EvidenceSource;
  content: string;
  embedding: number[];
  weight: number;
  state: VerificationState;
  collectedAt: string;
}

export interface AuthorizationRecord extends AuthorizationResult {
  id: string;
  claimId: string;
  createdAt: string;
}

export interface CircuitBreakerRecord {
  id: string;
  claimId: string;
  triggered: boolean;
  reason: CircuitBreakerReason | "";
  trippedAt: string;
}

export interface NIndRecord {
  id: string;
  claimId: string;
  numEvidence: number;
  numSources: number;
  nInd: number;
  gamma: number;
  eigenvalues: number[];
  createdAt: string;
}

export interface ClaimWithRelations {
  id: string;
  title: string;
  description: string;
  claimType: ClaimType;
  state: VerificationState;
  intendedAction: string;
  safetyCritical: boolean;
  estateId: string | null;
  estateKey: EstateKey;
  createdAt: string;
  updatedAt: string;
  evidence: EvidenceItem[];
  authorizations: AuthorizationRecord[];
  circuitEvents: CircuitBreakerRecord[];
  nIndRecords: NIndRecord[];
}

// --- Constants ---

export const STATE_RANK: Record<VerificationState, number> = {
  PROVEN: 8,
  VERIFIED: 7,
  SUPPORTED: 6,
  OBSERVED: 5,
  INCONCLUSIVE: 4,
  UNVALIDATED: 2,
  UNTESTED: 1,
  STALE: 0,
  FALSIFIED: -1,
};

export const AUTH_THRESHOLD: VerificationState = "SUPPORTED";

export const CLAIM_TYPE_RANK: Record<ClaimType, number> = {
  mathematical: 4,
  semantic: 3,
  empirical: 2,
  operational: 1,
};

export const EVIDENCE_SOURCES: EvidenceSource[] = [
  "you.com",
  "brave",
  "firecrawl",
  "watchdog",
];

export const STATE_DESCRIPTIONS: Record<VerificationState, string> = {
  PROVEN: "Formal proof exists; the claim is established beyond the evidence lattice.",
  VERIFIED: "Cross-source corroboration at semantic + mathematical level.",
  SUPPORTED: "Multiple independent sources agree; no contradiction.",
  OBSERVED: "At least one source reports it; no corroboration yet.",
  INCONCLUSIVE: "Evidence is ambiguous or self-contradictory.",
  UNVALIDATED: "Collected but no verification step has run.",
  UNTESTED: "No evidence has been ingested for this claim.",
  STALE: "Previously verified but the evidence bound has decayed.",
  FALSIFIED: "A source reports the negation; terminal denial state.",
};

export const EVIDENCE_BOUND = "Claim ≤ Evidence ≤ Verification ≤ Authorization ≤ Action";
export const AUTHORIZATION_FORMULA = "A = C ∧ E ∧ I ∧ S ∧ R";
