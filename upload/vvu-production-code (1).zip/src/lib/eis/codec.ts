/**
 * EIS codec — deterministic canonical encoding of the 11-field payload.
 * Zero ambiguity before hashing: fixed width, big-endian, scaled integers.
 */
import type { EISPayload } from "./types";

/** Pack firmware Major.Minor.Patch into one u8 (major 2b · minor 3b · patch 3b). */
export function packFirmware(major: number, minor: number, patch: number): number {
  return ((major & 0x3) << 6) | ((minor & 0x7) << 3) | (patch & 0x7);
}

/** Unpack a firmware u8 back into human-readable "v Major.Minor.Patch". */
export function unpackFirmware(u8: number): string {
  const major = (u8 >> 6) & 0x3;
  const minor = (u8 >> 3) & 0x7;
  const patch = u8 & 0x7;
  return `v${major}.${minor}.${patch}`;
}

/** Degrees → i64 scaled integer (× 1e7). */
export function scaleCoord(deg: number): number {
  return Math.round(deg * 1e7);
}

/** i64 scaled integer (× 1e7) → degrees. */
export function unscaleCoord(scaled: number): number {
  return scaled / 1e7;
}

function hexPad(value: bigint | number, bytes: number): string {
  let h = BigInt(value).toString(16);
  if (h.length > bytes * 2) h = h.slice(-bytes * 2); // wrap like fixed-width truncation
  return h.padStart(bytes * 2, "0");
}

/** Signed i64 to two's-complement 64-bit BigInt. */
function toSigned64(n: number): bigint {
  const b = BigInt(n) & ((1n << 64n) - 1n);
  return b;
}

/**
 * Canonical byte-string of fields [0..9] (signature excluded — one signs the
 * body, then appends field 10). Returned as lowercase hex for display and
 * hashing. This is the deterministic pre-image of the block hash.
 */
export function canonicalBodyHex(p: EISPayload): string {
  const parts: string[] = [
    hexPad(p.timestamp, 8), // [0] u64
    hexPad(p.sensorId, 4), // [1] u32
    hexPad(p.firmware, 1), // [2] u8
    hexPad(p.calEpoch, 4), // [3] u32
    hexPad(toSigned64(p.lat), 8), // [4] i64
    hexPad(toSigned64(p.lon), 8), // [5] i64
    hexPad(p.valType, 1), // [6] u8
    p.rawHex.padStart(64, "0").toLowerCase(), // [7] u256
    p.locHash.padStart(64, "0").toLowerCase(), // [8] u256
    p.prevHash.padStart(64, "0").toLowerCase(), // [9] u256
  ];
  return parts.join("");
}

/** Human-readable trace of each encoded field (for the payload inspector). */
export function encodedFieldHexes(p: EISPayload): string[] {
  return [
    hexPad(p.timestamp, 8),
    hexPad(p.sensorId, 4),
    hexPad(p.firmware, 1),
    hexPad(p.calEpoch, 4),
    hexPad(toSigned64(p.lat), 8),
    hexPad(toSigned64(p.lon), 8),
    hexPad(p.valType, 1),
    p.rawHex.padStart(64, "0").toLowerCase(),
    p.locHash.padStart(64, "0").toLowerCase(),
    p.prevHash.padStart(64, "0").toLowerCase(),
    p.sig ?? "-".repeat(64),
  ];
}

/** Encode a float reading (e.g. 40.0 °C) into the first 256 bits as raw bytes. */
export function readingToRawHex(reading: number, unitTag: string): string {
  const tag = Array.from(unitTag).map((c) => c.charCodeAt(0).toString(16).padStart(2, "0")).join("");
  const val = Math.round(reading * 100).toString(16).padStart(8, "0");
  return (val + tag).padEnd(64, "0").slice(0, 64);
}

/** Decode display value back out of Raw_Hex (inverse of readingToRawHex). */
export function rawHexToReading(rawHex: string): number | null {
  if (/^0+$/.test(rawHex)) return null;
  const val = parseInt(rawHex.slice(0, 8), 16);
  if (Number.isNaN(val)) return null;
  return val / 100;
}

export function shortHash(h: string, n = 8): string {
  return `${h.slice(0, n)}…${h.slice(-4)}`;
}
