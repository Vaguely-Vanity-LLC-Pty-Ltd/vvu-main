// Estate-aware seed data for the canonical IVE dashboard.
// Three estates: canonical (IVE native) + hbk-mk2 + skylantern.
// Each estate contributes a handful of representative claims that flow
// through the canonical verification pipeline.

import type { ClaimType, EstateKey, VerificationState } from "./types";

export interface SeedClaimSpec {
  title: string;
  description: string;
  claimType: ClaimType;
  intendedAction: string;
  safetyCritical: boolean;
  estateKey: EstateKey;
  // sourceStates — explicit per-source verification states for the seeded
  // evidence (lets us demonstrate the lattice cap + the fail-closed breaker).
  sourceStates?: Partial<Record<"you.com" | "brave" | "firecrawl" | "watchdog", VerificationState>>;
  seed: number;
}

export const ESTATE_META: Record<
  EstateKey,
  { name: string; description: string; accent: string; theorem: string }
> = {
  canonical: {
    name: "Canonical IVE",
    description:
      "The Integrated Verification Environment's native demonstration claims — the 5-theorem substrate.",
    accent: "emerald",
    theorem: "Theorem 1 · Evidence Bound",
  },
  "hbk-mk2": {
    name: "HBK Mk-II Estate",
    description:
      "HBK Mk-II Proof Spatial Intelligence — governance / research / commercialisation evidence with WORM hash-chained telemetry.",
    accent: "amber",
    theorem: "Theorem 5 · Fail-Closed Operation",
  },
  skylantern: {
    name: "Skylantern Estate",
    description:
      "Skylantern pilot-readiness pack — governance / pricing / compliance evidence for the lantern festival pilot programme.",
    accent: "cyan",
    theorem: "Theorem 4 · State-Lattice Closure",
  },
};

export const SEED_CLAIMS: SeedClaimSpec[] = [
  // --- canonical (3 demo claims from the skill spec) ---
  {
    title: "GPT-5 model output meets accuracy SLA",
    description:
      "Empirical claim: the GPT-5 production model meets the documented accuracy SLA on the held-out evaluation suite.",
    claimType: "empirical",
    intendedAction: "deploy to production",
    safetyCritical: true,
    estateKey: "canonical",
    sourceStates: { firecrawl: "SUPPORTED", watchdog: "SUPPORTED", brave: "OBSERVED" },
    seed: 117,
  },
  {
    title: "Riemann Hypothesis is decidable in ZFC",
    description:
      "Mathematical claim: RH is decidable within ZFC set theory. Demonstrates the claim-type cap — even strong evidence only reaches OBSERVED under the mathematical cap unless a proof exists.",
    claimType: "mathematical",
    intendedAction: "publish theorem",
    safetyCritical: false,
    estateKey: "canonical",
    sourceStates: { "you.com": "OBSERVED", brave: "OBSERVED" },
    seed: 234,
  },
  {
    title: "Edge latency under 50ms p99",
    description:
      "Operational claim: edge-node p99 latency is under 50ms for the metropolitan mesh. Demonstrates operational cap + fail-closed when N_ind < threshold.",
    claimType: "operational",
    intendedAction: "expand edge footprint",
    safetyCritical: true,
    estateKey: "canonical",
    sourceStates: { watchdog: "OBSERVED" },
    seed: 351,
  },

  // --- HBK Mk-II estate (governance / research / commercialisation) ---
  {
    title: "HBK R3 deliverable — digital isolator schematic signed off",
    description:
      "Governance claim: the HBK Mk-II R3 hardware deliverable (digital isolator schematic + transient sampling rate spec) is signed by the responsible engineer and registered with a gate ID.",
    claimType: "operational",
    intendedAction: "release R3 gate",
    safetyCritical: true,
    estateKey: "hbk-mk2",
    sourceStates: { firecrawl: "SUPPORTED", watchdog: "VERIFIED", brave: "OBSERVED" },
    seed: 412,
  },
  {
    title: "WORM hash chain is tamper-evident across the R0–R3 spine",
    description:
      "Empirical claim: the ProofBridge WORM ledger hash chain is continuous and tamper-evident from R0 through R3. Each event links to the previous by SHA-256.",
    claimType: "empirical",
    intendedAction: "publish audit receipt",
    safetyCritical: true,
    estateKey: "hbk-mk2",
    sourceStates: { watchdog: "SUPPORTED", firecrawl: "SUPPORTED", brave: "SUPPORTED" },
    seed: 423,
  },
  {
    title: "CityTwin3D telemetry node ESP32-S3-HUB-01 reports within SLA",
    description:
      "Operational claim: spatial telemetry node ESP32-S3-HUB-01 reports acoustic + tank levels within the 1.5s tick SLA for the metropolitan mesh.",
    claimType: "operational",
    intendedAction: "promote node to production",
    safetyCritical: true,
    estateKey: "hbk-mk2",
    sourceStates: { watchdog: "OBSERVED" },
    seed: 434,
  },

  // --- Skylantern estate (governance / pricing / compliance) ---
  {
    title: "Skylantern pilot pricing tier reconciles with CIPC and SARS",
    description:
      "Compliance claim: the Skylantern pilot pricing tier reconciles with CIPC registration and SARS tax-compliance thresholds for the festival programme.",
    claimType: "semantic",
    intendedAction: "open pilot intake",
    safetyCritical: false,
    estateKey: "skylantern",
    sourceStates: { "you.com": "VERIFIED", brave: "VERIFIED", firecrawl: "SUPPORTED" },
    seed: 517,
  },
  {
    title: "Skylantern intake form captures B-BBEE ESD contributor status",
    description:
      "Governance claim: the Skylantern intake form (05_INTAKE) captures the B-BBEE ESD contributor status and supporting documents for each pilot customer.",
    claimType: "semantic",
    intendedAction: "publish intake template",
    safetyCritical: false,
    estateKey: "skylantern",
    sourceStates: { "you.com": "SUPPORTED", brave: "SUPPORTED", firecrawl: "VERIFIED" },
    seed: 528,
  },
  {
    title: "Skylantern ops runbook covers lantern-launch safety perimeter",
    description:
      "Operational claim: the Skylantern ops runbook (07_OPS) documents the lantern-launch safety perimeter, crowd-density cap, and wind-abort threshold for the pilot launches.",
    claimType: "operational",
    intendedAction: "approve launch window",
    safetyCritical: true,
    estateKey: "skylantern",
    sourceStates: { watchdog: "OBSERVED", firecrawl: "OBSERVED" },
    seed: 539,
  },
];
