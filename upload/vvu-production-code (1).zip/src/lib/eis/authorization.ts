// EIS — authorization.ts (Theorems 1, 4, 5)
//
//   A = C ∧ E ∧ I ∧ S ∧ R
//
//   C — claim state ≥ SUPPORTED (and not FALSIFIED)
//   E — evidence ≥ 1 item AND (≥ 2 distinct sources OR ≥ 3 items)
//   I — N_ind ≥ (safetyCritical ? 2 : 1) − 0.3  (tolerance for estimator bias)
//   S — safetyCritical ? safetyOverride === true : true
//   R — safetyCritical ? reviewSignedOff === true : true
//
// If any conjunct is false, A is false and the action is blocked (fail-closed).

import {
  AUTH_THRESHOLD,
  type AuthorizationResult,
  type ClaimType,
  type EvidenceItem,
  type VerificationState,
} from "./types";
import { computeClaimState, stateAtLeast } from "./state-lattice";
import { distinctSources } from "./evidence-mesh";

export interface AuthorizationInput {
  claimType: ClaimType;
  claimState: VerificationState;
  evidence: EvidenceItem[];
  nInd: number;
  safetyCritical: boolean;
  safetyOverride?: boolean;
  reviewSignedOff?: boolean;
}

export function evaluateAuthorization(input: AuthorizationInput): AuthorizationResult {
  const {
    claimType,
    claimState,
    evidence,
    nInd,
    safetyCritical,
    safetyOverride = false,
    reviewSignedOff = false,
  } = input;

  // C — claim state is at least SUPPORTED (and not FALSIFIED).
  const claimOk = claimState !== "FALSIFIED" && stateAtLeast(claimState, AUTH_THRESHOLD);

  // E — at least one evidence item AND (≥2 distinct sources OR ≥3 items).
  const sources = distinctSources(evidence);
  const evidenceOk = evidence.length >= 1 && (sources.length >= 2 || evidence.length >= 3);

  // I — N_ind ≥ threshold − 0.3 (tolerance for estimator bias).
  const iThreshold = (safetyCritical ? 2 : 1) - 0.3;
  const integrityOk = nInd >= iThreshold;

  // S — safety override required when safety-critical.
  const safetyOk = safetyCritical ? safetyOverride === true : true;

  // R — reviewer sign-off required when safety-critical.
  const reviewOk = safetyCritical ? reviewSignedOff === true : true;

  const authorized = claimOk && evidenceOk && integrityOk && safetyOk && reviewOk;
  const failed: string[] = [];
  if (!claimOk) failed.push("C");
  if (!evidenceOk) failed.push("E");
  if (!integrityOk) failed.push("I");
  if (!safetyOk) failed.push("S");
  if (!reviewOk) failed.push("R");

  const reason = authorized
    ? "A = C∧E∧I∧S∧R = true — all conjuncts satisfied"
    : `A = C∧E∧I∧S∧R = false — failed: ${failed.join(", ")}`;

  return { claimOk, evidenceOk, integrityOk, safetyOk, reviewOk, authorized, reason };
}

// Used by /api/authorize to lift the claim state if evidence changed since verify.
export function recomputeClaimState(
  claimType: ClaimType,
  evidence: EvidenceItem[],
): VerificationState {
  return computeClaimState(claimType, evidence.map((e) => e.state));
}
