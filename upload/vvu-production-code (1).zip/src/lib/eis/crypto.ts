/**
 * EIS crypto layer — runs 100% client-side via the Web Crypto API.
 *
 * ⚠ PROTOTYPE HONESTY NOTE (the system flags its own stubs — M0 Doctrine):
 *   EIS v1.0 specifies Ed25519 (ed25519-dalek). Browser Ed25519 via
 *   SubtleCrypto is not yet universal, so this prototype signs with
 *   HMAC-SHA256 held in a non-extractable CryptoKey vault. The signature
 *   layer is therefore flagged as STUBBED by the Paranoia Bar itself.
 *   Production swaps `signBody`/`verifySig` for Ed25519 without touching
 *   the chain logic — the hash chain (SHA-256) is fully real.
 */
import { canonicalBodyHex } from "./codec";
import type { ChainLinkReport, ChainReport, EISPayload } from "./types";
import { ZERO_HASH } from "./types";

const enc = new TextEncoder();

/** Real SHA-256 over a hex/utf8 string → 64-char lowercase hex. */
export async function sha256Hex(input: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", enc.encode(input));
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** SHA-256 of the spatial context → Loc_Hash (field 8). */
export async function locHash(latDeg: number, lonDeg: number, radiusM: number): Promise<string> {
  return sha256Hex(`EIS-SPATIAL|${latDeg.toFixed(7)}|${lonDeg.toFixed(7)}|${radiusM}`);
}

/* ------------------------------------------------------------------ */
/* Key vault: non-extractable HMAC keys standing in for Ed25519 keys. */
/* ------------------------------------------------------------------ */

const keyVault = new Map<string, CryptoKey>();

export async function ensureKey(keyId: string): Promise<CryptoKey> {
  let k = keyVault.get(keyId);
  if (!k) {
    k = await crypto.subtle.generateKey({ name: "HMAC", hash: "SHA-256" }, false, [
      "sign",
      "verify",
    ]);
    keyVault.set(keyId, k);
  }
  return k;
}

/** Sign the canonical body (fields 0–9). Returns hex signature. */
export async function signBody(payload: EISPayload, keyId: string): Promise<string> {
  const key = await ensureKey(keyId);
  const mac = await crypto.subtle.sign("HMAC", key, enc.encode(canonicalBodyHex(payload)));
  return Array.from(new Uint8Array(mac))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** Verify field-10 signature against a key id. `null` sig → invalid. */
export async function verifySig(payload: EISPayload, keyId: string): Promise<boolean> {
  if (payload.sig === null) return false;
  const key = await ensureKey(keyId);
  const sigBytes = Uint8Array.from(
    (payload.sig.match(/.{2}/g) ?? []).map((h) => parseInt(h, 16)),
  );
  return crypto.subtle.verify("HMAC", key, sigBytes, enc.encode(canonicalBodyHex(payload)));
}

/* ------------------------------------------------------------------ */
/* The deterministic audit chain.                                      */
/* ------------------------------------------------------------------ */

/** Recompute the block hash of a payload (SHA-256 over canonical body). */
export async function blockHash(p: EISPayload): Promise<string> {
  return sha256Hex(canonicalBodyHex(p));
}

/**
 * Build a chain in order: each payload's Prev_Hash is set to the previous
 * block's computed hash, then signed. Returns the payloads and their hashes.
 */
export async function buildChain(
  payloads: Omit<EISPayload, "prevHash" | "sig">[],
  keyOf: (sensorId: number) => string,
): Promise<{ chain: EISPayload[]; hashes: string[] }> {
  const chain: EISPayload[] = [];
  const hashes: string[] = [];
  let prev = ZERO_HASH;
  for (const partial of payloads) {
    const p: EISPayload = { ...partial, prevHash: prev, sig: null };
    const sig = p.valType === 2 ? null : await signBody(p, keyOf(p.sensorId));
    p.sig = sig;
    const h = await blockHash(p);
    chain.push(p);
    hashes.push(h);
    prev = h;
  }
  return { chain, hashes };
}

/**
 * Verify a chain locally — THE core paranoia routine.
 * For every block: recompute hash, compare against the next block's
 * Prev_Hash, and re-verify the signature. Any mismatch = CRITICAL FAILURE.
 */
export async function verifyChain(
  chain: EISPayload[],
  keyOf: (sensorId: number) => string,
): Promise<ChainReport> {
  const links: ChainLinkReport[] = [];
  let intact = true;
  let breakIndex: number | null = null;
  let computed = 0;

  for (let i = 0; i < chain.length; i++) {
    const p = chain[i];
    const h = await blockHash(p);
    computed++;
    const storedPrevOfNext = i + 1 < chain.length ? chain[i + 1].prevHash : null;
    const linkOk = storedPrevOfNext === null || storedPrevOfNext === h;
    const sigValid =
      p.valType === 2 ? (p.sig === null ? true : false) : await verifySig(p, keyOf(p.sensorId));
    links.push({ index: i, sensorId: p.sensorId, computedHash: h, storedPrevOfNext, sigValid, intact: linkOk && sigValid });
    if ((!linkOk || !sigValid) && intact) {
      intact = false;
      breakIndex = i;
    }
  }
  return { intact, breakIndex, links, computed };
}

/**
 * Merkle root over verified payload hashes (binary tree, duplicate-last on
 * odd counts — Bitcoin style). Used as the SBT's evidence commitment.
 */
export async function merkleRoot(hashes: string[]): Promise<string> {
  if (hashes.length === 0) return ZERO_HASH;
  let level = [...hashes];
  while (level.length > 1) {
    const next: string[] = [];
    for (let i = 0; i < level.length; i += 2) {
      const a = level[i];
      const b = i + 1 < level.length ? level[i + 1] : level[i];
      next.push(await sha256Hex(a + b));
    }
    level = next;
  }
  return level[0];
}
