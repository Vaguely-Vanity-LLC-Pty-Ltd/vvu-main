/**
 * Deterministic genesis scenario — "The Intervention".
 *
 * Campus: Nelson Mandela University (NMU), Gqeberha, South Africa.
 * The challenge:  Sensor A says 40.0 °C. Sensor B (same spot) says 40.0 °C.
 *                 Sensor C (acoustic) is OFFLINE.
 * The trap:       the student tries to "fix" the missing data by averaging.
 * The lesson:     correlated echoes cap at 0.2 — go find orthogonal evidence.
 */
import { VAL_TYPE } from "./types";
import type { EISPayload, SensorMeta } from "./types";
import { packFirmware, readingToRawHex, scaleCoord } from "./codec";

/** NMU Missionvale campus, Gqeberha — thermal cluster. */
export const SITE_THERMAL = { lat: -33.929102, lon: 25.570077, radiusM: 6 };
/** NMU North campus — acoustic sensor (offline). */
export const SITE_ACOUSTIC = { lat: -33.961234, lon: 25.626443, radiusM: 10 };
/** Remote spectral station ~800 m from the thermal cluster. */
export const SITE_SPECTRAL = { lat: -33.934521, lon: 25.564102, radiusM: 15 };

/** Fixed epoch so the genesis ledger is byte-identical on every boot.
 *  2025-10-20T22:40:00Z expressed in nanoseconds (u64). */
const T0 = 1_761_000_000_000_000_000n;
const NS = 1_000_000_000n;
const CAL = 1_760_400_000; // calibration epoch (2025-10-14)

export const SENSORS: Record<string, SensorMeta> = {
  A: {
    id: 0x0a1b2c3d,
    name: "THRM-A",
    modality: "THERMAL",
    label: "Thermal · Missionvale rooftop",
    distanceM: 0,
    reading: 40.0,
    unit: "°C",
  },
  B: {
    id: 0x0a1b2c3e,
    name: "THRM-B",
    modality: "THERMAL",
    label: "Thermal · 4 m from A (same mast)",
    distanceM: 4,
    reading: 40.0,
    unit: "°C",
  },
  C: {
    id: 0x07d30000,
    name: "ACOU-C",
    modality: "ACOUSTIC",
    label: "Acoustic · North campus — OFFLINE",
    distanceM: 3800,
    reading: null,
    unit: "dB",
  },
  D: {
    id: 0x5e9a1100,
    name: "SPEC-D",
    modality: "SPECTRAL",
    label: "Spectral · independent station, ~820 m",
    distanceM: 820,
    reading: 41.2,
    unit: "°C(eq)",
  },
};

/** Key ids for the (stubbed) signature vault. */
export const keyOf = (sensorId: number): string => `sensor:${sensorId.toString(16)}`;

/** Genesis payloads (Prev_Hash/Sig filled by buildChain at boot). */
export function genesisPayloads(locHashes: Record<string, string>): Omit<EISPayload, "prevHash" | "sig">[] {
  return [
    {
      timestamp: T0 + 0n * NS,
      sensorId: SENSORS.A.id,
      firmware: packFirmware(1, 4, 2),
      calEpoch: CAL,
      lat: scaleCoord(SITE_THERMAL.lat),
      lon: scaleCoord(SITE_THERMAL.lon),
      valType: VAL_TYPE.RAW,
      rawHex: readingToRawHex(40.0, "C"),
      locHash: locHashes.A,
    },
    {
      timestamp: T0 + 1n * NS,
      sensorId: SENSORS.B.id,
      firmware: packFirmware(1, 4, 2),
      calEpoch: CAL,
      lat: scaleCoord(SITE_THERMAL.lat + 0.000036), // ~4 m north
      lon: scaleCoord(SITE_THERMAL.lon),
      valType: VAL_TYPE.RAW,
      rawHex: readingToRawHex(40.0, "C"),
      locHash: locHashes.B,
    },
    {
      timestamp: T0 + 2n * NS,
      sensorId: SENSORS.C.id,
      firmware: packFirmware(0, 9, 7),
      calEpoch: CAL - 86_400 * 30,
      lat: scaleCoord(SITE_ACOUSTIC.lat),
      lon: scaleCoord(SITE_ACOUSTIC.lon),
      valType: VAL_TYPE.UNDEFINED,
      rawHex: "0".repeat(64),
      locHash: locHashes.C,
    },
  ];
}

/** The independent spectral source the student must request. */
export function spectralPayload(locHash: string, prevHash: string): Omit<EISPayload, "prevHash" | "sig"> {
  return {
    timestamp: T0 + 4n * NS,
    sensorId: SENSORS.D.id,
    firmware: packFirmware(2, 0, 1),
    calEpoch: CAL - 86_400 * 3,
    lat: scaleCoord(SITE_SPECTRAL.lat),
    lon: scaleCoord(SITE_SPECTRAL.lon),
    valType: VAL_TYPE.RAW,
    rawHex: readingToRawHex(41.2, "S"),
    locHash: locHash,
  };
}

/** Student code displayed in the embedded editor for the Zero-Fab trap. */
export const STUDENT_SCRIPT = `# student_evidence.py — close the acoustic gap
from ledger import fetch, average, submit

sensor_a = fetch("THRM-A")        # 40.0 C, RAW, sig OK
sensor_b = fetch("THRM-B")        # 40.0 C, RAW, sig OK
sensor_c = fetch("ACOU-C")        # OFFLINE -> UNDEFINED

# OPTION 1 — fill the hole:
missing = average(sensor_a, sensor_b)
submit(missing, val_type=PROCESSED)`;

/** ERC-5192 minimal SBT contract shown in the Credential Lab. */
export const SBT_CONTRACT = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title IVE_Credential — ERC-5192 Soulbound Evidence Token
/// @notice Minted only when the evidence graph verifies on-chain.
contract IVE_Credential is ERC-721, ERC-5192 {
    address public immutable issuer;      // VVU registry
    mapping(uint256 => bytes32) public evidenceRoot; // merkle root per token
    mapping(uint256 => string) public arweaveTx;     // permanent pin
    mapping(uint256 => bool) public revoked;

    error NotIssuer();
    error EvidenceUnproven();
    error TokenLocked();

    modifier onlyIssuer() {
        if (msg.sender != issuer) revert NotIssuer();
        _;
    }

    /// @notice Grading is binary. No partial credit.
    function mint(address student, bytes32 root, string calldata arweaveId)
        external onlyIssuer returns (uint256 tokenId)
    {
        if (root == bytes32(0)) revert EvidenceUnproven();
        tokenId = uint256(root);
        _safeMint(student, tokenId);
        evidenceRoot[tokenId] = root;
        arweaveTx[tokenId] = arweaveId;
        emit Locked(tokenId);
    }

    /// @notice ERC-5192 — the token never leaves the student.
    function locked(uint256 tokenId) public view override returns (bool) {
        return _exists(tokenId) && !revoked[tokenId];
    }

    /// @notice Revocation path for post-audit (issuer only).
    function revoke(uint256 tokenId) external onlyIssuer {
        revoked[tokenId] = true;
        emit Unlocked(tokenId);
    }

    function _update(address to, uint256 tokenId, address auth)
        internal override returns (address)
    {
        if (to != address(0)) revert TokenLocked();
        return super._update(to, tokenId, auth);
    }
}`;
