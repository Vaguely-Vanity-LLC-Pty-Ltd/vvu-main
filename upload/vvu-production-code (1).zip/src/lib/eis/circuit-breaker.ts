// EIS — circuit-breaker.ts (Theorem 5: Fail-Closed Operation)
//
//   Loss of E → loss of V → loss of A → breaker trips.
//   When tripped, all authorization is revoked until reverification
//   restores the evidence bound.
//
//   shouldTripBreaker inspects a snapshot of the verification state and
//   decides whether the breaker must trip (and for what reason).
//
//   isTripped inspects the persisted event log and returns the latest
//   triggered state (false if empty).

import type { CircuitBreakerEvent, CircuitBreakerReason, VerificationState } from "./types";

export interface CircuitBreakerInput {
  evidenceCount: number;
  previousEvidenceCount: number;
  claimState: VerificationState;
  safetyCritical: boolean;
  safetyOk: boolean;
  nInd: number;
  integrityThreshold: number;
  lastEvidenceAt: number; // epoch ms
  stalenessMs: number; // max age before stale
}

export function shouldTripBreaker(
  input: CircuitBreakerInput,
): { trip: boolean; reason: CircuitBreakerReason | "" } {
  // 1. evidence_lost — count went to zero.
  if (input.evidenceCount < input.previousEvidenceCount && input.evidenceCount === 0) {
    return { trip: true, reason: "evidence_lost" };
  }
  // 2. verification_failed — claim is falsified / stale / untested.
  if (
    input.claimState === "FALSIFIED" ||
    input.claimState === "STALE" ||
    input.claimState === "UNTESTED"
  ) {
    return { trip: true, reason: "verification_failed" };
  }
  // 3. safety_violation — safety-critical but safety not ok.
  if (input.safetyCritical && !input.safetyOk) {
    return { trip: true, reason: "safety_violation" };
  }
  // 4. integrity_breach — N_ind below threshold − 0.5.
  if (input.nInd < input.integrityThreshold - 0.5) {
    return { trip: true, reason: "integrity_breach" };
  }
  // 5. stale_evidence — age > staleness and still has evidence.
  if (
    Date.now() - input.lastEvidenceAt > input.stalenessMs &&
    input.evidenceCount > 0
  ) {
    return { trip: true, reason: "stale_evidence" };
  }
  return { trip: false, reason: "" };
}

export function isTripped(events: CircuitBreakerEvent[]): boolean {
  if (events.length === 0) return false;
  const sorted = [...events].sort(
    (a, b) => b.trippedAt.getTime() - a.trippedAt.getTime(),
  );
  return sorted[0].triggered;
}

export function describeBreakerReason(reason: CircuitBreakerReason | ""): string {
  switch (reason) {
    case "evidence_lost":
      return "Evidence Lost";
    case "verification_failed":
      return "Verification Failed";
    case "safety_violation":
      return "Safety Violation";
    case "stale_evidence":
      return "Stale Evidence";
    case "integrity_breach":
      return "Integrity Breach";
    default:
      return "—";
  }
}
