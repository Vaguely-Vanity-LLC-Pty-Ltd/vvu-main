// EIS — state-lattice.ts (Theorem 4: Verification State Lattice)
//
// The lattice order:
//   PROVEN ≥ VERIFIED ≥ SUPPORTED ≥ OBSERVED ≥ INCONCLUSIVE
//   UNVALIDATED, UNTESTED, STALE are weak/neutral; FALSIFIED is incomparable & terminal.
//
// computeClaimState(claimType, evidenceStates):
//   Step 1 — aggregate = latticeSup over all evidence states (FALSIFIED dominates).
//   Step 2 — cap by claim-type rank:
//              mathematical(4) → PROVEN
//              semantic(3)     → VERIFIED
//              empirical(2)    → SUPPORTED
//              operational(1)  → OBSERVED
//   Step 3 — clamp down if aggregate exceeds cap.

import {
  AUTH_THRESHOLD,
  CLAIM_TYPE_RANK,
  STATE_RANK,
  type ClaimType,
  type VerificationState,
} from "./types";

export function compareStates(a: VerificationState, b: VerificationState): number {
  // FALSIFIED is incomparable with affirmative states.
  if (a === "FALSIFIED" || b === "FALSIFIED") return 0;
  return STATE_RANK[a] - STATE_RANK[b];
}

export function stateAtLeast(a: VerificationState, b: VerificationState): boolean {
  if (a === "FALSIFIED" || b === "FALSIFIED") return false;
  return compareStates(a, b) >= 0;
}

export function latticeSup(a: VerificationState, b: VerificationState): VerificationState {
  // If either is FALSIFIED, the supremum is FALSIFIED (terminal denial dominates).
  if (a === "FALSIFIED" || b === "FALSIFIED") return "FALSIFIED";
  return STATE_RANK[a] >= STATE_RANK[b] ? a : b;
}

function capForClaimType(claimType: ClaimType): VerificationState {
  const rank = CLAIM_TYPE_RANK[claimType];
  if (rank >= 4) return "PROVEN";
  if (rank >= 3) return "VERIFIED";
  if (rank >= 2) return "SUPPORTED";
  return "OBSERVED";
}

export function computeClaimState(
  claimType: ClaimType,
  evidenceStates: VerificationState[],
): VerificationState {
  // Step 1 — aggregate over evidence by latticeSup (start UNTESTED).
  let aggregate: VerificationState = "UNTESTED";
  for (const s of evidenceStates) {
    aggregate = latticeSup(aggregate, s);
  }
  // Step 2/3 — cap by claim-type rank; clamp down if aggregate exceeds cap.
  const cap = capForClaimType(claimType);
  if (aggregate === "FALSIFIED") return "FALSIFIED";
  if (STATE_RANK[aggregate] > STATE_RANK[cap]) return cap;
  return aggregate;
}

export function latticeDescription(): string {
  return "PROVEN ≥ VERIFIED ≥ SUPPORTED ≥ OBSERVED ≥ INCONCLUSIVE; FALSIFIED incomparable (terminal).";
}

export function statesInOrder(): VerificationState[] {
  return [
    "PROVEN",
    "VERIFIED",
    "SUPPORTED",
    "OBSERVED",
    "INCONCLUSIVE",
    "UNVALIDATED",
    "UNTESTED",
    "STALE",
    "FALSIFIED",
  ];
}

export function stateColor(s: VerificationState): string {
  switch (s) {
    case "PROVEN":
      return "emerald";
    case "VERIFIED":
      return "green";
    case "SUPPORTED":
      return "lime";
    case "OBSERVED":
      return "amber";
    case "INCONCLUSIVE":
      return "orange";
    case "UNVALIDATED":
      return "zinc";
    case "UNTESTED":
      return "slate";
    case "STALE":
      return "stone";
    case "FALSIFIED":
      return "red";
  }
}

export { AUTH_THRESHOLD };
