/**
 * EIS engine — the "teacher". It does not grade answers; it grades
 * data provenance. Every function here is pure and testable.
 */
import type { SensorMeta } from "./types";

/* ------------------------------------------------------------------ */
/* A. The "Echo Chamber" monitor — evidence independence.              */
/* ------------------------------------------------------------------ */

export const CORRELATION_CAP = 0.2; // confidence cap for correlated clusters
export const CORRELATION_DISTANCE_M = 5; // same-mast radius
export const ZERO_VARIANCE_WINDOW = 0.05; // readings closer than this = echo

export interface IndependenceReport {
  clusters: SensorMeta[][];
  correlated: boolean;
  zeroVariance: boolean; // "strong = suspicious"
  independentCount: number;
  flags: string[];
}

/**
 * Cluster active sensors by physical distance + modality. Two sensors of the
 * same modality within CORRELATION_DISTANCE_M form ONE correlated cluster —
 * their evidence counts once, capped at 0.2.
 */
export function checkIndependence(active: SensorMeta[]): IndependenceReport {
  const flags: string[] = [];
  const clusters: SensorMeta[][] = [];

  for (const s of active) {
    let placed = false;
    for (const cluster of clusters) {
      const sameModality = cluster.some((m) => m.modality === s.modality);
      const close = cluster.some(
        (m) => Math.abs(m.distanceM - s.distanceM) <= CORRELATION_DISTANCE_M,
      );
      if (sameModality && close) {
        cluster.push(s);
        placed = true;
        break;
      }
    }
    if (!placed) clusters.push([s]);
  }

  const correlated = clusters.some((c) => c.length > 1);
  if (correlated) {
    flags.push(
      `CORRELATED_CLUSTER: ${clusters
        .filter((c) => c.length > 1)
        .map((c) => c.map((s) => s.name).join("+"))
        .join(", ")} → confidence capped at ${CORRELATION_CAP}`,
    );
  }

  // Zero variance across the whole active evidence set = potential spoof.
  // "If it looks perfect, it's spoofed."
  const readings = active.map((s) => s.reading).filter((r): r is number => r !== null);
  let zeroVariance = false;
  if (readings.length > 1) {
    const spread = Math.max(...readings) - Math.min(...readings);
    if (spread < ZERO_VARIANCE_WINDOW) {
      zeroVariance = true;
      flags.push(
        `ZERO_VARIANCE: entire active set spans only ${spread.toFixed(2)} — if it looks perfect, it's spoofed`,
      );
    }
  }

  return { clusters, correlated, zeroVariance, independentCount: clusters.length, flags };
}

/* ------------------------------------------------------------------ */
/* B. Confidence with risk bounds — never a bare number, never 100%.   */
/* ------------------------------------------------------------------ */

export interface ConfidenceReport {
  value: number;
  bound: number;
  formula: string;
}

/**
 * Transparent confidence model (shown to the student — no black boxes):
 *   contribution = 0.35 per singleton cluster (independent evidence)
 *   contribution = 0.20 for any correlated cluster (echoes count once)
 *   bonus        = +0.05 spatial diversity when clusters span > 500 m
 *   ceiling      = 0.85 — the system structurally refuses certainty
 *   bound        = 0.10 − 0.02 × (clusters − 1), floored at 0.05
 *                  (every independent cluster tightens the bound)
 */
export function computeConfidence(rep: IndependenceReport, maxSpanM: number): ConfidenceReport {
  const parts: string[] = [];
  let sum = 0;
  for (const cluster of rep.clusters) {
    if (cluster.length > 1) {
      sum += CORRELATION_CAP;
      parts.push(`echo cluster (${cluster.map((s) => s.name).join("+")}) → capped at ${CORRELATION_CAP.toFixed(2)}`);
    } else {
      sum += 0.35;
      parts.push(`independent cluster (${cluster[0].name}) → 0.35`);
    }
  }
  const diversity = rep.independentCount > 1 && maxSpanM > 500 ? 0.05 : 0;
  if (diversity) parts.push("spatial diversity → +0.05");
  const value = Math.min(sum + diversity, 0.85);
  const bound = Math.max(0.05, 0.1 - 0.02 * (rep.independentCount - 1));
  const formula =
    parts.join(" · ") +
    (value >= 0.85 ? " · ceiling 0.85" : "") +
    ` → ${value.toFixed(2)} ± ${bound.toFixed(2)}`;
  return { value, bound, formula };
}

/* ------------------------------------------------------------------ */
/* C. The "Zero Fabrication" linter — interpolation is a hard error.   */
/* ------------------------------------------------------------------ */

export interface LintResult {
  ok: boolean;
  errors: { line: number; rule: string; message: string }[];
}

const FABRICATION_PATTERNS: { re: RegExp; rule: string; msg: string }[] = [
  {
    re: /\b(average|mean|median|interpolate|fillna|ffill|bfill|impute)\s*\(/i,
    rule: "EIS §2 ZERO-FABRICATION",
    msg: "interpolation over missing evidence — `assert(data != null, \"Zero Fabrication Rule Violation\")`",
  },
  {
    re: /=\s*(0+(\.0*)?|null|none)\s*;?\s*(#.*)?$/im,
    rule: "EIS §2 ZERO-FABRICATION",
    msg: "silent null assignment masks an UNDEFINED source",
  },
  {
    re: /val_type\s*=\s*PROCESSED/i,
    rule: "EIS §4 PROVENANCE",
    msg: "Val_Type=1 (Processed) requires a corresponding valid proof in Loc_Hash",
  },
];

export function lintStudentCode(code: string): LintResult {
  const errors: LintResult["errors"] = [];
  code.split("\n").forEach((line, i) => {
    for (const p of FABRICATION_PATTERNS) {
      if (p.re.test(line)) {
        errors.push({ line: i + 1, rule: p.rule, message: p.msg });
      }
    }
  });
  return { ok: errors.length === 0, errors };
}

/* ------------------------------------------------------------------ */
/* D. The "Anti-Perfection" rule — absolutes are rejected outright.    */
/* ------------------------------------------------------------------ */

export const FORBIDDEN_CLAIMS = ["100%", "safe", "secure", "bug-free", "perfect", "guaranteed", "certain", "proven 100"];

export interface ClaimResult {
  ok: boolean;
  reason?: string;
}

/**
 * A valid claim must (1) contain no absolute language and (2) carry an
 * explicit risk bound of the form `confidence = 0.xx ± 0.xx`.
 */
export function validateClaim(claim: string, currentConfidence: ConfidenceReport): ClaimResult {
  const lower = claim.toLowerCase();
  const hit = FORBIDDEN_CLAIMS.find((f) => lower.includes(f.toLowerCase()));
  if (hit) {
    return {
      ok: false,
      reason: `M0 ANTI-PERFECTION: the token "${hit}" is forbidden. Strong claims are suspicious — output risk bounds instead (e.g. "confidence = ${currentConfidence.value.toFixed(2)} ± ${currentConfidence.bound.toFixed(2)}").`,
    };
  }
  const m = lower.match(/confidence\s*=\s*(0?\.\d+)\s*±\s*(0?\.\d+)/);
  if (!m) {
    return {
      ok: false,
      reason:
        'FORMAT: the claim must state a bounded estimate, e.g. `confidence = 0.62 ± 0.08`. Unbounded numbers are unauditable.',
    };
  }
  const claimed = parseFloat(m[1]);
  const bound = parseFloat(m[2]);
  if (claimed >= 1) {
    return { ok: false, reason: "M0 ANTI-PERFECTION: confidence ≥ 1.0 is structurally impossible in this system." };
  }
  if (Math.abs(claimed - currentConfidence.value) > currentConfidence.bound + bound + 0.02) {
    return {
      ok: false,
      reason: `INTEGRITY: claimed ${claimed.toFixed(2)} deviates from the computed ${currentConfidence.value.toFixed(2)} beyond the stated bounds. Claim your evidence, not your hopes.`,
    };
  }
  return { ok: true };
}

export const CLAIM_TEMPLATE = "The Missionvale anomaly is a real thermal event. confidence = 0.20 ± 0.05";
