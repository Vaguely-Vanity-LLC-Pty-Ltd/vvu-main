// EIS — participation-ratio.ts (Theorem 2: N_ind Participation Ratio)
//
//   N_ind = (Σλ_i)² / Σλ_i²
//
// where λ are the eigenvalues of the RBF Gram matrix
//   G_ij = exp(−γ ‖φ_i − φ_j‖²)
// with the median-heuristic γ = 1 / median({ ‖φ_i − φ_j‖² : i < j }).
//
// N_ind is monotonic non-decreasing in the true latent source count m,
// with bounded bias — it estimates how many genuinely independent
// sources produced the evidence (multiple sources ≠ independent).

import type { ParticipationRatioResult } from "./types";

// --- helpers ---

function squaredDistance(a: number[], b: number[]): number {
  let s = 0;
  for (let i = 0; i < a.length; i++) {
    const d = a[i] - b[i];
    s += d * d;
  }
  return s;
}

function median(xs: number[]): number {
  if (xs.length === 0) return 0;
  const sorted = [...xs].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0
    ? (sorted[mid - 1] + sorted[mid]) / 2
    : sorted[mid];
}

// FNV-1a hash → deterministic per-source center.
function hashString(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
  h = Math.imul(h, 0x01000193);
  }
  // force unsigned
  return h >>> 0;
}

// Mulberry32 PRNG → deterministic per-evidence jitter.
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function seededVector(seed: number, dim: number): number[] {
  const rng = mulberry32(seed);
  const v: number[] = [];
  for (let i = 0; i < dim; i++) v.push(rng() * 2 - 1);
  // L2-normalise.
  let norm = 0;
  for (const x of v) norm += x * x;
  norm = Math.sqrt(norm) || 1;
  return v.map((x) => x / norm);
}

// --- public API ---

export function medianHeuristicGamma(embeddings: number[][]): number {
  const n = embeddings.length;
  if (n < 2) return 1.0;
  const dists: number[] = [];
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      dists.push(squaredDistance(embeddings[i], embeddings[j]));
    }
  }
  const m = median(dists);
  if (m === 0 || !isFinite(m)) return 1.0;
  return 1.0 / m;
}

export function rbfGramMatrix(embeddings: number[][], gamma: number): number[][] {
  const n = embeddings.length;
  const G: number[][] = Array.from({ length: n }, () => new Array(n).fill(0));
  for (let i = 0; i < n; i++) {
    for (let j = i; j < n; j++) {
      if (i === j) {
        G[i][j] = 1;
        G[j][i] = 1;
      } else {
        const d2 = squaredDistance(embeddings[i], embeddings[j]);
        const v = Math.exp(-gamma * d2);
        G[i][j] = v;
        G[j][i] = v;
      }
    }
  }
  return G;
}

// Jacobi eigenvalue algorithm for symmetric matrices.
// Returns eigenvalues sorted descending by |λ|.
export function symmetricEigenvalues(matrix: number[][]): number[] {
  const n = matrix.length;
  if (n === 0) return [];
  if (n === 1) return [matrix[0][0]];
  // Copy into a working array.
  const a: number[] = [];
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) a.push(matrix[i][j]);
  const get = (i: number, j: number) => a[i * n + j];
  const set = (i: number, j: number, v: number) => {
    a[i * n + j] = v;
  };

  const maxSweeps = 100;
  const tolerance = 1e-10;
  for (let sweep = 0; sweep < maxSweeps; sweep++) {
    // off-diagonal norm.
    let off = 0;
    for (let p = 0; p < n; p++) {
      for (let q = p + 1; q < n; q++) {
        off += get(p, q) * get(p, q);
      }
    }
    if (off < tolerance) break;
    for (let p = 0; p < n; p++) {
      for (let q = p + 1; q < n; q++) {
        const app = get(p, p);
        const aqq = get(q, q);
        const apq = get(p, q);
        if (Math.abs(apq) < 1e-30) continue;
        const tau = (aqq - app) / (2 * apq);
        const t =
          tau >= 0 ? 1 / (tau + Math.sqrt(1 + tau * tau)) : -1 / (-tau + Math.sqrt(1 + tau * tau));
        const c = 1 / Math.sqrt(1 + t * t);
        const s = t * c;
        set(p, p, app - t * apq);
        set(q, q, aqq + t * apq);
        set(p, q, 0);
        set(q, p, 0);
        for (let k = 0; k < n; k++) {
          if (k !== p && k !== q) {
            const akp = get(k, p);
            const akq = get(k, q);
            set(k, p, c * akp - s * akq);
            set(p, k, get(k, p));
            set(k, q, s * akp + c * akq);
            set(q, k, get(k, q));
          }
        }
      }
    }
  }
  const eigvals: number[] = [];
  for (let i = 0; i < n; i++) eigvals.push(get(i, i));
  eigvals.sort((x, y) => Math.abs(y) - Math.abs(x));
  return eigvals;
}

export function computeParticipationRatio(
  embeddings: number[][],
  gammaOverride?: number,
): ParticipationRatioResult {
  const n = embeddings.length;
  if (n === 0) {
    return { nInd: 0, numEvidence: 0, numSources: 0, gamma: 0, eigenvalues: [] };
  }
  if (n === 1) {
    return { nInd: 1, numEvidence: 1, numSources: 1, gamma: 1, eigenvalues: [1] };
  }
  const gamma = gammaOverride ?? medianHeuristicGamma(embeddings);
  const G = rbfGramMatrix(embeddings, gamma);
  let eigvals = symmetricEigenvalues(G);
  // Clamp tiny negatives to 0 (Gram matrix is PSD up to numerical error).
  eigvals = eigvals.map((v) => (v < 0 && v > -1e-9 ? 0 : v));
  const sum = eigvals.reduce((a, b) => a + b, 0);
  const sumSq = eigvals.reduce((a, b) => a + b * b, 0);
  const nInd = sumSq > 0 ? (sum * sum) / sumSq : 0;
  return {
    nInd,
    numEvidence: n,
    numSources: Math.round(nInd),
    gamma,
    eigenvalues: eigvals,
  };
}

export function synthesizeEmbedding(source: string, seed: number, dim = 20): number[] {
  // Deterministic per-source center.
  const centerHash = hashString(source);
  const centerRng = mulberry32(centerHash);
  const center: number[] = [];
  for (let i = 0; i < dim; i++) center.push(centerRng() * 2 - 1);
  // Per-evidence jitter.
  const jitter = seededVector(seed, dim);
  const out: number[] = [];
  let norm = 0;
  for (let i = 0; i < dim; i++) {
    const v = center[i] * 0.7 + jitter[i] * 0.3;
    out.push(v);
    norm += v * v;
  }
  norm = Math.sqrt(norm) || 1;
  return out.map((v) => v / norm);
}
