// EIS — heat-kernel.ts (Theorem 3: Heat-Kernel Diffusion)
//
//   u_t = −κ L u   where L = D − A is the graph Laplacian.
//
// Low-frequency modes persist; high-frequency modes are suppressed; the system
// converges to the projection onto the kernel of L. The wave equation
// (u_tt + c² L u = 0) conserves energy (drift 0) but is inappropriate for
// dissipative evidence systems.

import type { HeatKernelResult, HeatKernelStep } from "./types";

// --- graph Laplacians ---

export function cycleGraphLaplacian(n: number): number[][] {
  const L: number[][] = Array.from({ length: n }, () => new Array(n).fill(0));
  for (let i = 0; i < n; i++) {
    L[i][i] = 2;
    L[i][(i + 1) % n] = -1;
    L[i][(i - 1 + n) % n] = -1;
  }
  return L;
}

export function completeGraphLaplacian(n: number): number[][] {
  const L: number[][] = Array.from({ length: n }, () => new Array(n).fill(0));
  for (let i = 0; i < n; i++) {
    L[i][i] = n - 1;
    for (let j = 0; j < n; j++) {
      if (i !== j) L[i][j] = -1;
    }
  }
  return L;
}

// --- linear algebra helpers ---

function matVec(M: number[][], v: number[]): number[] {
  const n = M.length;
  const out = new Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    let s = 0;
    for (let j = 0; j < n; j++) s += M[i][j] * v[j];
    out[i] = s;
  }
  return out;
}

function l2Norm(v: number[]): number {
  let s = 0;
  for (const x of v) s += x * x;
  return Math.sqrt(s);
}

// Jacobi eigenvalue algorithm (duplicated for module independence).
function symmetricEigenvalues(matrix: number[][]): number[] {
  const n = matrix.length;
  if (n === 0) return [];
  if (n === 1) return [matrix[0][0]];
  const a: number[] = [];
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) a.push(matrix[i][j]);
  const get = (i: number, j: number) => a[i * n + j];
  const set = (i: number, j: number, v: number) => {
    a[i * n + j] = v;
  };
  for (let sweep = 0; sweep < 100; sweep++) {
    let off = 0;
    for (let p = 0; p < n; p++) for (let q = p + 1; q < n; q++) off += get(p, q) * get(p, q);
    if (off < 1e-10) break;
    for (let p = 0; p < n; p++) {
      for (let q = p + 1; q < n; q++) {
        const apq = get(p, q);
        if (Math.abs(apq) < 1e-30) continue;
        const app = get(p, p);
        const aqq = get(q, q);
        const tau = (aqq - app) / (2 * apq);
        const t =
          tau >= 0 ? 1 / (tau + Math.sqrt(1 + tau * tau)) : -1 / (-tau + Math.sqrt(1 + tau * tau));
        const c = 1 / Math.sqrt(1 + t * t);
        const s = t * c;
        set(p, p, app - t * apq);
        set(q, q, aqq + t * apq);
        set(p, q, 0);
        set(q, p, 0);
        for (let k = 0; k < n; k++) {
          if (k !== p && k !== q) {
            const akp = get(k, p);
            const akq = get(k, q);
            set(k, p, c * akp - s * akq);
            set(p, k, get(k, p));
            set(k, q, s * akp + c * akq);
            set(q, k, get(k, q));
          }
        }
      }
    }
  }
  const eigvals: number[] = [];
  for (let i = 0; i < n; i++) eigvals.push(get(i, i));
  eigvals.sort((a, b) => a - b);
  return eigvals;
}

// --- diffusion ---

export function gaussianInitialCondition(n: number, center: number, sigma = 5.0): number[] {
  const u = new Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    let d = Math.abs(i - center);
    d = Math.min(d, n - d); // cycle wrap-around
    u[i] = Math.exp(-(d * d) / (2 * sigma * sigma));
  }
  const norm = l2Norm(u) || 1;
  return u.map((x) => x / norm);
}

export function heatKernelDiffusion(
  L: number[][],
  u0: number[],
  kappa = 0.25,
  steps = 100,
): HeatKernelResult {
  const n = L.length;
  const eigvals = symmetricEigenvalues(L);
  let lambdaMax = 0;
  for (const e of eigvals) {
    if (Math.abs(e) > lambdaMax) lambdaMax = Math.abs(e);
  }
  if (lambdaMax === 0) lambdaMax = 1;
  // CFL stability: dt = 0.5 / λ_max
  const dt = 0.5 / lambdaMax;
  const out: HeatKernelStep[] = [];
  let u = [...u0];
  const initialL2 = l2Norm(u) || 1;
  for (let s = 0; s <= steps; s++) {
    const Lu = matVec(L, u);
    const l2 = l2Norm(u);
    const hf = l2Norm(Lu);
    out.push({ step: s, l2Norm: l2, highFreqEnergy: hf, nodeValues: [...u] });
    if (s < steps) {
      // explicit Euler: u ← u − κ·dt·L·u
      const next = new Array(n).fill(0);
      for (let i = 0; i < n; i++) next[i] = u[i] - kappa * dt * Lu[i];
      u = next;
    }
  }
  const finalL2 = out[out.length - 1].l2Norm;
  const finalHF = out[out.length - 1].highFreqEnergy;
  const finalHfNorm = initialL2 > 0 ? finalHF / initialL2 : finalHF;
  const retention = initialL2 > 0 ? finalL2 / initialL2 : 0;
  return {
    steps: out,
    finalL2Norm: finalL2,
    finalHighFreqEnergy: finalHfNorm,
    retention,
  };
}

export function smoothEvidenceWeights(
  evidenceWeights: number[],
  kappa = 0.1,
  steps = 25,
): { smoothed: number[]; retention: number } {
  const n = evidenceWeights.length;
  if (n === 0) return { smoothed: [], retention: 0 };
  const L = completeGraphLaplacian(n);
  const res = heatKernelDiffusion(L, evidenceWeights, kappa, steps);
  const last = res.steps[res.steps.length - 1];
  return { smoothed: last.nodeValues, retention: res.retention };
}
