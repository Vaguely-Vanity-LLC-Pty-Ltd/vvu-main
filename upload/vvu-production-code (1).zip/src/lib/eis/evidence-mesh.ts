// EIS — evidence-mesh.ts (Theorem 4 §4: Evidence Mesh synthesis)
//
// The Evidence Mesh synthesises observations from four sources:
//   you.com — search latent (semantic recall)
//   brave   — independent index (semantic recall, distinct corpus)
//   firecrawl — page-grounded extraction (high-fidelity content)
//   watchdog — operational telemetry (the strongest, most direct signal)
//
// Each MeshResult carries:
//   - content (deterministic per-source/per-seed)
//   - weight ∈ [0,1] (base weight + deterministic jitter)
//   - embedding ∈ R^20 (per-source center + per-evidence jitter)
//   - state = "OBSERVED"
//
// NOTE: multiple sources ≠ independent. N_ind (Theorem 2) identifies the
// true latent source count.

import type { EvidenceSource, EvidenceItem } from "./types";
import { synthesizeEmbedding } from "./participation-ratio";

export interface MeshQuery {
  claimId: string;
  query: string;
  sources?: EvidenceSource[];
}

export interface MeshResult {
  source: EvidenceSource;
  content: string;
  embedding: number[];
  weight: number;
  state: string;
}

export const SOURCE_DESCRIPTIONS: Record<EvidenceSource, string[]> = {
  "you.com": [
    "Semantic recall from the open web — summarised passage relevant to the claim.",
    "Latent search result — adjacent corpus confirms the entity under test.",
    "Search-graph walk — related nodes present; no direct contradiction.",
  ],
  brave: [
    "Independent index hit — separate crawler corpus reports the same anchor fact.",
    "Brave rank signal — the entity appears in the top-K of a distinct index.",
    "Privacy-preserving query — result fingerprint differs from you.com.",
  ],
  firecrawl: [
    "Page-grounded extraction — full DOM text retrieved and chunked deterministically.",
    "Structured extraction — JSON-LD + main content normalised into evidence payload.",
    "Crawl frontier — outbound links form the provenance graph for diffusion.",
  ],
  watchdog: [
    "Operational telemetry — direct probe measurement of the system under test.",
    "Heartbeat probe — liveness + latency sample collected at the edge.",
    "Sequence receipt — hash-chained event from the runtime WORM ledger.",
  ],
};

const BASE_WEIGHT: Record<EvidenceSource, number> = {
  "you.com": 0.65,
  brave: 0.75,
  firecrawl: 0.85,
  watchdog: 0.95,
};

export function queryEvidenceMesh(query: string, seed = 1): MeshResult[] {
  const sources: EvidenceSource[] = ["you.com", "brave", "firecrawl", "watchdog"];
  const out: MeshResult[] = [];
  sources.forEach((source, idx) => {
    const descriptions = SOURCE_DESCRIPTIONS[source];
    const content = descriptions[(seed + idx) % descriptions.length];
    const base = BASE_WEIGHT[source];
    const jitter = ((seed * (idx + 7)) % 11) / 100;
    const weight = Math.min(1, Math.max(0, base + jitter));
    const embedding = synthesizeEmbedding(source, seed * 10 + idx);
    out.push({ source, content, embedding, weight, state: "OBSERVED" });
  });
  return out;
}

export function evidenceToNodes(items: EvidenceItem[]): number[] {
  return items.map((e) => e.weight);
}

export function distinctSources(items: EvidenceItem[]): EvidenceSource[] {
  return Array.from(new Set(items.map((e) => e.source as EvidenceSource)));
}

// Estate-aware mesh flavors.
// Each estate biases the base weights to reflect where its evidence
// typically comes from:
//   canonical  — balanced (default)
//   hbk-mk2    — watchdog + firecrawl heavy (operational + page-grounded)
//   skylantern — you.com + brave heavy (semantic + governance docs)
export function estateMeshFlavor(estateKey: string): Partial<Record<EvidenceSource, number>> {
  switch (estateKey) {
    case "hbk-mk2":
      return { watchdog: 0.97, firecrawl: 0.88, brave: 0.7, "you.com": 0.6 };
    case "skylantern":
      return { "you.com": 0.82, brave: 0.8, firecrawl: 0.78, watchdog: 0.6 };
    default:
      return {};
  }
}

export function queryEvidenceMeshForEstate(
  query: string,
  seed = 1,
  estateKey = "canonical",
): MeshResult[] {
  const base = queryEvidenceMesh(query, seed);
  const flavor = estateMeshFlavor(estateKey);
  return base.map((r) => ({
    ...r,
    weight: flavor[r.source] ?? r.weight,
  }));
}
