"use client";
/**
 * VVU global paranoia store — the single source of truth for the
 * Paranoia Bar. Gates are only ever *computed*, never asserted.
 */
import { create } from "zustand";

export type SuspicionLevel = "CLEAR" | "ELEVATED" | "CRITICAL";

export interface StubFlag {
  id: string;
  label: string;
}

export interface GateDef {
  id: string;
  lab: 0 | 1 | 2;
  label: string;
}

export const GATES: GateDef[] = [
  // Lab 0 — The Language of Numbers
  { id: "m-place", lab: 0, label: "CH1 · Reach the address (3, 4)" },
  { id: "m-axes", lab: 0, label: "CH2 · Walk (3, 4) using pure axis moves" },
  { id: "m-add", lab: 0, label: "CH3 · Chain two walks into (4, 3)" },
  { id: "m-pyth", lab: 0, label: "CH4 · Build the 3-4-5 triangle" },
  { id: "m-pi", lab: 0, label: "CH5 · Test π across 3 radii" },
  { id: "m-frac", lab: 0, label: "CH6 · Cut space into quarters, select 3/4" },
  { id: "m-phys", lab: 0, label: "CH7 · Steer the puck with net force (4, 3)" },

  // Lab 1 — EIS Evidence Lab
  { id: "e-inspect", lab: 1, label: "Inspect all 11 fields of every payload" },
  { id: "e-indep", lab: 1, label: "Run the Echo Chamber independence check" },
  { id: "e-zerofab", lab: 1, label: "Survive the Zero Fabrication trap" },
  { id: "e-chain", lab: 1, label: "Verify the hash chain locally" },
  { id: "e-redteam", lab: 1, label: "RED TEAM: break the chain, witness CRITICAL FAILURE" },
  { id: "e-resolve", lab: 1, label: "Resolve with an independent spectral source" },
  { id: "e-claim", lab: 1, label: "Submit a bounded claim (anti-perfection)" },

  // Lab 2 — Credential Engine
  { id: "c-contract", lab: 2, label: "Review the ERC-5192 contract" },
  { id: "c-employer", lab: 2, label: "Run the employer verification flow" },
  { id: "c-mint", lab: 2, label: "Mint the soulbound evidence token" },
];

interface VVUState {
  booted: boolean;
  setBooted: (b: boolean) => void;

  gates: Record<string, boolean>;
  computeGate: (id: string) => void;

  stubs: StubFlag[];
  flagStub: (stub: StubFlag) => void;
  clearStub: (id: string) => void;

  /** live suspicion of "too clean" evidence */
  zeroVariance: boolean;
  setZeroVariance: (v: boolean) => void;

  /** ledger integrity */
  chainBroken: boolean;
  setChainBroken: (v: boolean) => void;

  /** derived */
  computedCount: () => number;
  suspicion: () => SuspicionLevel;
}

export const useVVU = create<VVUState>((set, get) => ({
  booted: false,
  setBooted: (b) => set({ booted: b }),

  gates: {},
  computeGate: (id) =>
    set((s) => (s.gates[id] ? {} : { gates: { ...s.gates, [id]: true } })),

  stubs: [
    { id: "SIG-001", label: "Signature layer: HMAC-SHA256 stand-in for Ed25519 (prototype)" },
  ],
  flagStub: (stub) =>
    set((s) => (s.stubs.some((x) => x.id === stub.id) ? {} : { stubs: [...s.stubs, stub] })),
  clearStub: (id) => set((s) => ({ stubs: s.stubs.filter((x) => x.id !== id) })),

  zeroVariance: true, // genesis: A & B report identical 40.0 °C
  setZeroVariance: (v) => set({ zeroVariance: v }),

  chainBroken: false,
  setChainBroken: (v) => set({ chainBroken: v }),

  computedCount: () => Object.values(get().gates).filter(Boolean).length,

  suspicion: () => {
    const s = get();
    if (s.chainBroken) return "CRITICAL";
    if (s.zeroVariance) return "ELEVATED";
    return "CLEAR";
  },
}));

export const REQUIRED_FOR_MINT = [
  "m-place",
  "m-axes",
  "m-add",
  "m-pyth",
  "m-pi",
  "m-frac",
  "m-phys",
  "e-inspect",
  "e-indep",
  "e-zerofab",
  "e-chain",
  "e-resolve",
  "e-claim",
];
