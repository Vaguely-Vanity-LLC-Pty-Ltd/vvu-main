import { PrismaClient } from "@prisma/client"
import { createClient, type Client } from "@libsql/client"

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
  libsql: Client | undefined
}

const databaseUrl = process.env.DATABASE_URL || ""

// When DATABASE_URL is a libsql:// URL (Turso), use the libsql client directly.
// Prisma sqlite provider cannot connect to libsql:// — so we export both:
// - `db` for code that still uses Prisma (will throw on libsql://, which is expected)
// - `libsql` for code that queries Turso directly via SQL
export const libsql: Client =
  globalForPrisma.libsql ??
  (databaseUrl.startsWith("libsql://")
    ? (() => {
        const url = new URL(databaseUrl)
        const authToken = url.searchParams.get("authToken") || undefined
        return createClient({ url: url.protocol + "//" + url.host, authToken })
      })()
    : createClient({ url: "file:./db/custom.db" }))

if (process.env.NODE_ENV !== "production") globalForPrisma.libsql = libsql

// Prisma client — only works with file: URLs.
// On Turso, this will throw. API routes should use `libsql` instead.
export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ["error", "warn"],
  })

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = db
