# VVU Ingest — Round 8: Operator Deployment Integration (Task 14)

Sovereign messages ingested verbatim-order. Epistemic status of this record: VERBATIM ARCHIVE.

## Directive (Round 8, current)

Sovereign supplies two reference images and re-rules the game design:

1. **Image 1 — `03_verbatim_after_dead_button_clicks.png`** (also in `download/vvu_loadout_forge_evidence/`):
   VVU Operator Loadout screen. Terminal-style UI, dark hex-grid backdrop, cyan monospace accents.
   - Left panel: `EDIT LOADOUT` / `01 // VVU OPERATOR`; PRIMARY: `M4A1 // DRONE CONTROLLER` — `LVL 43 // EQUIPPED`.
   - PERKS (MAX 3): `GHOST // STEALTH MODE` (Undetectable by enemy CCTV networks) — unchecked; `BLOOD RUSH // OVERCLOCK` (Tactical sprint boosts local edge compute) — **checked**; `BATTLE HARDENED // ENCRYPTION` (Reduces effect of enemy cyber attacks) — unchecked.
   - Right: 3D damaged sci-fi helmet (white/red/cyan PBR), caption `M4A1` / `DRONE CONTROLLER`.
   - Top right ammo fixture: `28` | `7` — `AMMO // RESERVE`.
   - Bottom: `DEPLOY TO SCENE` (cyan solid) + `EDIT CAMO` (outline).

2. **Image 2 — `call-of-duty-modern-warfare-4-dmz_edit_7799318375892.jpg`**:
   Cinematic tactical squad: three operators in full dark tactical gear (helmets, NODs, heavy backpacks, suppressed rifles) advancing through an industrial hall beneath a **massive shattered geodesic glass dome ceiling** pouring atmospheric light shafts through haze. Smoke/dust, drifting orange sparks (right), shell casings on floor, blurred dark foreground mass (fallen body/gear) bottom-left, steel truss silhouettes. Strike team clearing a room.

## Sovereign rulings (supersede Round 6-game proposals)

- The previous UI/combat redesign (rock-paper-scissors Light/Heavy/Block + 3D arena with health bars) is **REJECTED by sovereign** — do not build it.
- Space gameplay: **KEEP** the top-down space shooter loop — black hole, drones, pirates, warp, boost.
- Ground gameplay (boarding): transition into **first-person / close-up CQC** — 1v1 fights, close combat.
- Image 1 = HUD/UI language of the ground combat (Loadout, Perks, Telemetry, Damaged Helmet, Recon Operator).
- Image 2 = atmosphere of the ground combat (dark, sparks, tactical, dome ceiling).
- Deliverable: describe the images + integrate with the described ground gameplay; single HTML.

## Canonical-carryover ruling (runner, fail-closed)

- No space-shooter source exists anywhere in transport (checked: upload/, download/, workspace/, both `message-ea2fed31*.zip` archives = Round 3–6 evidence only). The "previous" loop cannot be carried byte-exact — that claim would be FALSE.
- Action: rebuild the loop **from sovereign's verbatim spec**; every in-UI claim labeled `REBUILT_FROM_SPEC` and metered at runtime. Canonical GLB equip pipeline imported unchanged from `vvu_loadout_forge_patched.html` (three@0.147.0 pair, per-claim fetch/meter, fail-closed w/ stage clearing, No-Primitives Law).

## Standing queues (unresolved, not blocking this task)

- Choice (a): Bioteknik Clinician Dashboard vs Vitality Gym Integration — QUEUED (sovereign has not ruled).
- G19 relay hardware, G20 checkout artifact, G18 marketplace, provider feeds — standing debts.
- Numbering on entry: next defect **F32**, next gap **G21**.
