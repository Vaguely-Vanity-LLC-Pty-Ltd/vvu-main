# VVU EDGE OF OBLIVION — ROUND 9 AUDIT
File: `download/vvu_edge_of_oblivion.html` (128,520 B, single file, no build step)
Baseline: `vvu_operator_deployment.html` (Round 8, Task 14, PROVEN — byte-carried forward, all Round-8 systems intact)
Sovereign directive: dedicated on-screen controls `< > ^ v` + `+ # * ?`; `?` = mystery attack earned after battlefield time; propaganda radio layer; ground close-contact semantics per Ground Combat design doc v1.0.

## 1. WHAT WAS ADDED (per-claim)

### ctlPads — dedicated on-screen controls (PROVEN)
- Movement pad: `^` up/sprint, `v` down/crouch, `<` `>` lateral. Grid D-pad, always visible in SPACE + GROUND, hidden in LOADOUT.
- Weapon pad 2×2: `+` fire, `#` pulse/boost, `*` melee/board, `?` killcode. `?` carries live sub-label (UNKNOWN / 44s / READY / REBOOT).
- Pointer events + touchstart guard + keyboard mirrors (1/J, 2/K, 3/L/E, 4/Q; WASD/arrows for move; Shift sprint; double-tap `^` = BLOOD RUSH overclock).
- Pad-driven aim fallback in space (velocity heading when mouse idle > 2.5s); auto-aim fire solution + auto-reload on foot.
- Claims: padMove button states drive Space movement (px 800→553.25 measured) and Ground operator px; all 8 buttons present at 390px viewport.

### `?` CARTOGRAPHER KILLCODE — INVERSION (PROVEN)
- State machine: UNKNOWN → CHARGING (field exposure; ground = 1.0×, space = 0.55×) → READY (pulse animation) → fired → REBOOT (2.6s HUD glitch via `.hud-glitch`) → CHARGING (60s).
- First charge 45s, subsequent 60s. Button sub-label shows remaining field time — the earn mechanic is visible on the control itself.
- SPACE variant: pull drones ≤560 toward a point 150 ahead over 0.9s, then unmake ≤300 radius; consumed drones → +1 fragment each + salvage; ledger INVERSION_FIRED / INVERSION_CONSUMED.
- GROUND variant: captain pulled toward point ahead of operator, 60 dmg + SIGNAL DISRUPTED (3s); self-damage 15 (8 if crouched — "dive for cover"); INVERSION COMPLETE text; HUD reboot.
- Fictions consistent with the sovereign's lore: the button is unlabeled because the VVU erased the symbol (Cartographer's kill-code).

### Propaganda radio layer (PROVEN)
- `#radioFeed`: 3-line typed feed + always-moving static garbage row (the static is literally rendered beneath the sanitized line).
- 15 sanitized VVU broadcast lines (the actual scripts, verbatim in source) + 8 Cartographer static leaks gated by fragment count (shards ≥ 1..8) + 8 event-pushed lines (boarding, hull critical, inversion, captain neutralized, ship lost, operator down, killcode ready, boot).
- Fragment economy: drone kills 14%, raider disabled, disruption first-per-sortie, captain neutralized +2, inversion consumes.
- WebAudio static bed (band-passed noise) gated to typing; fail-safe no-op if AudioContext blocked.

### Ground close-contact upgrade (PROVEN)
- Operator avatar on the field (cyan optical sensor, patched armor, multi-tool belt glint, sprint dust, suit-leak trail <39%).
- `< >` move / `^` sprint (loud: CCTV exposure pressure) / `v` crouch; cover only counts when actually behind crates (crouch-in-open = 55% dmg, no longer immune).
- `*` = MELEE // FIELD TOOL: light 16 / L-L-H heavy 26 → DISRUPTION CHAIN → SIGNAL DISRUPTED 3s → `*` again = EXECUTE 70. Works while HUD is cyber-jammed (the analog tool).
- `#` = PULSE CHARGE: hold 0.22–0.92s; 0.78–0.92 = PERFECT (68 dmg + stagger); on hidden target = cover flush. Charge ring drawn on reticle.
- `+` = sidearm with auto-aim solution + auto-reload. VVU HUD lies: armor note flickers to "SUIT LEAKING — TRUTH LAYER ACTIVE" below 40; SECTOR STATUS: STABLE chip flips to T-MINUS truth at shards ≥ 5.
- MULTI-TOOL chip relabeled: "BLOCKED_MISSING_ASSET // FIELD REALITY: ON YOUR BELT (*)" — the slot stays BLOCKED (fail-closed, No-Primitives) while the fiction proceeds, exactly per the Cartographer lore.

### Lore layer (PROVEN)
- Timeline counter: increments on ship loss AND operator death; death banner carries the Cartographer rewind line; telemetry strip shows TIMELINE n · FRAGMENTS n.
- Threat meter: MODERATE→ELEVATED→SEVERE by timeline; shards ≥ 5 flips to "TRUTH LAYER: CONSUMPTION IN PROGRESS — T-MINUS n DAYS".
- Title/branding → EDGE OF OBLIVION — VVU FIELD TERMINAL; LOADOUT MULTI-TOOL slot note carries the Cartographer bypass-code anomaly; BLOOD RUSH perk now documents the -5% suit trade-off (implemented).

## 2. VERIFICATION (live, agent-browser headless)
- node --check: PASS. ID cross-check: PASS. Brace balance: PASS. No-Primitives grep: 0 hits.
- Full battery (scripts/verify_round9_battery.sh): 9/9 sections — boot/pads/radio; killcode earn loop (44s→READY→REBOOT→57s recharge); INVERSION_FIRED + INVERSION_CONSUMED; board→LOADOUT real GLB 3,773,916 B · 15,452 tris → PROVEN (fail-closed gate intact); deploy→ground; pad movement measured; melee chain CQC_MELEE×2→CQC_DISRUPTION→CQC_EXECUTE→CAPTAIN_NEUTRALIZED; ground inversion; timeline 2 rewind; mobile 390 ×3 phases; zero page errors; 8 evidence PNGs (vvu_edge_of_oblivion_evidence/).
- Recheck (scripts/verify_round9_recheck.sh): F36 fix verified on both lethal paths.

## 3. DEFECT LEDGER
- **F36** (found by battery, PATCHED, re-verified): ground INVERSION detonation reduced captain to 0 HP without resolving victory — soft-lock (0-HP captain kept firing). Fix: detonation is a lethal source; win() resolved before self-blast; invT cleared. Evidence: 08_recheck_F36_melee_execute_inversion.png + ledger tail CQC_DISRUPTION→CQC_EXECUTE→CAPTAIN_NEUTRALIZED.
- No new gaps consumed. Numbering: next defect **F37**, next gap **G22** (G18 marketplace/WORM, G21 camo, G19 relay HW, G20 checkout remain QUEUED).

## 4. EPISTEMIC STATUS
- PROVEN: ctlPads; killcode earn loop + both INVERSION variants; radio layer + script banks; ground movement/melee/pulse/execute; timeline rewind; Round-8 equip pipeline untouched and re-verified (real network PROVEN).
- SIMULATED (disclosed in-band): enemy AI, static hiss, telemetry strip, session ledger (non-cryptographic, G18).
- BLOCKED_MISSING_ASSET: MULTI-TOOL .glb (by design — it is the story), camo library (G21).
